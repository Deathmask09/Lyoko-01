#!/usr/bin/env bash
set -euo pipefail
B="${1:-.theos/obj/debug/MessengerBubbles.dylib}"
if [[ ! -f "$B" ]]; then echo "Missing dylib: $B" >&2; exit 2; fi
if [[ -f build.log ]] && grep -Eiq 'incompatible arm64e ABI compiler|unsupported arm64e' build.log; then
  echo 'ERROR: ARM64e ABI incompatibility detected in build log.' >&2
  exit 3
fi

echo '===== FILE ====='
file "$B"
echo '===== ARCHS ====='
lipo -archs "$B"
lipo -verify_arch arm64 arm64e "$B"
echo '===== MACH-O HEADERS (check arm64e ABI against known-working dylib) ====='
otool -hv "$B"
echo '===== LOAD COMMANDS / DEPENDENCIES ====='
otool -L "$B"
echo '===== CODE SIGNATURE LOAD COMMAND (presence only) ====='
otool -l "$B" | grep -A5 -m1 LC_CODE_SIGNATURE || true
echo '===== SUCCESS: architectural/link checks completed; runtime NOT tested ====='
