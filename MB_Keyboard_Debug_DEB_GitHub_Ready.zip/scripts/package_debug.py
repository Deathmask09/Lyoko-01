#!/usr/bin/env python3
"""Offline Debug packaging using original MessengerBubbles DEB. Does not install anything."""
import argparse, hashlib, pathlib, re, shutil, subprocess, tempfile

def run(*a):
    print('$', ' '.join(map(str,a)),flush=True)
    return subprocess.run(list(map(str,a)),check=True,text=True,capture_output=True)

p=argparse.ArgumentParser()
p.add_argument('--base',required=True,type=pathlib.Path)
p.add_argument('--binary',required=True,type=pathlib.Path)
p.add_argument('--output',required=True,type=pathlib.Path)
a=p.parse_args()
for f in (a.base,a.binary):
    if not f.is_file(): raise SystemExit(f'MISSING: {f}')

# Validate new architecture: do not use false-success old ABI on arm64e.
archs=run('lipo','-archs',a.binary).stdout.split()
if not {'arm64','arm64e'}.issubset(archs):
    raise SystemExit('STOP: new binary needs ARM64 + ARM64E')
header=run('otool','-hv',a.binary).stdout
lines=[x for x in header.splitlines() if 'ARM64' in x and ' E ' in f' {x} ']
if not lines or not any('USR00' in x or 'PAC00' in x for x in lines):
    raise SystemExit('STOP: cannot verify modern ARM64E ABI from otool -hv; inspect header manually.\n'+header)
if pathlib.Path('build.log').is_file() and 'incompatible arm64e abi' in pathlib.Path('build.log').read_text(errors='replace').lower():
    raise SystemExit('STOP: arm64e ABI compiler warning found')

with tempfile.TemporaryDirectory(prefix='mb_deb_') as d:
    root=pathlib.Path(d)/'root'
    run('dpkg-deb','-R',a.base,root)
    control=root/'DEBIAN/control'
    if not control.is_file(): raise SystemExit('Missing control')
    info=control.read_text()
    for v in ('Package: com.lyoko-01.messengerbubbles','Architecture: iphoneos-arm64e'):
        if v not in info: raise SystemExit(f'Wrong original DEB: {v}')
    required=[
        root/'Library/MessengerBubbles/MessengerBubblesEngine.dylib',
        root/'Library/MobileSubstrate/DynamicLibraries/MessengerBubbles.dylib',
        root/'Library/MobileSubstrate/DynamicLibraries/MessengerBubbles.plist',
        root/'Library/PreferenceBundles/MessengerBubblesPrefs.bundle/MessengerBubblesPrefs',
        root/'Library/PreferenceLoader/Preferences/MessengerBubblesPrefs.plist',
    ]
    for r in required:
        if not r.is_file(): raise SystemExit(f'Missing original component {r}')
    injection=(root/'Library/MobileSubstrate/DynamicLibraries/MessengerBubbles.plist').read_bytes()
    if b'com.facebook.Messenger' not in injection or b'com.apple.springboard' not in injection:
        raise SystemExit('Unexpected injection filter in original DEB')
    original_hash=hashlib.sha256(required[0].read_bytes()).hexdigest()
    target=required[1]
    shutil.copy2(a.binary,target)
    target.chmod(0o755)
    version='0.0.6~viewport5reopen1+keyboarddbg1'
    info=re.sub(r'(?m)^Version:.*$',f'Version: {version}',info,count=1)
    if f'Version: {version}' not in info: raise SystemExit('Cannot change version')
    # Appending an extra field rather than altering potentially multiline Description.
    if 'X-Keyboard-Debug:' not in info:
        info+='\n' if not info.endswith('\n') else ''
        info+='X-Keyboard-Debug: UNTESTED-on-device\n'
    control.write_text(info)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    run('dpkg-deb','--build','-Zgzip',root,a.output)
    print('DEB:',a.output,'bytes:',a.output.stat().st_size)
    print('Engine SHA256 retained:',original_hash)
    print('New dylib SHA256:',hashlib.sha256(a.binary.read_bytes()).hexdigest())
    print('DEB SHA256:',hashlib.sha256(a.output.read_bytes()).hexdigest())
    print('STATUS: PACKAGED ONLY; NOT INSTALLED / NOT RUNTIME VALIDATED')
