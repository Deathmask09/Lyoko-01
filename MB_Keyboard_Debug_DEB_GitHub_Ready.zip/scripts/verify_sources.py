#!/usr/bin/env python3
"""Static project sanity check. This is not runtime verification."""
from pathlib import Path
import re

makefile = Path('Makefile').read_text()
match = re.search(r'MessengerBubbles_FILES\s*:=\s*(.*?)(?:\n\n)', makefile, re.S)
if not match:
    raise SystemExit('Missing MessengerBubbles_FILES in Makefile')
files = [x.strip() for x in match.group(1).replace('\\\n', ' ').split()]
if len(files) != 17 or len(files) != len(set(files)):
    raise SystemExit(f'Expected 17 unique compiled source files; got {len(files)}')
for fn in files:
    if not Path(fn).is_file():
        raise SystemExit(f'Source file missing: {fn}')
if not Path('Sources/MBSceneSizeRequestGate.h').is_file():
    raise SystemExit('Keyboard scene request gate header missing')
if 'MBSceneSizeRequestTicketAllows' not in Path('Sources/MBVendorAdapter.m').read_text():
    raise SystemExit('Expected keyboard scene request gate usage missing')
if 'THEOS_PACKAGE_SCHEME := roothide' not in makefile or 'ARCHS := arm64 arm64e' not in makefile:
    raise SystemExit('Unexpected RootHide or architecture configuration')
print(f'Static source check passed: {len(files)} compilation units; keyboard gate present')
