# MessengerBubbles Debug DEB – Không dùng Apelin

**Dự án này dành cho GitHub Actions chạy trên macOS/Xcode. Không thể chạy trực tiếp từ file ZIP bằng Sileo.**

- Source đã vá keyboard và Makefile: dùng lại từ gói đã gửi.
- `base/MessengerBubbles_viewport4frame2.deb`: DEB gốc đã cung cấp, dùng để giữ nguyên BubbleMe engine, Preferences, injection filter và metadata.
- `.github/workflows/build.yml`: chạy khi chọn **Actions → MessengerBubbles - Debug DEB RootHide (test only) → Run workflow**.
- `scripts/package_debug.py`: xác minh kiến trúc và ARM64e ABI rồi thay đúng adapter dylib trong bản DEB gốc, nâng version thành `0.0.6~viewport5reopen1+keyboarddbg1`, không cài.

**Giới hạn:** Chưa chạy workflow thực tế, chưa thử keyboard hay inject trên iPhone. Nếu GitHub Actions báo lỗi, workflow sẽ không xuất DEB. Nếu DEB được tạo, vẫn phải kiểm tra file và log trước khi cài lên SpringBoard. Không tải ZIP nguồn trực tiếp vào Sileo.

Tạo GitHub repo **Private**; giải nén ZIP và upload **các file bên trong**, bao gồm thư mục ẩn `.github`. Trong Safari bật chế độ trang desktop nếu cần. Để bảo vệ bản engine bên thứ ba, không đưa repo thành public hoặc phát tán DEB.
