// SPDX-License-Identifier: MIT
#import "MBMessengerDiagnostic.h"
#import <os/log.h>
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#if __has_feature(ptrauth_calls)
#include <ptrauth.h>
#endif

#define MB_CORE_RELATIVE_IMAGE "Frameworks/LightSpeedCore.framework/LightSpeedCore"
#define MB_IMAGE_SCAN_MAX 4096u

static BOOL MBCopyFactString(char *destination, size_t capacity, id value) {
    if (![value isKindOfClass:NSString.class]) return NO;
    return [value getCString:destination maxLength:capacity encoding:NSUTF8StringEncoding];
}
static BOOL MBCanonicalPath(const char *source, char destination[PATH_MAX]) {
    if (!source || source[0] != '/' || strnlen(source, PATH_MAX) == PATH_MAX) return NO;
    return realpath(source, destination) != NULL;
}
static BOOL MBAppendPath(char destination[PATH_MAX], const char *root, const char *relative) {
    int length = snprintf(destination, PATH_MAX, "%s/%s", root, relative);
    return length > 0 && length < PATH_MAX;
}

BOOL MBCollectMessengerProcessFacts(MBMessengerProcessFacts *facts, __unused void *context) {
    if (!facts) return NO;
    memset(facts, 0, sizeof(*facts));
    NSBundle *bundle = NSBundle.mainBundle;
    NSDictionary *info = bundle.infoDictionary; // nonlocalized main-bundle metadata, not app data
    if (!MBCopyFactString(facts->bundleIdentifier, sizeof(facts->bundleIdentifier), info[@"CFBundleIdentifier"]) ||
        !MBCopyFactString(facts->version, sizeof(facts->version), info[@"CFBundleShortVersionString"]) ||
        !MBCopyFactString(facts->build, sizeof(facts->build), info[@"CFBundleVersion"]) ||
        !MBCopyFactString(facts->packageType, sizeof(facts->packageType), info[@"CFBundlePackageType"]) ||
        !MBCopyFactString(facts->executableName, sizeof(facts->executableName), info[@"CFBundleExecutable"])) return NO;
    facts->isExtension = info[@"NSExtension"] != nil;
    if (!MBCanonicalPath(bundle.bundlePath.fileSystemRepresentation, facts->bundlePath) ||
        !MBCanonicalPath(bundle.executablePath.fileSystemRepresentation, facts->bundleExecutable) ||
        !MBCanonicalPath(_dyld_get_image_name(0), facts->mainExecutable)) return NO;
    const struct mach_header *mainHeader = _dyld_get_image_header(0);
    facts->mainIsExecutable = mainHeader && mainHeader->filetype == MH_EXECUTE;
    if (!MBAppendPath(facts->coreImagePath, facts->bundlePath, MB_CORE_RELATIVE_IMAGE)) return NO;
    uint32_t count = _dyld_image_count(); // bounded snapshot: no dlopen and no retry/polling
    if (count > MB_IMAGE_SCAN_MAX) {
        facts->coreImageState = MBMessengerImageLimit;
        return YES;
    }
    facts->coreImageState = MBMessengerImageAbsent;
    for (uint32_t i = 0; i < count; ++i) {
        char path[PATH_MAX];
        if (!MBCanonicalPath(_dyld_get_image_name(i), path)) continue;
        if (strcmp(path, facts->coreImagePath) != 0) continue;
        facts->coreImageHeader = _dyld_get_image_header(i);
        facts->coreImageState = facts->coreImageHeader ? MBMessengerImageLoaded : MBMessengerImageUnknown;
        break;
    }
    return YES;
}

static BOOL MBAddressIsInCore(const void *address, const MBMessengerProcessFacts *facts, BOOL *known) {
    Dl_info image = {0};
    char path[PATH_MAX];
    *known = address && dladdr(address, &image) != 0 && image.dli_fbase;
    // Shared-cache images may have no standalone file for realpath. A different
    // loaded base is already conclusive negative evidence; do not hide it.
    if (!*known || image.dli_fbase != facts->coreImageHeader) return NO;
    *known = MBCanonicalPath(image.dli_fname, path);
    return *known && strcmp(path, facts->coreImagePath) == 0;
}

MBMessengerMetadataStatus MBVerifyMessengerLoadedOrigin(void *classHandle, Method ownedMethod,
    const char *relativeImage, const MBMessengerProcessFacts *facts) {
    if (!facts || !classHandle || !relativeImage || strcmp(relativeImage, MB_CORE_RELATIVE_IMAGE) != 0 ||
        facts->coreImageState != MBMessengerImageLoaded || !facts->coreImageHeader) return MBMessengerMetadataImageUnavailable;
    __unsafe_unretained Class cls = (__bridge Class)classHandle;
    BOOL known = NO;
    if (!ownedMethod) {
        BOOL matched = MBAddressIsInCore(classHandle, facts, &known);
        if (!known) return MBMessengerMetadataImageUnavailable;
        if (!matched) return MBMessengerMetadataClassImageMismatch;
        char path[PATH_MAX];
        if (!MBCanonicalPath(class_getImageName(cls), path)) return MBMessengerMetadataImageUnavailable;
        return strcmp(path, facts->coreImagePath) == 0 ? MBMessengerMetadataContractMatch : MBMessengerMetadataClassImageMismatch;
    }
    IMP implementation = method_getImplementation(ownedMethod);
#if __has_feature(ptrauth_calls)
    const void *address = ptrauth_strip(implementation, ptrauth_key_function_pointer);
#else
    const void *address = (const void *)implementation;
#endif
    BOOL matched = MBAddressIsInCore(address, facts, &known);
    // A hook/trampoline in another image is unsupported; never remove it.
    return !known ? MBMessengerMetadataImageUnavailable :
        (matched ? MBMessengerMetadataContractMatch : MBMessengerMetadataIMPImageMismatch);
}

static BOOL MBFactsTerminated(const MBMessengerProcessFacts *facts) {
#define MB_TERMINATED(field) (memchr(facts->field, 0, sizeof(facts->field)) != NULL)
    return MB_TERMINATED(bundleIdentifier) && MB_TERMINATED(version) && MB_TERMINATED(build) &&
        MB_TERMINATED(packageType) && MB_TERMINATED(executableName) && MB_TERMINATED(bundlePath) &&
        MB_TERMINATED(bundleExecutable) && MB_TERMINATED(mainExecutable) && MB_TERMINATED(coreImagePath);
#undef MB_TERMINATED
}
static void MBSafeNumericMetadata(char destination[32], const char source[32]) {
    const char *end = memchr(source, 0, 32);
    if (!end || end == source) { strcpy(destination, "unknown"); return; }
    for (const char *cursor = source; cursor < end; ++cursor) {
        if ((*cursor < '0' || *cursor > '9') && *cursor != '.') { strcpy(destination, "invalid"); return; }
    }
    memcpy(destination, source, (size_t)(end - source) + 1);
}
static MBMessengerMetadataStatus MBValidateFacts(const MBMessengerProcessFacts *facts) {
    if (!MBFactsTerminated(facts)) return MBMessengerMetadataFactsUnavailable;
    if (strcmp(facts->bundleIdentifier, "com.facebook.Messenger") != 0) return MBMessengerMetadataBundleMismatch;
    char executable[PATH_MAX], core[PATH_MAX];
    size_t length = strlen(facts->bundlePath);
    if (facts->isExtension || !facts->mainIsExecutable || strcmp(facts->packageType, "APPL") != 0 ||
        strcmp(facts->executableName, "Messenger") != 0 || facts->bundlePath[0] != '/' ||
        length < 4 || strcmp(facts->bundlePath + length - 4, ".app") != 0 ||
        !MBAppendPath(executable, facts->bundlePath, "Messenger") ||
        strcmp(executable, facts->bundleExecutable) != 0 || strcmp(executable, facts->mainExecutable) != 0)
        return MBMessengerMetadataProcessMismatch;
    if (strcmp(facts->version, "579.0.0") != 0) return MBMessengerMetadataVersionMismatch;
    if (strcmp(facts->build, "1068430635") != 0) return MBMessengerMetadataBuildMismatch;
    if (!MBAppendPath(core, facts->bundlePath, MB_CORE_RELATIVE_IMAGE) || strcmp(core, facts->coreImagePath) != 0)
        return MBMessengerMetadataImageUnavailable;
    switch (facts->coreImageState) {
        case MBMessengerImageAbsent: return MBMessengerMetadataImageNotLoaded;
        case MBMessengerImageLimit: return MBMessengerMetadataImageScanLimit;
        case MBMessengerImageLoaded: return facts->coreImageHeader ? MBMessengerMetadataContractMatch : MBMessengerMetadataImageUnavailable;
        default: return MBMessengerMetadataImageUnavailable;
    }
}

typedef struct { const MBMessengerProcessFacts *facts; MBMessengerDiagnosticDependencies dependencies; } MBInspectionContext;
static void *MBLookupDiagnosticClass(const char *name, void *context) {
    MBInspectionContext *inspection = context;
    return inspection->dependencies.lookup ? inspection->dependencies.lookup(name, inspection->dependencies.context) :
        (__bridge void *)objc_lookUpClass(name);
}
static MBMessengerMetadataStatus MBCheckDiagnosticOrigin(void *handle, Method method, const char *relative, void *context) {
    MBInspectionContext *inspection = context;
    return inspection->dependencies.origin ? inspection->dependencies.origin(handle, method, relative, inspection->dependencies.context) :
        MBVerifyMessengerLoadedOrigin(handle, method, relative, inspection->facts);
}
MBMessengerDiagnosticReport MBEvaluateMessengerDiagnostic(MBMessengerDiagnosticDependencies dependencies) {
    MBMessengerDiagnosticReport report = { .metadata.status = MBMessengerMetadataFactsUnavailable, .version = "unknown", .build = "unknown" };
    @try {
        MBMessengerProcessFacts facts = {0};
        if (!dependencies.collect || !dependencies.collect(&facts, dependencies.context)) return report;
        MBSafeNumericMetadata(report.version, facts.version);
        MBSafeNumericMetadata(report.build, facts.build);
        report.metadata.status = MBValidateFacts(&facts);
        if (report.metadata.status != MBMessengerMetadataContractMatch) return report;
        MBInspectionContext inspection = { .facts = &facts, .dependencies = dependencies };
        report.metadata = MBCheckMessengerMetadataContractWithOrigins(MBMessengerMetadataMainApplication,
            facts.version, facts.build, MBLookupDiagnosticClass, MBCheckDiagnosticOrigin, &inspection);
    } @catch (__unused NSException *exception) {
        report.metadata = (MBMessengerMetadataResult){ .status = MBMessengerMetadataException };
    }
    return report;
}

BOOL MBQueueMessengerDiagnostic(MBMessengerDiagnosticOnce *once, MBMessengerDiagnosticDependencies dependencies) {
    if (!once || !dependencies.collect || !dependencies.enqueue || !dependencies.sink) return NO;
    unsigned expected = 0;
    if (!atomic_compare_exchange_strong(&once->phase, &expected, 1)) return NO;
    @try {
        dependencies.enqueue(^{
            unsigned queued = 1;
            if (!atomic_compare_exchange_strong(&once->phase, &queued, 2)) return;
            @autoreleasepool {
                @try {
                    MBMessengerDiagnosticReport report = MBEvaluateMessengerDiagnostic(dependencies);
                    dependencies.sink(&report, dependencies.context);
                } @catch (__unused NSException *exception) {
                    // Sink is trusted; never stringify an exception or retry an attempt.
                } @finally {
                    atomic_store(&once->phase, 3);
                }
            }
        }, dependencies.context);
    } @catch (__unused NSException *exception) {
        atomic_store(&once->phase, 3);
    }
    return YES;
}

const char *MBMessengerDiagnosticReason(MBMessengerMetadataStatus status) {
    switch (status) {
        case MBMessengerMetadataUnknownProcess: return "scope-unknown";
        case MBMessengerMetadataVersionMismatch: return "version-mismatch";
        case MBMessengerMetadataBuildMismatch: return "build-mismatch";
        case MBMessengerMetadataClassMissing: return "class-missing";
        case MBMessengerMetadataInstanceMethodMissing: return "owned-instance-method-missing";
        case MBMessengerMetadataABIMismatch: return "abi-mismatch";
        case MBMessengerMetadataContractMatch: return "metadata-only-match";
        case MBMessengerMetadataClassImageMismatch: return "class-image-mismatch";
        case MBMessengerMetadataIMPImageMismatch: return "imp-image-mismatch";
        case MBMessengerMetadataImageUnavailable: return "image-unavailable";
        case MBMessengerMetadataInspectionLimit: return "method-inspection-limit";
        case MBMessengerMetadataFactsUnavailable: return "facts-unavailable";
        case MBMessengerMetadataBundleMismatch: return "bundle-mismatch";
        case MBMessengerMetadataProcessMismatch: return "main-process-mismatch";
        case MBMessengerMetadataImageNotLoaded: return "image-not-loaded";
        case MBMessengerMetadataImageScanLimit: return "image-scan-limit";
        case MBMessengerMetadataException: return "inspection-exception";
    }
    return "unknown-status";
}
const char *MBMessengerDiagnosticDisposition(MBMessengerMetadataStatus status) {
    switch (status) {
        case MBMessengerMetadataContractMatch: return "metadata-match";
        case MBMessengerMetadataImageUnavailable:
        case MBMessengerMetadataInspectionLimit:
        case MBMessengerMetadataFactsUnavailable:
        case MBMessengerMetadataImageNotLoaded:
        case MBMessengerMetadataImageScanLimit:
        case MBMessengerMetadataException: return "inconclusive";
        default: return "unsupported";
    }
}
static void MBLogDiagnostic(const MBMessengerDiagnosticReport *report, __unused void *context) {
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "messenger-diagnostic"); });
    os_log(log, "MBMessengerDiagnostic scope=main feature=metadata version=%{public}s build=%{public}s result=%{public}s reason=%{public}s",
        report->version, report->build, MBMessengerDiagnosticDisposition(report->metadata.status), MBMessengerDiagnosticReason(report->metadata.status));
}
static void MBEnqueueDiagnostic(dispatch_block_t work, __unused void *context) {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), work);
}
void MBStartPassiveMessengerDiagnostic(void) {
    static MBMessengerDiagnosticOnce once = MB_MESSENGER_DIAGNOSTIC_ONCE_INIT;
    MBQueueMessengerDiagnostic(&once, (MBMessengerDiagnosticDependencies){
        .collect = MBCollectMessengerProcessFacts, .sink = MBLogDiagnostic, .enqueue = MBEnqueueDiagnostic,
    });
}
