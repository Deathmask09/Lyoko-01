// SPDX-License-Identifier: MIT
#import "MBHybridAvatarCache.h"
#import <dispatch/dispatch.h>
#include <math.h>
#include <stdint.h>

static const NSUInteger MBHybridAvatarLoadLimit = 16;
static const NSUInteger MBHybridAvatarSubscriberLimit = 64;
static const size_t MBHybridAvatarPixelLimit = 512;
static const NSTimeInterval MBHybridAvatarTimeout = 10.0;

static void MBHybridAvatarRequireMain(void) {
    NSCAssert([NSThread isMainThread], @"Avatar cache is main-queue-only");
}

// Also used for the decoded raster. Do not multiply before checking overflow.
static BOOL MBHybridAvatarRasterCost(size_t width, size_t height, size_t row,
                                    size_t bitsPerPixel, NSUInteger *cost) {
    if (!width || !height || width > MBHybridAvatarPixelLimit ||
        height > MBHybridAvatarPixelLimit || !row || !bitsPerPixel) return NO;
    if (bitsPerPixel > (SIZE_MAX - 7) / width) return NO;
    size_t minimumRow = (width * bitsPerPixel + 7) / 8;
    if (row < minimumRow || row > NSUIntegerMax / height) return NO;
    if (cost) *cost = (NSUInteger)(row * height);
    return YES;
}

static BOOL MBHybridAvatarInputIsValid(UIImage *image, NSUInteger ceiling) {
    if (![image isKindOfClass:UIImage.class] || image.images.count ||
        !isfinite(image.scale) || image.scale <= 0) return NO;
    CGImageRef raster = image.CGImage;
    if (!raster || CGImageIsMask(raster)) return NO; // No CI-only or animated input.
    NSUInteger cost = 0;
    return MBHybridAvatarRasterCost(CGImageGetWidth(raster), CGImageGetHeight(raster),
        CGImageGetBytesPerRow(raster), CGImageGetBitsPerPixel(raster), &cost) && cost <= ceiling;
}

static UIImage *MBHybridAvatarDecode(UIImage *image, NSUInteger ceiling, NSUInteger *cost) {
    if (!MBHybridAvatarInputIsValid(image, ceiling)) return nil;
    CGImageRef input = image.CGImage;
    size_t width = CGImageGetWidth(input), height = CGImageGetHeight(input);
    NSUInteger outputCost = 0;
    if (width > SIZE_MAX / 4 ||
        !MBHybridAvatarRasterCost(width, height, width * 4, 32, &outputCost) ||
        outputCost > ceiling) return nil;
    CGColorSpaceRef color = CGColorSpaceCreateDeviceRGB();
    if (!color) return nil;
    CGContextRef context = CGBitmapContextCreate(NULL, width, height, 8, width * 4, color,
        (CGBitmapInfo)(kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big));
    CGColorSpaceRelease(color);
    if (!context) return nil;
    CGContextSetBlendMode(context, kCGBlendModeCopy);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), input);
    CGImageRef decoded = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    if (!decoded) return nil;
    BOOL valid = MBHybridAvatarRasterCost(CGImageGetWidth(decoded), CGImageGetHeight(decoded),
        CGImageGetBytesPerRow(decoded), CGImageGetBitsPerPixel(decoded), &outputCost);
    UIImage *result = nil;
    if (valid && outputCost <= ceiling) {
        result = [UIImage imageWithCGImage:decoded scale:image.scale orientation:image.imageOrientation];
        if (result && cost) *cost = outputCost;
    }
    CGImageRelease(decoded);
    return result;
}

static void MBHybridAvatarCancelSource(id<MBHybridAvatarTask> task) {
    // Invalidate our state BEFORE calling an external, potentially reentrant task.
    @try { [task cancel]; } @catch (__unused NSException *exception) { }
}

@class MBHybridAvatarFlight, MBHybridAvatarEntry, MBHybridAvatarSubscription;

@interface MBHybridAvatarCache (MBHybridAvatarPrivate)
- (void)mb_cancelSubscription:(MBHybridAvatarSubscription *)subscription;
- (void)mb_deliverSubscription:(MBHybridAvatarSubscription *)subscription;
- (void)mb_finishFlight:(MBHybridAvatarFlight *)flight;
- (void)mb_timeoutFlight:(MBHybridAvatarFlight *)flight;
@end

// This is the only cross-queue state. A source retains this gate, NOT the cache,
// flight, its task or a client callback. At most one source reply can be queued.
// Invalidation releases even an accepted-but-not-yet-processed source image.
@interface MBHybridAvatarReplyGate : NSObject {
    BOOL _closed;
    BOOL _received;
    UIImage *_image;
}
- (BOOL)offerImage:(UIImage *)image;
- (UIImage *)takeImage;
- (void)invalidate;
@end
@implementation MBHybridAvatarReplyGate
- (BOOL)offerImage:(UIImage *)image {
    @synchronized (self) {
        if (_closed || _received) return NO;
        _received = YES;
        _image = image;
        return YES;
    }
}
- (UIImage *)takeImage {
    @synchronized (self) {
        _closed = YES;
        UIImage *image = _image;
        _image = nil;
        return image;
    }
}
- (void)invalidate {
    @synchronized (self) { _closed = YES; _image = nil; }
}
@end

@interface MBHybridAvatarEntry : NSObject
@property(nonatomic, copy) NSString *key;
@property(nonatomic, strong) UIImage *image;
@property(nonatomic) NSUInteger cost;
@end
@implementation MBHybridAvatarEntry
@end

@interface MBHybridAvatarSubscription : NSObject <MBHybridAvatarTask>
@property(nonatomic, weak) MBHybridAvatarCache *cache;
@property(nonatomic, weak) MBHybridAvatarFlight *flight;
@property(nonatomic, weak) MBHybridAvatarEntry *entry;
@property(nonatomic, copy) MBHybridAvatarReply reply;
@property(nonatomic) BOOL scheduled;
@property(nonatomic) BOOL finished;
@end
@implementation MBHybridAvatarSubscription
- (void)cancel {
    MBHybridAvatarRequireMain();
    [self.cache mb_cancelSubscription:self];
}
@end

@interface MBHybridAvatarFlight : NSObject
@property(nonatomic, copy) NSString *key;
@property(nonatomic, strong) NSMutableArray<MBHybridAvatarSubscription *> *subscriptions;
@property(nonatomic, strong) MBHybridAvatarReplyGate *gate;
@property(nonatomic, strong) id<MBHybridAvatarTask> task;
@property(nonatomic, strong) dispatch_source_t timer;
@property(nonatomic) NSTimeInterval deadline;
@property(nonatomic) BOOL active;
@end
@implementation MBHybridAvatarFlight
@end

@implementation MBHybridAvatarCache {
    id<MBHybridAvatarSource> _source;
    NSUInteger _costLimit;
    NSUInteger _maxEntries;
    NSUInteger _residentCost;
    NSMutableDictionary<NSString *, MBHybridAvatarEntry *> *_entries;
    NSMutableArray<MBHybridAvatarEntry *> *_lru; // Oldest first; bounded by maxEntries.
    NSMutableDictionary<NSString *, MBHybridAvatarFlight *> *_flights;
    NSMutableSet<MBHybridAvatarSubscription *> *_subscriptions;
    id _memoryObserver;
    BOOL _purging;
}

- (instancetype)initWithSource:(id<MBHybridAvatarSource>)source
                    costLimit:(NSUInteger)bytes maxEntries:(NSUInteger)entries {
    MBHybridAvatarRequireMain();
    NSParameterAssert(source);
    self = [super init];
    if (self) {
        _source = source;
        _costLimit = bytes;
        _maxEntries = entries;
        _entries = [NSMutableDictionary new];
        _lru = [NSMutableArray new];
        _flights = [NSMutableDictionary new];
        _subscriptions = [NSMutableSet new];
        __weak MBHybridAvatarCache *weakCache = self;
        _memoryObserver = [NSNotificationCenter.defaultCenter
            addObserverForName:UIApplicationDidReceiveMemoryWarningNotification object:nil queue:nil
            usingBlock:^(__unused NSNotification *note) {
                if ([NSThread isMainThread]) [weakCache purge];
                else dispatch_async(dispatch_get_main_queue(), ^{ [weakCache purge]; });
            }];
    }
    return self;
}

- (BOOL)mb_isCurrentFlight:(MBHybridAvatarFlight *)flight {
    return flight && flight.active && _flights[flight.key] == flight;
}

- (void)mb_enqueueSubscription:(MBHybridAvatarSubscription *)subscription
                        entry:(MBHybridAvatarEntry *)entry {
    if (subscription.finished || subscription.scheduled) return;
    subscription.entry = entry; // Weak: a queued delivery must not pin evicted RAM.
    subscription.scheduled = YES;
    __weak MBHybridAvatarCache *weakCache = self;
    __weak MBHybridAvatarSubscription *weakSubscription = subscription;
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakCache mb_deliverSubscription:weakSubscription];
    });
}

- (void)mb_clearSubscription:(MBHybridAvatarSubscription *)subscription {
    subscription.finished = YES;
    subscription.reply = nil;
    subscription.entry = nil;
    subscription.flight = nil;
    subscription.cache = nil;
    [_subscriptions removeObject:subscription];
}

- (void)mb_deliverSubscription:(MBHybridAvatarSubscription *)subscription {
    MBHybridAvatarRequireMain();
    if (!subscription || subscription.finished || ![_subscriptions containsObject:subscription]) return;
    MBHybridAvatarReply reply = subscription.reply;
    UIImage *image = subscription.entry.image;
    [self mb_clearSubscription:subscription]; // Clear ownership before client reentry.
    if (reply) reply(image);
}

// No external calls here. Callers decide whether to cancel the returned source task.
- (id<MBHybridAvatarTask>)mb_detachFlight:(MBHybridAvatarFlight *)flight {
    flight.active = NO;
    if (_flights[flight.key] == flight) [_flights removeObjectForKey:flight.key];
    [flight.gate invalidate];
    if (flight.timer) { dispatch_source_cancel(flight.timer); flight.timer = nil; }
    id<MBHybridAvatarTask> task = flight.task;
    flight.task = nil;
    return task;
}

- (void)mb_cancelSubscription:(MBHybridAvatarSubscription *)subscription {
    MBHybridAvatarRequireMain();
    if (subscription.finished || ![_subscriptions containsObject:subscription]) return;
    MBHybridAvatarFlight *flight = subscription.flight;
    [self mb_clearSubscription:subscription];
    [flight.subscriptions removeObjectIdenticalTo:subscription];
    if ([self mb_isCurrentFlight:flight] && !flight.subscriptions.count)
        MBHybridAvatarCancelSource([self mb_detachFlight:flight]);
}

- (MBHybridAvatarEntry *)mb_storeImage:(UIImage *)image key:(NSString *)key cost:(NSUInteger)cost {
    if (!image || !cost || !_maxEntries || cost > _costLimit) return nil;
    // Subtraction avoids total+cost overflow even with a caller's NSUIntegerMax budget.
    while (_lru.count && (_entries.count >= _maxEntries || _residentCost > _costLimit - cost)) {
        MBHybridAvatarEntry *oldest = _lru.firstObject;
        _residentCost -= oldest.cost;
        [_entries removeObjectForKey:oldest.key];
        [_lru removeObjectAtIndex:0];
    }
    MBHybridAvatarEntry *entry = [MBHybridAvatarEntry new];
    entry.key = key;
    entry.image = image;
    entry.cost = cost;
    _entries[key] = entry;
    [_lru addObject:entry];
    _residentCost += cost;
    return entry;
}

- (void)mb_finishFlight:(MBHybridAvatarFlight *)flight {
    MBHybridAvatarRequireMain();
    if (![self mb_isCurrentFlight:flight]) return;
    if (NSProcessInfo.processInfo.systemUptime >= flight.deadline) {
        [self mb_timeoutFlight:flight];
        return;
    }
    UIImage *input = [flight.gate takeImage];
    NSUInteger cost = 0;
    UIImage *decoded = MBHybridAvatarDecode(input, _costLimit, &cost);
    MBHybridAvatarEntry *entry = [self mb_storeImage:decoded key:flight.key cost:cost];
    (void)[self mb_detachFlight:flight]; // Completed tasks are released, not cancelled.
    NSArray<MBHybridAvatarSubscription *> *subscriptions = [flight.subscriptions copy];
    [flight.subscriptions removeAllObjects];
    for (MBHybridAvatarSubscription *subscription in subscriptions) {
        subscription.flight = nil;
        [self mb_enqueueSubscription:subscription entry:entry];
    }
}

- (void)mb_timeoutFlight:(MBHybridAvatarFlight *)flight {
    MBHybridAvatarRequireMain();
    if (![self mb_isCurrentFlight:flight]) return;
    id<MBHybridAvatarTask> task = [self mb_detachFlight:flight];
    NSArray<MBHybridAvatarSubscription *> *subscriptions = [flight.subscriptions copy];
    [flight.subscriptions removeAllObjects];
    for (MBHybridAvatarSubscription *subscription in subscriptions) {
        subscription.flight = nil;
        [self mb_enqueueSubscription:subscription entry:nil];
    }
    MBHybridAvatarCancelSource(task);
}

- (id<MBHybridAvatarTask>)requestKey:(NSString *)key completion:(MBHybridAvatarReply)completion {
    MBHybridAvatarRequireMain();
    MBHybridAvatarSubscription *subscription = [MBHybridAvatarSubscription new];
    if (!completion || _purging || _subscriptions.count >= MBHybridAvatarSubscriberLimit) {
        subscription.finished = YES; // Hard admission cap: never retain rejected callbacks.
        return subscription;
    }
    subscription.cache = self;
    subscription.reply = completion;
    [_subscriptions addObject:subscription];
    if (![key isKindOfClass:NSString.class] || key.length < 1 || key.length > 512 ||
        !_costLimit || !_maxEntries) {
        [self mb_enqueueSubscription:subscription entry:nil];
        return subscription;
    }
    NSString *stableKey = [key copy]; // Mutable input may change after request returns.
    if (!stableKey.length || stableKey.length > 512) {
        [self mb_enqueueSubscription:subscription entry:nil];
        return subscription;
    }
    MBHybridAvatarEntry *entry = _entries[stableKey];
    if (entry) {
        [_lru removeObjectIdenticalTo:entry];
        [_lru addObject:entry];
        [self mb_enqueueSubscription:subscription entry:entry];
        return subscription;
    }
    MBHybridAvatarFlight *flight = _flights[stableKey];
    if (flight) {
        [flight.subscriptions addObject:subscription];
        subscription.flight = flight;
        return subscription;
    }
    if (_flights.count >= MBHybridAvatarLoadLimit) {
        [self mb_enqueueSubscription:subscription entry:nil];
        return subscription;
    }
    flight = [MBHybridAvatarFlight new];
    flight.key = stableKey;
    flight.active = YES;
    flight.deadline = NSProcessInfo.processInfo.systemUptime + MBHybridAvatarTimeout;
    flight.gate = [MBHybridAvatarReplyGate new];
    flight.subscriptions = [NSMutableArray arrayWithObject:subscription];
    subscription.flight = flight;
    _flights[stableKey] = flight;

    __weak MBHybridAvatarCache *weakCache = self;
    __weak MBHybridAvatarFlight *weakFlight = flight;
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,
                                                      dispatch_get_main_queue());
    flight.timer = timer;
    dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW,
        (int64_t)(MBHybridAvatarTimeout * NSEC_PER_SEC)), DISPATCH_TIME_FOREVER, NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer, ^{ [weakCache mb_timeoutFlight:weakFlight]; });
    dispatch_activate(timer);

    MBHybridAvatarReplyGate *gate = flight.gate;
    NSUInteger ceiling = _costLimit;
    MBHybridAvatarReply sourceReply = ^(UIImage *image) {
        UIImage *accepted = MBHybridAvatarInputIsValid(image, ceiling) ? image : nil;
        if (![gate offerImage:accepted]) return;
        // No image or strong cache/flight/task captured in this queued block.
        dispatch_async(dispatch_get_main_queue(), ^{ [weakCache mb_finishFlight:weakFlight]; });
    };
    id<MBHybridAvatarTask> task = nil;
    @try { task = [_source loadAvatarForKey:stableKey completion:sourceReply]; }
    @catch (__unused NSException *exception) { sourceReply(nil); }
    // Handles synchronous source replies AND reentrant purge/last-subscriber cancel.
    if ([self mb_isCurrentFlight:flight]) flight.task = task;
    else MBHybridAvatarCancelSource(task);
    return subscription;
}

- (void)purge {
    MBHybridAvatarRequireMain();
    if (_purging) return;
    _purging = YES;
    for (MBHybridAvatarSubscription *subscription in [_subscriptions allObjects])
        [self mb_clearSubscription:subscription];
    NSArray<MBHybridAvatarFlight *> *flights = [_flights allValues];
    NSMutableArray<id<MBHybridAvatarTask>> *tasks = [NSMutableArray new];
    for (MBHybridAvatarFlight *flight in flights) {
        id<MBHybridAvatarTask> task = [self mb_detachFlight:flight];
        [flight.subscriptions removeAllObjects];
        if (task) [tasks addObject:task];
    }
    [_entries removeAllObjects];
    [_lru removeAllObjects];
    _residentCost = 0;
    for (id<MBHybridAvatarTask> task in tasks) MBHybridAvatarCancelSource(task);
    _purging = NO;
}

- (void)dealloc {
    if (_memoryObserver) [NSNotificationCenter.defaultCenter removeObserver:_memoryObserver];
    [self purge];
}
@end
