// SPDX-License-Identifier: MIT
#import "MBEngineArtwork.h"
#import "MBRuntime.h"
#import <objc/message.h>

id MBReadMessengerArtwork(Class provider, id iconModel) {
    NSString *bundle = MBReadBoundedString(iconModel, sel_registerName("applicationBundleID"), 255);
    if (!provider || ![bundle isEqualToString:@"com.facebook.Messenger"]) return nil;
    const char *object[] = {"@"};
    SEL setBundle = sel_registerName("setBundleIdentifier:");
    SEL setIcon = sel_registerName("setSbIcon:");
    SEL readIcon = sel_registerName("icon");
    if (!MBMethodMatches(provider, setBundle, "v", 1, object) ||
        !MBMethodMatches(provider, setIcon, "v", 1, object) ||
        !MBMethodMatches(provider, readIcon, "@", 0, NULL)) return nil;
    @try {
        id info = [provider new];
        ((void (*)(id, SEL, id))objc_msgSend)(info, setBundle, @"com.facebook.Messenger");
        ((void (*)(id, SEL, id))objc_msgSend)(info, setIcon, iconModel);
        return MBReadObject(info, readIcon);
    } @catch (__unused NSException *exception) { return nil; }
}
