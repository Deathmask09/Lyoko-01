// SPDX-License-Identifier: MIT
#import "MBSceneHostDiagnostic.h"
#import "MBSceneDiagnosticReadout.h"
#import "MBRuntime.h"
#import <os/log.h>
#include <dlfcn.h>
#include <crt_externs.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/mach.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#if __has_feature(ptrauth_calls)
#include <ptrauth.h>
#endif

#define MB_SH_METHOD(feature_, class_, selector_, result_, count_, image_, ...) \
    { .feature = feature_, .className = class_, .selectorName = selector_, .returnType = result_, \
      .argumentTypes = {__VA_ARGS__}, .argumentCount = count_, .image = image_, .kind = MBSceneHostInstanceMethod }
#define MB_SH_CLASS_METHOD(feature_, class_, selector_, result_, count_, image_, ...) \
    { .feature = feature_, .className = class_, .selectorName = selector_, .returnType = result_, \
      .argumentTypes = {__VA_ARGS__}, .argumentCount = count_, .image = image_, .kind = MBSceneHostClassMethod }
#define MB_SH_REFERENCE_METHOD(feature_, class_, selector_, result_, count_, image_, kind_, ...) \
    { .feature = feature_, .className = class_, .selectorName = selector_, .returnType = result_, \
      .argumentTypes = {__VA_ARGS__}, .argumentCount = count_, .image = image_, .kind = kind_, .referenceOnly = YES }
#define MB_SH_PROTOCOL(feature_, protocol_, selector_, count_, ...) \
    { .feature = feature_, .className = protocol_, .selectorName = selector_, .returnType = "v", \
      .argumentTypes = {__VA_ARGS__}, .argumentCount = count_, .kind = MBSceneHostProtocolInstanceMethod }

// 16.5/20F66 metadata supplied by independent Foundation helpers V1 and V2.
// They never called candidates or obtained a live scene. Observed declaration
// metadata is not callability, observer queue/order or host/input semantics.
static const MBSceneHostContract MBSceneCatalog[] = {
    { .feature = "context-host-init", .className = "_UIContextLayerHostView", .selectorName = "initWithSceneLayer:",
      .returnType = "@", .argumentTypes = {"@"}, .argumentCount = 1, .image = MBSceneHostUIKitCore,
      .superclassName = "_UISceneLayerHostView" },
    MB_SH_METHOD("context-host-resizes", "_UIContextLayerHostView", "setResizesHostedContext:", "v", 1, MBSceneHostUIKitCore, "B"),
    MB_SH_METHOD("layer-host-layer", "_UISceneLayerHostView", "sceneLayer", "@", 0, MBSceneHostUIKitCore, NULL),
    MB_SH_METHOD("layer-host-hit-test", "_UISceneLayerHostView", "hitTest:withEvent:", "@", 2, MBSceneHostUIKitCore, "{CGPoint=dd}", "@"),
    MB_SH_METHOD("layer-host-presentation", "_UISceneLayerHostView", "setCurrentPresentationContext:", "v", 1, MBSceneHostUIKitCore, "@"),
    MB_SH_METHOD("external-host-init", "_UIExternalSceneLayerHostView", "initWithSceneLayer:parentScene:", "@", 2, MBSceneHostUIKitCore, "@", "@"),
    MB_SH_METHOD("external-host-target", "_UIExternalSceneLayerHostView", "targetScene", "@", 0, MBSceneHostUIKitCore, NULL),
    MB_SH_METHOD("scene-layer-manager", "FBScene", "layerManager", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("scene-settings", "FBScene", "settings", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("scene-client-settings", "FBScene", "clientSettings", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("scene-update-settings", "FBScene", "updateSettings:withTransitionContext:completion:", "v", 3, MBSceneHostFrontBoard, "@", "@", "@?"),
    MB_SH_METHOD("scene-observer-add", "FBScene", "addObserver:", "v", 1, MBSceneHostFrontBoard, "@"),
    MB_SH_METHOD("scene-observer-remove", "FBScene", "removeObserver:", "v", 1, MBSceneHostFrontBoard, "@"),
    MB_SH_METHOD("scene-update-block", "FBScene", "updateSettingsWithBlock:", "v", 1, MBSceneHostFrontBoard, "@?"),
    MB_SH_METHOD("scene-process", "FBScene", "clientProcess", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("process-bundle", "FBProcess", "bundleIdentifier", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("process-application", "FBProcess", "isApplicationProcess", "B", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("process-identity", "FBProcess", "identity", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("manager-layers", "FBSceneLayerManager", "layers", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("manager-observer-add", "FBSceneLayerManager", "addObserver:", "v", 1, MBSceneHostFrontBoard, "@"),
    MB_SH_METHOD("manager-observer-remove", "FBSceneLayerManager", "removeObserver:", "v", 1, MBSceneHostFrontBoard, "@"),
    MB_SH_METHOD("manager-scene", "FBSceneLayerManager", "scene", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("manager-layer-context", "FBSceneLayerManager", "layerWithContextID:", "@", 1, MBSceneHostFrontBoard, "I"),
    MB_SH_METHOD("layer-context-id", "FBSceneLayer", "contextID", "I", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("layer-scene-id", "FBSceneLayer", "sceneID", "I", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("layer-external-id", "FBSceneLayer", "externalSceneID", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("layer-keyboard", "FBSceneLayer", "isKeyboardLayer", "B", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("layer-keyboard-proxy", "FBSceneLayer", "isKeyboardProxyLayer", "B", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("layer-level", "FBSceneLayer", "level", "d", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_CLASS_METHOD("manager-shared", "FBSceneManager", "sharedInstance", "@", 0, MBSceneHostFrontBoard, NULL),
    MB_SH_METHOD("scene-manager-by-id", "FBSceneManager", "sceneWithIdentifier:", "@", 1, MBSceneHostFrontBoard, "@"),
    MB_SH_METHOD("scene-manager-enumerate", "FBSceneManager", "enumerateScenesWithBlock:", "v", 1, MBSceneHostFrontBoard, "@?"),
    MB_SH_METHOD("scene-manager-test", "FBSceneManager", "scenesPassingTest:", "@", 1, MBSceneHostFrontBoard, "@?"),
    MB_SH_METHOD("settings-foreground", "FBSSceneSettings", "isForeground", "B", 0, MBSceneHostFrontBoardServices, NULL),
    MB_SH_METHOD("settings-backgrounded", "FBSSceneSettings", "isBackgrounded", "B", 0, MBSceneHostFrontBoardServices, NULL),
    MB_SH_METHOD("settings-frame", "FBSSceneSettings", "frame", "{CGRect={CGPoint=dd}{CGSize=dd}}", 0, MBSceneHostFrontBoardServices, NULL),
    MB_SH_METHOD("settings-orientation", "FBSSceneSettings", "interfaceOrientation", "q", 0, MBSceneHostFrontBoardServices, NULL),
    MB_SH_METHOD("settings-level", "FBSSceneSettings", "level", "d", 0, MBSceneHostFrontBoardServices, NULL),
    MB_SH_METHOD("mutable-foreground", "FBSMutableSceneSettings", "setForeground:", "v", 1, MBSceneHostFrontBoardServices, "B"),
    MB_SH_METHOD("mutable-backgrounded", "FBSMutableSceneSettings", "setBackgrounded:", "v", 1, MBSceneHostFrontBoardServices, "B"),
    MB_SH_METHOD("mutable-frame", "FBSMutableSceneSettings", "setFrame:", "v", 1, MBSceneHostFrontBoardServices, "{CGRect={CGPoint=dd}{CGSize=dd}}"),
    MB_SH_METHOD("mutable-orientation", "FBSMutableSceneSettings", "setInterfaceOrientation:", "v", 1, MBSceneHostFrontBoardServices, "q"),
    MB_SH_METHOD("mutable-level", "FBSMutableSceneSettings", "setLevel:", "v", 1, MBSceneHostFrontBoardServices, "d"),
    MB_SH_PROTOCOL("layers-updated", "FBSceneLayerManagerObserver", "sceneLayerManagerDidUpdateLayers:", 1, "@"),
    MB_SH_PROTOCOL("layers-start", "FBSceneLayerManagerObserver", "sceneLayerManagerDidStartTrackingLayers:", 1, "@"),
    MB_SH_PROTOCOL("layers-stop", "FBSceneLayerManagerObserver", "sceneLayerManagerDidStopTrackingLayers:", 1, "@"),
    MB_SH_PROTOCOL("scene-invalidated", "FBSceneObserver", "sceneDidInvalidate:", 1, "@"),
    MB_SH_PROTOCOL("scene-deactivate", "FBSceneObserver", "sceneWillDeactivate:withError:", 2, "@", "@"),
    MB_SH_PROTOCOL("client-settings", "FBSceneObserver", "scene:didUpdateClientSettingsWithDiff:oldClientSettings:transitionContext:", 4, "@", "@", "@", "@"),
    MB_SH_PROTOCOL("scene-update-complete", "FBSceneObserver", "scene:didCompleteUpdateWithContext:error:", 3, "@", "@", "@"),
    MB_SH_PROTOCOL("scene-activate", "FBSceneObserver", "sceneDidActivate:", 1, "@"),
    MB_SH_PROTOCOL("scene-content-state", "FBSceneObserver", "sceneContentStateDidChange:", 1, "@"),
    MB_SH_PROTOCOL("scene-manager-added", "FBSceneManagerObserver", "sceneManager:didAddScene:", 2, "@", "@"),
    MB_SH_PROTOCOL("scene-manager-created", "FBSceneManagerObserver", "sceneManager:didCreateScene:", 2, "@", "@"),
    MB_SH_PROTOCOL("scene-manager-removing", "FBSceneManagerObserver", "sceneManager:willRemoveScene:", 2, "@", "@"),
    MB_SH_PROTOCOL("scene-manager-destroying", "FBSceneManagerObserver", "sceneManager:willDestroyScene:", 2, "@", "@"),
    MB_SH_PROTOCOL("scene-manager-destroyed", "FBSceneManagerObserver", "sceneManager:didDestroyScene:", 2, "@", "@"),
    MB_SH_PROTOCOL("scene-manager-update", "FBSceneManagerObserver", "sceneManager:updateForScene:completedWithContext:error:", 4, "@", "@", "@", "@"),
    MB_SH_PROTOCOL("scene-manager-created-client", "FBSceneManagerObserver", "sceneManager:didCreateScene:withClient:", 3, "@", "@", "@"),
    // Remaining rows are still iOS 17 references, not observed 16.5 metadata.
    // No actual scene, process identity, frame or keyboard instance is read.
    MB_SH_REFERENCE_METHOD("reference-scene-identifier", "FBScene", "identifier", "@", 0, MBSceneHostFrontBoard, MBSceneHostInstanceMethod, NULL),
    MB_SH_REFERENCE_METHOD("reference-scene-identity", "FBScene", "identity", "@", 0, MBSceneHostFrontBoard, MBSceneHostInstanceMethod, NULL),
    MB_SH_REFERENCE_METHOD("reference-scene-valid", "FBScene", "isValid", "B", 0, MBSceneHostFrontBoard, MBSceneHostInstanceMethod, NULL),
    MB_SH_REFERENCE_METHOD("reference-scene-active", "FBScene", "isActive", "B", 0, MBSceneHostFrontBoard, MBSceneHostInstanceMethod, NULL),
    MB_SH_REFERENCE_METHOD("reference-identity-identifier", "FBSSceneIdentity", "identifier", "@", 0, MBSceneHostFrontBoardServices, MBSceneHostInstanceMethod, NULL),
    MB_SH_REFERENCE_METHOD("reference-process-extension", "FBProcess", "isExtensionProcess", "B", 0, MBSceneHostFrontBoard, MBSceneHostInstanceMethod, NULL),
    MB_SH_REFERENCE_METHOD("reference-keyboard-scene", "FBSceneManager", "keyboardScene", "@", 0, MBSceneHostFrontBoard, MBSceneHostClassMethod, NULL),
};
#undef MB_SH_METHOD
#undef MB_SH_CLASS_METHOD
#undef MB_SH_REFERENCE_METHOD
#undef MB_SH_PROTOCOL
_Static_assert(sizeof(MBSceneCatalog) / sizeof(MBSceneCatalog[0]) <= MB_SCENE_HOST_CATALOG_MAX, "Bound diagnostic rows");
_Static_assert(sizeof(MBSceneCatalog) / sizeof(MBSceneCatalog[0]) + MB_SCENE_HOST_LOG_OVERHEAD <= MB_SCENE_HOST_LOG_LINE_MAX, "Bound diagnostic lines including progress");

size_t MBSceneHostCatalogCount(void) { return sizeof(MBSceneCatalog) / sizeof(MBSceneCatalog[0]); }
const MBSceneHostContract *MBSceneHostCatalogItem(size_t index) {
    return index < MBSceneHostCatalogCount() ? &MBSceneCatalog[index] : NULL;
}
const char *MBSceneHostExpectedImage(MBSceneHostImage image) {
    switch (image) {
        case MBSceneHostUIKitCore: return "/System/Library/PrivateFrameworks/UIKitCore.framework/UIKitCore";
        case MBSceneHostFrontBoard: return "/System/Library/PrivateFrameworks/FrontBoard.framework/FrontBoard";
        case MBSceneHostFrontBoardServices: return "/System/Library/PrivateFrameworks/FrontBoardServices.framework/FrontBoardServices";
        default: return NULL;
    }
}

BOOL MBSceneMainImageObservationIsValid(MBSceneMainImageObservation o) {
    if (o.headerRead > MBSceneMainHeaderCopied || o.magic > MBSceneMainMagicOther ||
        o.fileType > MBSceneMainTypeOther || o.bundleExecutablePath > MBSceneMainPathMismatch ||
        o.mainExecutablePath > MBSceneMainPathMismatch || o.bundleLocation > MBSceneMainPathMismatch) return NO;
    if (o.headerRead == MBSceneMainHeaderCopied) {
        if (o.magic == MBSceneMainMagicUnobserved || o.fileType == MBSceneMainTypeUnobserved) return NO;
    } else if (o.magic != MBSceneMainMagicUnobserved || o.fileType != MBSceneMainTypeUnobserved) return NO;
    if (o.headerRead == MBSceneMainHeaderUnobserved && (o.bundleExecutablePath != MBSceneMainPathUnobserved ||
        o.mainExecutablePath != MBSceneMainPathUnobserved || o.bundleLocation != MBSceneMainPathUnobserved)) return NO;
    return YES;
}
MBSceneMainImageObservation MBObserveSceneMainHeader(const void *address) {
    MBSceneMainImageObservation observation = { .headerRead = MBSceneMainHeaderMissing };
    if (!address) return observation;
    // This function does not attest API origin or pin an image. Copy one common
    // header prefix from SELF, without pointer dereference, load-command walk
    // or retry. An unmapping/protection race fails closed instead of crashing.
    // This copy is a point-in-time observation, not attestation/atomicity proof.
    struct mach_header header = {0};
    vm_size_t copied = 0;
    _Static_assert(offsetof(struct mach_header, filetype) == offsetof(struct mach_header_64, filetype), "Common header prefix");
    kern_return_t result = vm_read_overwrite(mach_task_self(), (vm_address_t)(uintptr_t)address,
        sizeof(header), (vm_address_t)(uintptr_t)&header, &copied);
    if (result != KERN_SUCCESS || copied != sizeof(header)) {
        observation.headerRead = MBSceneMainHeaderUnreadable;
        return observation;
    }
    observation.headerRead = MBSceneMainHeaderCopied;
    switch (header.magic) {
        case MH_MAGIC: observation.magic = MBSceneMainMagicNative32; break;
        case MH_MAGIC_64: observation.magic = MBSceneMainMagicNative64; break;
        case MH_CIGAM: observation.magic = MBSceneMainMagicSwapped32; break;
        case MH_CIGAM_64: observation.magic = MBSceneMainMagicSwapped64; break;
        default: observation.magic = MBSceneMainMagicOther; break;
    }
    // Host-order comparison exactly as the original filetype predicate. Magic
    // is informational: no new acceptance fallback or silent byte swapping.
    switch (header.filetype) {
        case MH_EXECUTE: observation.fileType = MBSceneMainTypeExecute; break;
        case MH_DYLIB: observation.fileType = MBSceneMainTypeDylib; break;
        case MH_DYLINKER: observation.fileType = MBSceneMainTypeDylinker; break;
        case MH_BUNDLE: observation.fileType = MBSceneMainTypeBundle; break;
        default: observation.fileType = MBSceneMainTypeOther; break;
    }
    return observation;
}
const char *MBSceneMainHeaderReadName(MBSceneMainHeaderRead value) {
    switch (value) {
        case MBSceneMainHeaderUnobserved: return "unobserved";
        case MBSceneMainHeaderMissing: return "missing";
        case MBSceneMainHeaderUnreadable: return "unreadable";
        case MBSceneMainHeaderCopied: return "copied";
    }
    return "invalid";
}
const char *MBSceneMainMagicName(MBSceneMainMagic value) {
    switch (value) {
        case MBSceneMainMagicUnobserved: return "unobserved";
        case MBSceneMainMagicNative32: return "native32";
        case MBSceneMainMagicNative64: return "native64";
        case MBSceneMainMagicSwapped32: return "swapped32";
        case MBSceneMainMagicSwapped64: return "swapped64";
        case MBSceneMainMagicOther: return "other";
    }
    return "invalid";
}
const char *MBSceneMainFileTypeName(MBSceneMainFileType value) {
    switch (value) {
        case MBSceneMainTypeUnobserved: return "unobserved";
        case MBSceneMainTypeExecute: return "execute";
        case MBSceneMainTypeDylib: return "dylib";
        case MBSceneMainTypeDylinker: return "dylinker";
        case MBSceneMainTypeBundle: return "bundle";
        case MBSceneMainTypeOther: return "other";
    }
    return "invalid";
}
const char *MBSceneMainPathName(MBSceneMainPath value) {
    switch (value) {
        case MBSceneMainPathUnobserved: return "unobserved";
        case MBSceneMainPathMatch: return "match";
        case MBSceneMainPathMismatch: return "mismatch";
    }
    return "invalid";
}

static BOOL MBSHCopyString(char *out, size_t capacity, id value) {
    return [value isKindOfClass:NSString.class] && [value getCString:out maxLength:capacity encoding:NSUTF8StringEncoding];
}
static BOOL MBSHSystemPathMatches(const char *actual, const char *expected) {
    if (!actual || !expected || strnlen(actual, PATH_MAX) == PATH_MAX || strncmp(actual, "/System/", 8) != 0) return NO;
    char resolvedActual[PATH_MAX], resolvedExpected[PATH_MAX];
    if (realpath(actual, resolvedActual) && realpath(expected, resolvedExpected)) return strcmp(resolvedActual, resolvedExpected) == 0;
    // Shared-cache image install names can have no standalone file. Only an
    // exact known system install name is accepted in that case; no loose suffix.
    return strcmp(actual, expected) == 0;
}
void MBApplySceneMainExecutableFacts(MBSceneHostProcessFacts *facts, MBSceneMainExecutableInput input) {
    if (!facts) return;
    facts->mainImage = MBObserveSceneMainHeader(input.header);
    facts->mainIsExecutable = facts->mainImage.headerRead == MBSceneMainHeaderCopied &&
        facts->mainImage.fileType == MBSceneMainTypeExecute;
    const char *systemMain = "/System/Library/CoreServices/SpringBoard.app/SpringBoard";
    BOOL bundleExecutableMatches = MBSHSystemPathMatches(input.bundleExecutablePath, systemMain);
    // Bind the exact CRT header address to the resolved image, not an interior
    // pointer or a similarly named loaded image. A path alone is not enough.
    BOOL mainExecutableMatches = input.header && input.resolvedImageBase == input.header &&
        MBSHSystemPathMatches(input.resolvedImagePath, systemMain);
    facts->systemSpringBoardBundle = MBSHSystemPathMatches(input.bundlePath,
        "/System/Library/CoreServices/SpringBoard.app");
    facts->mainMatchesBundle = bundleExecutableMatches && mainExecutableMatches;
    facts->mainImage.bundleExecutablePath = bundleExecutableMatches ? MBSceneMainPathMatch : MBSceneMainPathMismatch;
    // main_path includes base==header correlation; this is NOT dyld0_path from
    // older builds. Failure/no dladdr result stays mismatch, with no fallback.
    facts->mainImage.mainExecutablePath = mainExecutableMatches ? MBSceneMainPathMatch : MBSceneMainPathMismatch;
    facts->mainImage.bundleLocation = facts->systemSpringBoardBundle ? MBSceneMainPathMatch : MBSceneMainPathMismatch;
}
BOOL MBCollectSceneHostProcessFacts(MBSceneHostProcessFacts *facts, __unused void *context) {
    if (!facts) return NO;
    memset(facts, 0, sizeof(*facts));
    NSBundle *bundle = NSBundle.mainBundle;
    NSDictionary *info = bundle.infoDictionary;
    NSOperatingSystemVersion os = NSProcessInfo.processInfo.operatingSystemVersion;
    facts->osMajor = os.majorVersion; facts->osMinor = os.minorVersion; facts->osPatch = os.patchVersion;
    if (!MBSHCopyString(facts->bundleIdentifier, sizeof(facts->bundleIdentifier), info[@"CFBundleIdentifier"]) ||
        !MBSHCopyString(facts->packageType, sizeof(facts->packageType), info[@"CFBundlePackageType"]) ||
        !MBSHCopyString(facts->executableName, sizeof(facts->executableName), info[@"CFBundleExecutable"])) return NO;
    facts->isExtension = info[@"NSExtension"] != nil;
    // The CRT API names the executable directly; image enumeration index zero
    // is not used as a main-executable identity contract. No dlopen/dlsym/scan
    // fallback. Copy the prefix and validate its exact dladdr base+system path.
    const void *mainHeader = _NSGetMachExecuteHeader();
    Dl_info mainOrigin = {0};
    BOOL mainOriginFound = mainHeader && dladdr(mainHeader, &mainOrigin) != 0;
    MBApplySceneMainExecutableFacts(facts, (MBSceneMainExecutableInput){
        .header = mainHeader,
        .resolvedImageBase = mainOriginFound ? mainOrigin.dli_fbase : NULL,
        .resolvedImagePath = mainOriginFound ? mainOrigin.dli_fname : NULL,
        .bundleExecutablePath = bundle.executablePath.fileSystemRepresentation,
        .bundlePath = bundle.bundlePath.fileSystemRepresentation,
    });
    uint32_t count = _dyld_image_count();
    for (unsigned family = 0; family < MBSceneHostImageCount; ++family) {
        facts->imageStates[family] = count > MB_SCENE_HOST_INSPECTION_MAX ? MBSceneHostImageLimit : MBSceneHostImageNotLoaded;
    }
    if (count > MB_SCENE_HOST_INSPECTION_MAX) return YES;
    for (uint32_t i = 0; i < count; ++i) {
        const char *path = _dyld_get_image_name(i);
        // Do not canonicalize arbitrary loaded paths, including app/tweak images.
        if (!path || strncmp(path, "/System/", 8) != 0) continue;
        for (unsigned family = 0; family < MBSceneHostImageCount; ++family) {
            if (!MBSHSystemPathMatches(path, MBSceneHostExpectedImage(family))) continue;
            facts->imageHeaders[family] = _dyld_get_image_header(i);
            facts->imageStates[family] = facts->imageHeaders[family] ? MBSceneHostImageLoaded : MBSceneHostImageUnknown;
        }
    }
    return YES;
}

static MBSceneHostMetadataStatus MBSHImageStatus(MBSceneHostImage family, const MBSceneHostProcessFacts *facts) {
    if (!facts || family >= MBSceneHostImageCount) return MBSceneHostImageUnavailable;
    switch (facts->imageStates[family]) {
        case MBSceneHostImageLoaded: return facts->imageHeaders[family] ? MBSceneHostMetadataMatch : MBSceneHostImageUnavailable;
        case MBSceneHostImageNotLoaded: return MBSceneHostImageAbsent;
        case MBSceneHostImageLimit: return MBSceneHostImageScanLimit;
        default: return MBSceneHostImageUnavailable;
    }
}
MBSceneHostMetadataStatus MBClassifySceneHostResolvedOrigin(MBSceneHostImage family, MBSceneHostOriginInput input) {
    // Same predicate order as the verifier: availability, exact base, then path.
    // A matching path must never rescue a different base. Only fixed expected
    // system install names are used; no scan, provider lookup or raw log.
    if (family >= MBSceneHostImageCount || !input.expectedImageBase || !input.resolvedImageBase)
        return MBSceneHostImageUnavailable;
    if (input.resolvedImageBase != input.expectedImageBase)
        return input.isMethod ? MBSceneHostIMPBaseMismatch : MBSceneHostClassImageMismatch;
    if (!MBSHSystemPathMatches(input.resolvedImagePath, MBSceneHostExpectedImage(family)))
        return input.isMethod ? MBSceneHostIMPPathMismatch : MBSceneHostClassImageMismatch;
    return MBSceneHostMetadataMatch;
}
MBSceneHostMetadataStatus MBVerifySceneHostLoadedOrigin(void *handle, Method method,
    MBSceneHostImage family, const MBSceneHostProcessFacts *facts, __unused void *context) {
    MBSceneHostMetadataStatus state = MBSHImageStatus(family, facts);
    if (state != MBSceneHostMetadataMatch || !handle) return state == MBSceneHostMetadataMatch ? MBSceneHostImageUnavailable : state;
    const void *address = handle;
    if (method) {
        IMP implementation = method_getImplementation(method);
#if __has_feature(ptrauth_calls)
        address = ptrauth_strip(implementation, ptrauth_key_function_pointer);
#else
        address = (const void *)implementation;
#endif
    }
    Dl_info image = {0};
    if (!address || !dladdr(address, &image) || !image.dli_fbase) return MBSceneHostImageUnavailable;
    MBSceneHostMetadataStatus resolved = MBClassifySceneHostResolvedOrigin(family, (MBSceneHostOriginInput){
        .expectedImageBase = facts->imageHeaders[family], .resolvedImageBase = image.dli_fbase,
        .resolvedImagePath = image.dli_fname, .isMethod = method != NULL,
    });
    if (resolved != MBSceneHostMetadataMatch) return resolved;
    // Preserve the lazy class-only check: do not call this getter for a method
    // or when resolved base/path failed. No extra runtime API call is added.
    if (!method && !MBSHSystemPathMatches(class_getImageName((__bridge Class)handle), MBSceneHostExpectedImage(family)))
        return MBSceneHostClassImageMismatch;
    return MBSceneHostMetadataMatch;
}

static MBSceneHostMetadataStatus MBSHValidateFacts(const MBSceneHostProcessFacts *facts) {
    if (!memchr(facts->bundleIdentifier, 0, sizeof(facts->bundleIdentifier)) ||
        !memchr(facts->packageType, 0, sizeof(facts->packageType)) ||
        !memchr(facts->executableName, 0, sizeof(facts->executableName))) return MBSceneHostFactsUnavailable;
    // Preserve every predicate and its precedence. These reasons identify only
    // the first rejected existing fact, not its value or the runtime cause.
    if (strcmp(facts->bundleIdentifier, "com.apple.springboard")) return MBSceneHostBundleIdentifierMismatch;
    if (strcmp(facts->packageType, "APPL")) return MBSceneHostPackageTypeMismatch;
    if (strcmp(facts->executableName, "SpringBoard")) return MBSceneHostExecutableNameMismatch;
    if (facts->isExtension) return MBSceneHostExtensionProcess;
    if (!facts->mainIsExecutable) return MBSceneHostMainTypeMismatch;
    if (!facts->mainMatchesBundle) return MBSceneHostMainPathMismatch;
    if (!facts->systemSpringBoardBundle) return MBSceneHostBundlePathMismatch;
    if (facts->osMajor != 16 || facts->osMinor != 5 || facts->osPatch != 0) return MBSceneHostOSMismatch;
    return MBSceneHostMetadataMatch;
}
static void *MBSHLookup(const char *name, MBSceneHostDiagnosticDependencies dependencies) {
    return dependencies.lookup ? dependencies.lookup(name, dependencies.context) : (__bridge void *)objc_lookUpClass(name);
}
static Method MBSHOwnedMethod(Class cls, SEL selector, BOOL *limited) {
    unsigned count = 0;
    Method *list = class_copyMethodList(cls, &count);
    *limited = count > MB_SCENE_HOST_INSPECTION_MAX;
    Method found = NULL;
    if (!*limited) for (unsigned i = 0; list && i < count; ++i) {
        if (sel_isEqual(method_getName(list[i]), selector)) { found = list[i]; break; }
    }
    free(list);
    return found;
}
static MBSceneHostMetadataStatus MBSHOrigin(void *handle, Method method, MBSceneHostImage image,
    const MBSceneHostProcessFacts *facts, MBSceneHostDiagnosticDependencies dependencies) {
    MBSceneHostOriginVerifier verify = dependencies.origin ?: MBVerifySceneHostLoadedOrigin;
    MBSceneHostMetadataStatus status = verify(handle, method, image, facts, dependencies.context);
    switch (status) {
        case MBSceneHostMetadataMatch: case MBSceneHostClassImageMismatch:
        case MBSceneHostIMPImageMismatch: case MBSceneHostIMPBaseMismatch:
        case MBSceneHostIMPPathMismatch: case MBSceneHostImageUnavailable: return status;
        default: return MBSceneHostFactsUnavailable;
    }
}
static BOOL MBSHTokenMatches(const char *actual, const char *expected) {
    if (!actual || !expected) return NO;
    while (*actual && strchr("rnNoORV", *actual)) ++actual;
    return strcmp(expected, "@") == 0 ? actual[0] == '@' && actual[1] != '?' : strcmp(actual, expected) == 0;
}
static BOOL MBSHProtocolABIMatches(const char *encoding, const MBSceneHostContract *contract) {
    if (!encoding || strnlen(encoding, 2048) == 2048) return NO;
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:encoding];
    if (!signature || signature.numberOfArguments != contract->argumentCount + 2 ||
        !MBSHTokenMatches(signature.methodReturnType, contract->returnType)) return NO;
    for (unsigned i = 0; i < contract->argumentCount; ++i) {
        if (!MBSHTokenMatches([signature getArgumentTypeAtIndex:i + 2], contract->argumentTypes[i])) return NO;
    }
    return YES;
}
static MBSceneHostMetadataStatus MBSHInspectProtocol(const MBSceneHostContract *contract, MBSceneHostDiagnosticDependencies dependencies) {
    __unsafe_unretained Protocol *protocol = dependencies.protocolLookup ? (__bridge Protocol *)dependencies.protocolLookup(contract->className, dependencies.context) :
        objc_getProtocol(contract->className);
    if (!protocol) return MBSceneHostProtocolMissing;
    SEL selector = sel_registerName(contract->selectorName);
    BOOL found = NO, matched = YES;
    for (unsigned required = 0; required <= 1; ++required) {
        unsigned count = 0;
        struct objc_method_description *list = protocol_copyMethodDescriptionList(protocol, required != 0, YES, &count);
        if (count > MB_SCENE_HOST_INSPECTION_MAX) { free(list); return MBSceneHostInspectionLimit; }
        for (unsigned i = 0; list && i < count; ++i) {
            if (!sel_isEqual(list[i].name, selector)) continue;
            found = YES;
            matched &= MBSHProtocolABIMatches(list[i].types, contract);
        }
        free(list);
    }
    // Own protocol declarations only, no inferred superclass/protocol adoption.
    return !found ? MBSceneHostProtocolMethodMissing : matched ? MBSceneHostMetadataMatch : MBSceneHostProtocolABIMismatch;
}
static MBSceneHostMetadataStatus MBSHInspectItem(const MBSceneHostContract *contract,
    const MBSceneHostProcessFacts *facts, MBSceneHostDiagnosticDependencies dependencies) {
    if (contract->kind == MBSceneHostProtocolInstanceMethod) return MBSHInspectProtocol(contract, dependencies);
    MBSceneHostMetadataStatus status = MBSHImageStatus(contract->image, facts);
    if (status != MBSceneHostMetadataMatch) return status;
    __unsafe_unretained Class cls = (__bridge Class)MBSHLookup(contract->className, dependencies);
    if (!cls || class_isMetaClass(cls)) return MBSceneHostClassMissing;
    status = MBSHOrigin((__bridge void *)cls, NULL, contract->image, facts, dependencies);
    if (status != MBSceneHostMetadataMatch) return status;
    if (contract->superclassName) {
        __unsafe_unretained Class superclass = (__bridge Class)MBSHLookup(contract->superclassName, dependencies);
        if (!superclass || class_getSuperclass(cls) != superclass) return MBSceneHostSuperclassMismatch;
    }
    __unsafe_unretained Class owner = contract->kind == MBSceneHostClassMethod ? object_getClass(cls) : cls;
    SEL selector = sel_registerName(contract->selectorName);
    BOOL limited = NO;
    Method method = MBSHOwnedMethod(owner, selector, &limited);
    if (limited || !method) return limited ? MBSceneHostInspectionLimit : MBSceneHostMethodMissing;
    if (!MBMethodMatches(owner, selector, contract->returnType, contract->argumentCount, contract->argumentTypes)) return MBSceneHostABIMismatch;
    return MBSHOrigin((__bridge void *)cls, method, contract->image, facts, dependencies);
}
MBSceneHostDiagnosticReport MBEvaluateSceneHostDiagnostic(MBSceneHostDiagnosticDependencies dependencies) {
    MBSceneHostDiagnosticReport report = { .processStatus = MBSceneHostFactsUnavailable };
    @try {
        MBSceneHostProcessFacts facts = {0};
        if (!dependencies.collect || !dependencies.collect(&facts, dependencies.context)) return report;
        // Informational enums do not authorize process/metadata lookup. Ignore
        // malformed trusted-fixture observations rather than changing guards.
        if (MBSceneMainImageObservationIsValid(facts.mainImage)) report.mainImage = facts.mainImage;
        report.processStatus = MBSHValidateFacts(&facts);
        if (report.processStatus != MBSceneHostMetadataMatch) return report;
        report.count = MBSceneHostCatalogCount();
        for (size_t i = 0; i < report.count; ++i) {
            @try { report.items[i] = MBSHInspectItem(&MBSceneCatalog[i], &facts, dependencies); }
            @catch (__unused NSException *exception) { report.items[i] = MBSceneHostInspectionException; }
        }
    } @catch (__unused NSException *exception) {
        report = (MBSceneHostDiagnosticReport){ .processStatus = MBSceneHostInspectionException };
    }
    return report;
}
static void MBSHProgress(MBSceneHostDiagnosticDependencies dependencies, MBSceneHostDiagnosticStage stage) {
    // A diagnostic observer must not change scheduling, retry, or propagate an
    // exception into SpringBoard. Its arguments are finite enums, never facts.
    @try {
        if (dependencies.progress) dependencies.progress(stage, dependencies.trigger, dependencies.context);
    } @catch (__unused NSException *exception) {}
}
BOOL MBQueueSceneHostDiagnostic(MBSceneHostDiagnosticOnce *once, MBSceneHostDiagnosticDependencies dependencies) {
    if (!once || !dependencies.collect || !dependencies.enqueue || !dependencies.sink) return NO;
    unsigned expected = 0;
    if (!atomic_compare_exchange_strong(&once->phase, &expected, 1)) return NO;
    MBSHProgress(dependencies, MBSceneHostStageAccepted);
    @try {
        dependencies.enqueue(^{
            unsigned queued = 1;
            if (!atomic_compare_exchange_strong(&once->phase, &queued, 2)) return;
            MBSHProgress(dependencies, MBSceneHostStageExecuting);
            @autoreleasepool {
                BOOL delivered = NO;
                @try {
                    MBSceneHostDiagnosticReport report = MBEvaluateSceneHostDiagnostic(dependencies);
                    dependencies.sink(&report, dependencies.context);
                    delivered = YES;
                } @catch (__unused NSException *exception) {
                    // No exception descriptions, retry or external state.
                } @finally {
                    atomic_store(&once->phase, 3);
                    MBSHProgress(dependencies, delivered ? MBSceneHostStageFinished : MBSceneHostStageDeliveryException);
                }
            }
        }, dependencies.context);
    } @catch (__unused NSException *exception) {
        // An executor can enqueue and then throw. Only cancel a still-queued
        // attempt; never overwrite a running worker or emit a second terminal.
        unsigned queued = 1;
        if (atomic_compare_exchange_strong(&once->phase, &queued, 3))
            MBSHProgress(dependencies, MBSceneHostStageEnqueueException);
    }
    return YES; // attempt claimed, not proof of enqueue/report/host success
}
const char *MBSceneHostDiagnosticTriggerName(MBSceneHostDiagnosticTrigger trigger) {
    switch (trigger) {
        case MBSceneHostTriggerUnknown: return "unknown";
        case MBSceneHostTriggerPublicLaunch: return "public-launch";
        case MBSceneHostTriggerPublicActive: return "public-active";
        case MBSceneHostTriggerSpringBoardLaunchHook: return "springboard-launch-hook";
        case MBSceneHostTriggerPublicActiveCatchUp: return "public-active-catch-up";
    }
    return "unknown";
}
const char *MBSceneHostDiagnosticStageName(MBSceneHostDiagnosticStage stage) {
    switch (stage) {
        case MBSceneHostStageAccepted: return "accepted";
        case MBSceneHostStageExecuting: return "executing";
        case MBSceneHostStageFinished: return "finished";
        case MBSceneHostStageEnqueueException: return "enqueue-exception";
        case MBSceneHostStageDeliveryException: return "delivery-exception";
    }
    return "unknown-stage";
}
const char *MBSceneHostDiagnosticReason(MBSceneHostMetadataStatus status) {
    switch (status) {
        case MBSceneHostMetadataMatch: return "metadata-only-match";
        case MBSceneHostFactsUnavailable: return "facts-unavailable";
        case MBSceneHostProcessMismatch: return "springboard-process-mismatch";
        case MBSceneHostBundleIdentifierMismatch: return "springboard-bundle-id-mismatch";
        case MBSceneHostPackageTypeMismatch: return "springboard-package-type-mismatch";
        case MBSceneHostExecutableNameMismatch: return "springboard-executable-name-mismatch";
        case MBSceneHostExtensionProcess: return "springboard-extension-process";
        case MBSceneHostMainTypeMismatch: return "springboard-main-type-mismatch";
        case MBSceneHostMainPathMismatch: return "springboard-main-path-mismatch";
        case MBSceneHostBundlePathMismatch: return "springboard-bundle-path-mismatch";
        case MBSceneHostOSMismatch: return "os-mismatch";
        case MBSceneHostImageUnavailable: return "image-unavailable";
        case MBSceneHostImageAbsent: return "image-not-loaded";
        case MBSceneHostImageScanLimit: return "image-scan-limit";
        case MBSceneHostClassMissing: return "class-missing";
        case MBSceneHostSuperclassMismatch: return "superclass-mismatch";
        case MBSceneHostClassImageMismatch: return "class-image-mismatch";
        case MBSceneHostMethodMissing: return "owned-method-missing";
        case MBSceneHostABIMismatch: return "abi-mismatch";
        case MBSceneHostIMPImageMismatch: return "imp-image-mismatch";
        case MBSceneHostIMPBaseMismatch: return "imp-base-mismatch";
        case MBSceneHostIMPPathMismatch: return "imp-path-mismatch";
        case MBSceneHostProtocolMissing: return "protocol-missing";
        case MBSceneHostProtocolMethodMissing: return "protocol-owned-method-missing";
        case MBSceneHostProtocolABIMismatch: return "protocol-abi-mismatch";
        case MBSceneHostInspectionLimit: return "inspection-limit";
        case MBSceneHostInspectionException: return "inspection-exception";
    }
    return "unknown-status";
}
const char *MBSceneHostDiagnosticDisposition(MBSceneHostMetadataStatus status) {
    switch (status) {
        case MBSceneHostMetadataMatch: return "metadata-match";
        case MBSceneHostFactsUnavailable: case MBSceneHostImageUnavailable:
        case MBSceneHostImageAbsent: case MBSceneHostImageScanLimit:
        case MBSceneHostInspectionLimit: case MBSceneHostInspectionException: return "inconclusive";
        default: return "unsupported";
    }
}
static os_log_t MBSHLogger(void) {
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "scene-host-diagnostic"); });
    return log;
}
static void MBSHLogProgress(MBSceneHostDiagnosticStage stage, MBSceneHostDiagnosticTrigger trigger, __unused void *context) {
    MBRecordSceneDiagnosticProgress(stage, trigger);
    os_log(MBSHLogger(), "MBSceneHostDiagnostic scope=springboard feature=progress tweak_build=%{public}s trigger=%{public}s stage=%{public}s",
        APELIN_BUILD_ID, MBSceneHostDiagnosticTriggerName(trigger), MBSceneHostDiagnosticStageName(stage));
}
void MBEmitSceneHostDiagnosticReport(const MBSceneHostDiagnosticReport *report, BOOL replay) {
    if (!report) return;
    const char *delivery = replay ? "replay" : "initial";
    os_log_t log = MBSHLogger();
    MBSceneMainImageObservation main = MBSceneMainImageObservationIsValid(report->mainImage) ?
        report->mainImage : (MBSceneMainImageObservation){0};
    // Same process line and budget for initial/replay; only fixed enum labels.
    os_log(log, "MBSceneHostDiagnostic scope=springboard feature=process result=%{public}s reason=%{public}s tweak_build=%{public}s delivery=%{public}s main_read=%{public}s main_magic=%{public}s main_type=%{public}s bundle_exec=%{public}s main_path=%{public}s bundle_location=%{public}s",
        MBSceneHostDiagnosticDisposition(report->processStatus), MBSceneHostDiagnosticReason(report->processStatus), APELIN_BUILD_ID, delivery,
        MBSceneMainHeaderReadName(main.headerRead), MBSceneMainMagicName(main.magic), MBSceneMainFileTypeName(main.fileType),
        MBSceneMainPathName(main.bundleExecutablePath), MBSceneMainPathName(main.mainExecutablePath), MBSceneMainPathName(main.bundleLocation));
    size_t count = MIN(report->count, MIN(MBSceneHostCatalogCount(), MB_SCENE_HOST_CATALOG_MAX));
    for (size_t i = 0; i < count; ++i) {
        const MBSceneHostContract *contract = &MBSceneCatalog[i];
        const char *result = contract->referenceOnly && report->items[i] == MBSceneHostMetadataMatch ?
            "reference-abi-match" : MBSceneHostDiagnosticDisposition(report->items[i]);
        os_log(log, "MBSceneHostDiagnostic scope=springboard feature=%{public}s evidence=%{public}s result=%{public}s reason=%{public}s tweak_build=%{public}s delivery=%{public}s",
            contract->feature, contract->referenceOnly ? "ios17-header-reference" : "ios16.5-helper-metadata",
            result, MBSceneHostDiagnosticReason(report->items[i]), APELIN_BUILD_ID, delivery);
    }
    os_log(log, "MBSceneHostDiagnostic scope=springboard feature=complete items=%lu tweak_build=%{public}s delivery=%{public}s", (unsigned long)count, APELIN_BUILD_ID, delivery);
}
static void MBSHLog(const MBSceneHostDiagnosticReport *report, __unused void *context) {
    MBRetainSceneDiagnosticReport(report);
    MBEmitSceneHostDiagnosticReport(report, NO);
}
static void MBSHEnqueue(dispatch_block_t work, __unused void *context) {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), work);
}
void MBStartPassiveSceneHostDiagnostic(MBSceneHostDiagnosticTrigger trigger) {
    static MBSceneHostDiagnosticOnce once = MB_SCENE_HOST_DIAGNOSTIC_ONCE_INIT;
    MBQueueSceneHostDiagnostic(&once, (MBSceneHostDiagnosticDependencies){
        .collect = MBCollectSceneHostProcessFacts, .sink = MBSHLog, .enqueue = MBSHEnqueue,
        .progress = MBSHLogProgress, .trigger = trigger,
    });
}
