// SPDX-License-Identifier: MIT
// Copyright (c) 2026 OwnGoal Studio
// Load marker retained from Apelin's tweak template.
#import <Foundation/Foundation.h>
#import <os/log.h>
#import "MBVendorAdapter.h"
#import "MBMessengerBridge.h"

static os_log_t TweakLog(void) {
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "tweak"); });
    return log;
}
__attribute__((constructor)) static void TweakInitialize(void) {
    os_log(TweakLog(), "ApelinLoaded %{public}s in %{public}s", APELIN_BUILD_ID, getprogname());
    @autoreleasepool {
        NSString *bundle = NSBundle.mainBundle.bundleIdentifier;
        if ([bundle isEqualToString:@"com.apple.springboard"])
            dispatch_async(dispatch_get_main_queue(), ^{ MBStartVendorAdapter(); });
        else if ([bundle isEqualToString:@"com.facebook.Messenger"])
            dispatch_async(dispatch_get_main_queue(), ^{ MBStartMessengerBridge(); });
    }
}
