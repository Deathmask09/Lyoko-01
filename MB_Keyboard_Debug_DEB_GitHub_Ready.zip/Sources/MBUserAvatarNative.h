// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
/// Native app bubble photo only, not a per-chat picker/navigation implementation.
/// Main queue. Caller supplies only an accepted/deduplicated notification's bounded
/// thread string and the already verified native icon view. Exact DB lookup must
/// succeed; the candidate is NEVER treated as a user ID or navigation route.
FOUNDATION_EXPORT void MBUserAvatarObserveNative(NSString * _Nullable threadCandidate,
    UIImageView * _Nullable target, UIImage * _Nullable placeholder, BOOL (^mayApply)(UIImageView *target));
/// OFF/lock/capture/foreground/teardown: cancel, clear current pixels, purge RAM.
FOUNDATION_EXPORT void MBUserAvatarResetNative(void);
NS_ASSUME_NONNULL_END
