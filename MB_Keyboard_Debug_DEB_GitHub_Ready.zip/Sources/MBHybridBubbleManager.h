// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>

NS_ASSUME_NONNULL_BEGIN
// Only a verified provider may create these events. No payload guessing/DB access.
// sourceRevision must increase per thread across BOTH message and unread events.
@interface MBHybridMessageEvent : NSObject
@property(nonatomic, readonly, copy) NSString *threadID;
@property(nonatomic, readonly) BOOL groupThread;
@property(nonatomic, readonly, copy, nullable) NSString *avatarKey;
@property(nonatomic, readonly, copy, nullable) NSString *messageID;
@property(nonatomic, readonly) NSInteger authoritativeUnread; // -1 = unknown, never an app badge.
@property(nonatomic, readonly) uint64_t sourceRevision;
@property(nonatomic, readonly) BOOL newUnread;
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
- (nullable instancetype)initWithThreadID:(NSString *)threadID group:(BOOL)group
    avatarKey:(nullable NSString *)avatarKey messageID:(nullable NSString *)messageID
    authoritativeUnread:(NSInteger)unread revision:(uint64_t)revision newUnread:(BOOL)newUnread;
@end

@interface MBHybridBubble : NSObject <NSCopying>
@property(nonatomic, readonly, copy) NSString *threadID;
@property(nonatomic, readonly) BOOL groupThread;
@property(nonatomic, readonly, copy, nullable) NSString *avatarKey;
@property(nonatomic, readonly, copy, nullable) NSString *lastMessageID;
@property(nonatomic, readonly) NSUInteger unread;
@property(nonatomic, readonly) BOOL unreadIsAuthoritative;
@property(nonatomic, readonly) uint64_t sourceRevision;
@property(nonatomic, readonly) uint64_t activityOrder;
@end

typedef NS_ENUM(NSUInteger, MBHybridPresentationStyle) {
    MBHybridPresentationHidden, MBHybridPresentationSingle, MBHybridPresentationStack,
};
@interface MBHybridSnapshot : NSObject
@property(nonatomic, readonly, copy) NSArray<MBHybridBubble *> *items;
@property(nonatomic, readonly) MBHybridPresentationStyle style;
@property(nonatomic, readonly) BOOL pickerExpanded;
@property(nonatomic, readonly) BOOL badgeIsExact;
@property(nonatomic, readonly) NSUInteger totalUnread; // 0 while unknown; do not display an estimate.
@property(nonatomic, readonly) BOOL capacityExceeded;
@property(nonatomic, readonly, copy, nullable) NSString *activeThreadID;
@property(nonatomic, readonly, copy, nullable) NSString *pendingThreadID;
@end

// One injected instance owns ONE panel/scene for this manager's entire lifetime.
// navigate must leave the panel hidden; present is called only after current success.
// collapse/cancelNavigation must not create/destroy a scene or mark any chat read.
// cancelNavigation is a cancellation barrier: old work must never mutate the scene
// after it returns, even if its completion arrives late. A provider must prove this.
// No production implementation is assumed from a selector's name/metadata alone.
@protocol MBHybridSharedChatPanel <NSObject>
- (void)navigateToThread:(NSString *)threadID group:(BOOL)group completion:(void (^)(BOOL success))completion;
- (void)present;
- (void)collapse;
- (void)cancelNavigation;
@end

@interface MBHybridBubbleManager : NSObject
// All public APIs are main-queue only. Source/router callbacks may arrive anywhere.
// Changes are coalesced once on the next main-queue turn; no polling/render timer.
@property(nonatomic, copy, nullable) void (^onChange)(MBHybridSnapshot *snapshot);
@property(nonatomic, readonly) MBHybridSnapshot *snapshot;
- (instancetype)initWithSharedPanel:(id<MBHybridSharedChatPanel>)panel;
- (instancetype)initWithSharedPanel:(id<MBHybridSharedChatPanel>)panel maximumThreads:(NSUInteger)maximum;
- (BOOL)onMessage:(MBHybridMessageEvent *)event;
- (BOOL)onUnreadChanged:(NSString *)threadID count:(NSInteger)count revision:(uint64_t)revision;
- (void)onStackTap;
- (void)onAvatarTap:(NSString *)threadID;
- (BOOL)onBubbleClose:(NSString *)threadID;
// OFF, lock, capture, account switch/logout must call reset. No persistence.
- (void)reset;
@end
NS_ASSUME_NONNULL_END
