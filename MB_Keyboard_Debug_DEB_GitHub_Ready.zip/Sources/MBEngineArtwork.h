// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>

// Returns the engine's app-icon object, never a screenshot or contact avatar.
// The caller verifies the provider's engine image and checks for UIImage.
FOUNDATION_EXPORT id _Nullable MBReadMessengerArtwork(Class _Nullable provider,
                                                      id _Nullable iconModel);
