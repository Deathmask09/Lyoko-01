// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
#import "MBHybridAvatarCache.h"
NS_ASSUME_NONNULL_BEGIN
// One binding per reusable image view. No image/key is ever written to disk/log.
@interface MBHybridAvatarBinding : NSObject
- (instancetype)initWithImageView:(UIImageView *)imageView cache:(MBHybridAvatarCache *)cache;
- (void)bindThreadID:(NSString *)threadID avatarKey:(nullable NSString *)avatarKey;
- (void)prepareForReuse;
@end
NS_ASSUME_NONNULL_END
