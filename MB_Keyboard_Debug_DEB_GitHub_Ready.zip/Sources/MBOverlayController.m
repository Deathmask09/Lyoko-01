// SPDX-License-Identifier: MIT
#import "MBOverlayController.h"
#import <QuartzCore/QuartzCore.h>

static const CGFloat MBBubbleRadius = 27;
static const CGFloat MBBubbleSpacing = 64;
static const CGFloat MBDismissTargetRadius = 37;
static const CGFloat MBDismissTargetBottomInset = 5;

static BOOL MBSameRect(MBRect a, MBRect b) {
    return a.x == b.x && a.y == b.y && a.width == b.width && a.height == b.height;
}

@interface MBPassThroughWindow : UIWindow
@end
@implementation MBPassThroughWindow
- (BOOL)canBecomeKeyWindow { return NO; }
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    return hit == self || hit == self.rootViewController.view ? nil : hit;
}
@end

@interface MBOverlayCanvas : UIViewController
@property(nonatomic, copy) void (^didLayout)(void);
@end
@implementation MBOverlayCanvas
- (void)viewDidLoad { [super viewDidLoad]; self.view.backgroundColor = UIColor.clearColor; }
- (void)viewDidLayoutSubviews { [super viewDidLayoutSubviews]; if (self.didLayout) self.didLayout(); }
- (BOOL)prefersStatusBarHidden { return NO; }
@end

@interface MBBubbleControl : UIButton
@property(nonatomic) uint64_t conversation;
@property(nonatomic) unsigned observedUnread;
@property(nonatomic, strong) UILabel *badgeLabel;
@property(nonatomic, strong) UILabel *stackLabel;
- (void)showObservedUnread:(unsigned)unread extraConversations:(NSUInteger)extra;
@end
@implementation MBBubbleControl
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColor.systemBlueColor;
        self.tintColor = UIColor.whiteColor;
        [self setImage:[UIImage systemImageNamed:@"person.fill"] forState:UIControlStateNormal];
        self.layer.cornerRadius = MBBubbleRadius;
        self.layer.shadowColor = UIColor.blackColor.CGColor;
        self.layer.shadowOpacity = 0.18;
        self.layer.shadowRadius = 4;
        self.layer.shadowOffset = CGSizeMake(0, 2);
        self.badgeLabel = [[UILabel alloc] initWithFrame:CGRectMake(32, -3, 29, 21)];
        self.badgeLabel.backgroundColor = UIColor.systemRedColor;
        self.badgeLabel.textColor = UIColor.whiteColor;
        self.badgeLabel.font = [UIFont boldSystemFontOfSize:11];
        self.badgeLabel.textAlignment = NSTextAlignmentCenter;
        self.badgeLabel.layer.cornerRadius = 10.5;
        self.badgeLabel.clipsToBounds = YES;
        self.badgeLabel.userInteractionEnabled = NO;
        [self addSubview:self.badgeLabel];
        self.stackLabel = [[UILabel alloc] initWithFrame:CGRectMake(-5, 35, 27, 20)];
        self.stackLabel.backgroundColor = UIColor.secondarySystemBackgroundColor;
        self.stackLabel.textColor = UIColor.labelColor;
        self.stackLabel.font = [UIFont boldSystemFontOfSize:10];
        self.stackLabel.textAlignment = NSTextAlignmentCenter;
        self.stackLabel.layer.cornerRadius = 10;
        self.stackLabel.clipsToBounds = YES;
        self.stackLabel.userInteractionEnabled = NO;
        [self addSubview:self.stackLabel];
    }
    return self;
}
- (void)showObservedUnread:(unsigned)unread extraConversations:(NSUInteger)extra {
    self.badgeLabel.text = unread > 99 ? @"99+" : [NSString stringWithFormat:@"%u", unread];
    self.badgeLabel.hidden = unread == 0;
    self.stackLabel.hidden = extra == 0;
    self.stackLabel.text = [NSString stringWithFormat:@"+%lu", (unsigned long)extra];
    self.accessibilityLabel = [NSString stringWithFormat:@"Bong bóng, %u thông báo đã quan sát", unread];
    self.accessibilityHint = extra ? @"Chạm để mở dãy bong bóng. Chưa hỗ trợ mở chat nội tuyến." :
        @"Chưa hỗ trợ mở chat nội tuyến. Kéo để di chuyển hoặc kéo tới dấu đóng.";
}
@end

@interface MBOverlayController ()
@property(nonatomic, strong) MBPassThroughWindow *window;
@property(nonatomic, strong) MBOverlayCanvas *canvas;
@property(nonatomic, strong) NSMutableDictionary<NSNumber *, MBBubbleControl *> *controls;
@property(nonatomic, copy) NSArray<NSNumber *> *order;
@property(nonatomic, strong) UILabel *dismissTarget;
@property(nonatomic, strong) MBBubbleControl *dragged;
@property(nonatomic) CGPoint dragOrigin;
@property(nonatomic) NSUInteger dragIndex;
@property(nonatomic) MBPoint dragAnchor;
@property(nonatomic) MBPoint anchor;
@property(nonatomic) MBRect lastSafe;
@property(nonatomic) BOOL hasAnchor;
@property(nonatomic) BOOL hasGeometry;
@property(nonatomic) BOOL hasDismissTarget;
@property(nonatomic) BOOL purging;
@property(nonatomic) BOOL expanded;
@property(nonatomic) unsigned totalUnread;
- (BOOL)layoutAnimated:(BOOL)animated;
- (BOOL)dismissControlIfAllowed:(MBBubbleControl *)control;
@end

@implementation MBOverlayController
- (instancetype)init {
    self = [super init];
    if (self) { _controls = [NSMutableDictionary dictionary]; _order = @[]; }
    return self;
}

- (BOOL)permitted {
    return self.isDisplayAllowed && self.isDisplayAllowed();
}

- (UIWindowScene *)soleUsableScene {
    UIWindowScene *chosen = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        // Ambiguous/multiple active scenes => fail closed, not an arbitrary scene.
        if (chosen || ((UIWindowScene *)scene).screen.isCaptured) return nil;
        chosen = (UIWindowScene *)scene;
    }
    return chosen;
}

- (BOOL)presentationIsCurrent {
    if (self.purging || !self.window || ![self permitted]) return NO;
    UIWindowScene *scene = [self soleUsableScene];
    return scene && self.window.windowScene == scene;
}

- (void)invalidatePresentation {
    if (self.purging) return;
    [self purgeImmediately];
    // Closing a layout is not enough: reject queued bulletins from its epoch.
    // Ordinary coordinator purges do not call this callback back recursively.
    if (self.didLosePresentation) self.didLosePresentation();
}

- (BOOL)createWindowIfPossible {
    if (self.window) {
        if ([self presentationIsCurrent]) return YES;
        [self invalidatePresentation];
        return NO;
    }
    if (self.purging || ![self permitted]) return NO;
    UIWindowScene *chosen = [self soleUsableScene];
    if (!chosen) return NO;
    self.canvas = [MBOverlayCanvas new];
    self.window = [[MBPassThroughWindow alloc] initWithWindowScene:chosen];
    self.window.frame = chosen.coordinateSpace.bounds;
    self.window.backgroundColor = UIColor.clearColor;
    self.window.windowLevel = UIWindowLevelStatusBar + 1;
    self.window.rootViewController = self.canvas;
    self.canvas.view.frame = self.window.bounds;
    // Never makeKeyWindow / makeKeyAndVisible: leave the foreground app's input.
    CGFloat diameter = 2 * MBDismissTargetRadius;
    self.dismissTarget = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, diameter, diameter)];
    self.dismissTarget.text = @"×";
    self.dismissTarget.font = [UIFont systemFontOfSize:42 weight:UIFontWeightLight];
    self.dismissTarget.textColor = UIColor.whiteColor;
    self.dismissTarget.backgroundColor = UIColor.systemGrayColor;
    self.dismissTarget.textAlignment = NSTextAlignmentCenter;
    self.dismissTarget.layer.cornerRadius = MBDismissTargetRadius;
    self.dismissTarget.clipsToBounds = YES;
    self.dismissTarget.hidden = YES;
    self.dismissTarget.userInteractionEnabled = NO;
    self.dismissTarget.isAccessibilityElement = NO;
    [self.canvas.view addSubview:self.dismissTarget];
    __weak MBOverlayController *weakSelf = self;
    self.canvas.didLayout = ^{ [weakSelf layoutAnimated:NO]; };
    return YES;
}

- (MBRect)safeBounds {
    CGRect rect = UIEdgeInsetsInsetRect(self.canvas.view.bounds, self.canvas.view.safeAreaInsets);
    rect = CGRectInset(rect, 9, 9);
    return (MBRect){rect.origin.x, rect.origin.y, rect.size.width, rect.size.height};
}

- (BOOL)cancelActiveDragRestoringAnchor {
    MBBubbleControl *control = self.dragged;
    if (!control) return YES;
    // Clear ownership BEFORE UIKit cancellation can reenter pan:.
    self.dragged = nil;
    self.dismissTarget.hidden = YES;
    self.dismissTarget.backgroundColor = UIColor.systemGrayColor;
    MBPoint restored;
    BOOL valid = self.hasGeometry && MBResolveDragAnchor(self.lastSafe, MBBubbleRadius,
        MBBubbleSpacing, self.dragIndex, true, self.dragAnchor, (MBPoint){0}, 0, &restored);
    if (valid) self.anchor = restored;
    for (UIGestureRecognizer *gesture in control.gestureRecognizers) {
        gesture.enabled = NO;
        gesture.enabled = YES;
    }
    return valid;
}

- (BOOL)ownsVisibleControl:(MBBubbleControl *)control {
    return control && self.window && !self.window.hidden && !control.hidden &&
        control.window == self.window && self.controls[@(control.conversation)] == control &&
        [self.order containsObject:@(control.conversation)];
}

- (BOOL)dismissControlIfAllowed:(MBBubbleControl *)control {
    if (self.purging) return NO;
    if (![self presentationIsCurrent]) { [self invalidatePresentation]; return NO; }
    if (![self ownsVisibleControl:control] || !self.didDismiss) return NO;
    self.didDismiss(control.conversation);
    return YES;
}

- (BOOL)renderModel:(const MBModel *)model {
    NSAssert(NSThread.isMainThread, @"Overlay must stay on main");
    if (!model || !model->allowed || !model->count || model->count > MB_MAX_CONVERSATIONS || ![self permitted]) {
        [self purgeImmediately]; return NO;
    }
    if (![self createWindowIfPossible]) return NO;
    // A bulletin can reorder/evict the dragged control. Restore its original
    // rail anchor before replacing order; stale recognizers cannot act on new UI.
    if (![self cancelActiveDragRestoringAnchor]) { [self invalidatePresentation]; return NO; }
    MBConversation sorted[MB_MAX_CONVERSATIONS];
    memcpy(sorted, model->items, sizeof(sorted));
    for (size_t i = 0; i < model->count; ++i) for (size_t j = i + 1; j < model->count; ++j) {
        if (sorted[j].recency > sorted[i].recency) {
            MBConversation temp = sorted[i]; sorted[i] = sorted[j]; sorted[j] = temp;
        }
    }
    NSMutableArray<NSNumber *> *keys = [NSMutableArray array];
    self.totalUnread = MBModelTotalObservedUnread(model);
    __weak MBOverlayController *weakSelf = self;
    for (size_t i = 0; i < model->count; ++i) {
        NSNumber *key = @(sorted[i].conversation);
        [keys addObject:key];
        MBBubbleControl *control = self.controls[key];
        if (!control) {
            control = [[MBBubbleControl alloc] initWithFrame:CGRectMake(0, 0, 54, 54)];
            control.hidden = YES; // Do not expose a new control before a valid layout.
            control.conversation = sorted[i].conversation;
            [control addTarget:self action:@selector(toggleRail:) forControlEvents:UIControlEventTouchUpInside];
            [control addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
            __weak MBBubbleControl *weakControl = control;
            control.accessibilityCustomActions = @[[[UIAccessibilityCustomAction alloc] initWithName:@"Đóng bong bóng"
                actionHandler:^BOOL(__unused UIAccessibilityCustomAction *action) {
                    return [weakSelf dismissControlIfAllowed:weakControl];
                }]];
            self.controls[key] = control;
            [self.canvas.view addSubview:control];
        }
        control.observedUnread = sorted[i].observedUnread;
        [control showObservedUnread:(!self.expanded && i == 0) ? self.totalUnread : control.observedUnread
                extraConversations:(!self.expanded && i == 0) ? model->count - 1 : 0];
    }
    for (NSNumber *key in self.controls.allKeys) {
        if (![keys containsObject:key]) { [self.controls[key] removeFromSuperview]; [self.controls removeObjectForKey:key]; }
    }
    self.order = keys;
    BOOL firstPresentation = self.window.hidden;
    [self.canvas.view setNeedsLayout];
    [self.canvas.view layoutIfNeeded];
    if (![self layoutAnimated:!firstPresentation]) return NO;
    // Only unhide after layout and scene/policy validation have succeeded.
    self.window.hidden = NO;
    return YES;
}

- (BOOL)layoutAnimated:(BOOL)animated {
    if (self.purging || !self.window) return NO;
    if (![self presentationIsCurrent]) { [self invalidatePresentation]; return NO; }
    MBRect safe = [self safeBounds];
    BOOL changed = self.hasGeometry && !MBSameRect(self.lastSafe, safe);
    if (changed) {
        // Rotation/safe-area changes invalidate recognizer coordinates. Cancel
        // without dismissal, then map dock side and relative height to new space.
        if (![self cancelActiveDragRestoringAnchor] ||
            !MBRemapAnchor(self.lastSafe, safe, MBBubbleRadius, self.anchor, &_anchor)) {
            [self invalidatePresentation]; return NO;
        }
    } else if (self.dragged) {
        return YES;
    }
    if (!self.hasAnchor) {
        self.anchor = (MBPoint){safe.x + safe.width - MBBubbleRadius, safe.y + safe.height * 0.25};
    }
    MBPoint positions[MB_MAX_CONVERSATIONS] = {0};
    size_t requested = self.expanded ? self.order.count : MIN((NSUInteger)1, self.order.count);
    size_t visible = MBRailCenters(safe, MBBubbleRadius, MBBubbleSpacing, self.anchor, requested, positions);
    if (!visible) { [self invalidatePresentation]; return NO; }
    self.anchor = positions[0];
    self.hasAnchor = YES;
    self.lastSafe = safe;
    self.hasGeometry = YES;
    MBPoint close;
    self.hasDismissTarget = MBDismissTargetCenter(safe, MBDismissTargetRadius, MBDismissTargetBottomInset, &close);
    if (self.hasDismissTarget) self.dismissTarget.center = CGPointMake(close.x, close.y);
    self.dismissTarget.hidden = YES;
    self.dismissTarget.backgroundColor = UIColor.systemGrayColor;
    NSData *positionData = [NSData dataWithBytes:positions length:sizeof(positions)];
    void (^layout)(void) = ^{
        const MBPoint *targets = positionData.bytes;
        for (NSUInteger i = 0; i < self.order.count; ++i) {
            MBBubbleControl *control = self.controls[self.order[i]];
            control.hidden = i >= visible;
            if (i < visible) control.center = CGPointMake(targets[i].x, targets[i].y);
            control.alpha = 1;
        }
    };
    if (animated && !UIAccessibilityIsReduceMotionEnabled()) {
        [UIView animateWithDuration:0.24 delay:0 usingSpringWithDamping:0.86 initialSpringVelocity:0
                            options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction
                         animations:layout completion:nil];
    } else { layout(); }
    return YES;
}

- (void)toggleRail:(MBBubbleControl *)control {
    // This opens only the real bubble rail, NOT a chat window. A single bubble
    // has no pretend open-chat action; accessibility explicitly explains this.
    if (self.purging) return;
    if (![self presentationIsCurrent]) { [self invalidatePresentation]; return; }
    if (![self ownsVisibleControl:control] || self.dragged || self.order.count < 2) return;
    self.expanded = !self.expanded;
    // Refresh badges without manufacturing read receipts or modifying counts.
    for (NSUInteger i = 0; i < self.order.count; ++i) {
        MBBubbleControl *bubble = self.controls[self.order[i]];
        [bubble showObservedUnread:(!self.expanded && i == 0) ? self.totalUnread : bubble.observedUnread
                extraConversations:(!self.expanded && i == 0) ? self.order.count - 1 : 0];
    }
    [self layoutAnimated:YES];
}

- (void)pan:(UIPanGestureRecognizer *)gesture {
    if (self.purging) return;
    if (![self presentationIsCurrent]) { [self invalidatePresentation]; return; }
    MBBubbleControl *control = (MBBubbleControl *)gesture.view;
    if (![control isKindOfClass:MBBubbleControl.class] || ![self ownsVisibleControl:control]) return;
    if (gesture.state != UIGestureRecognizerStateBegan && self.dragged != control) return;
    if (!self.hasGeometry || !MBSameRect(self.lastSafe, [self safeBounds])) {
        [self layoutAnimated:NO]; // Cancels any drag in the old coordinate space.
        return;
    }
    // An interrupted recognizer has no authority to move, fling or dismiss.
    if (gesture.state == UIGestureRecognizerStateCancelled || gesture.state == UIGestureRecognizerStateFailed) {
        if (![self cancelActiveDragRestoringAnchor]) { [self invalidatePresentation]; return; }
        [self layoutAnimated:YES];
        return;
    }
    if (gesture.state == UIGestureRecognizerStateBegan) {
        if (self.dragged) return;
        NSUInteger index = [self.order indexOfObject:@(control.conversation)];
        if (index == NSNotFound || index >= MB_MAX_CONVERSATIONS) return;
        self.dragIndex = self.expanded ? index : 0;
        self.dragAnchor = self.anchor;
        // Start from the visible spring position, not its future model target.
        CALayer *presented = control.layer.presentationLayer;
        CGPoint start = presented ? presented.position : control.center;
        MBPoint origin;
        if (!MBClampCenter(self.lastSafe, MBBubbleRadius, (MBPoint){start.x, start.y}, &origin)) {
            [self invalidatePresentation]; return;
        }
        self.dragged = control;
        self.dragOrigin = CGPointMake(origin.x, origin.y);
        [control.layer removeAllAnimations];
        [self.canvas.view bringSubviewToFront:control];
        self.dismissTarget.hidden = !self.hasDismissTarget;
    } else if (gesture.state != UIGestureRecognizerStateChanged && gesture.state != UIGestureRecognizerStateEnded) {
        return;
    }
    CGPoint translation = [gesture translationInView:self.canvas.view];
    MBPoint point = {self.dragOrigin.x + translation.x, self.dragOrigin.y + translation.y};
    MBPoint clamped;
    if (!MBClampCenter(self.lastSafe, MBBubbleRadius, point, &clamped)) { [self invalidatePresentation]; return; }
    control.center = CGPointMake(clamped.x, clamped.y);
    MBPoint target = {self.dismissTarget.center.x, self.dismissTarget.center.y};
    BOOL dismiss = self.hasDismissTarget && MBDismissHit(clamped, target, 60);
    self.dismissTarget.backgroundColor = dismiss ? UIColor.systemRedColor : UIColor.systemGrayColor;
    if (gesture.state == UIGestureRecognizerStateEnded) {
        self.dragged = nil;
        self.dismissTarget.hidden = YES;
        self.dismissTarget.backgroundColor = UIColor.systemGrayColor;
        if (dismiss && self.didDismiss) {
            self.didDismiss(control.conversation); // Removes only this bubble, not notification or chat.
        } else {
            MBPoint first;
            if (!MBResolveDragAnchor(self.lastSafe, MBBubbleRadius, MBBubbleSpacing, self.dragIndex,
                    false, self.dragAnchor, clamped, [gesture velocityInView:self.canvas.view].x, &first)) {
                [self invalidatePresentation]; return;
            }
            self.anchor = first;
            [self layoutAnimated:YES];
        }
    }
}

- (void)purgeImmediately {
    if (self.purging) return;
    self.purging = YES;
    // Clear callbacks/gesture ownership before hiding can trigger UIKit reentry.
    self.canvas.didLayout = nil;
    self.dragged = nil;
    self.hasGeometry = NO;
    self.hasDismissTarget = NO;
    // Hide/remove only UI owned by this tweak, without a privacy animation.
    // This makes no claim to erase ARC allocations or system-owned snapshots.
    self.window.hidden = YES;
    [self.window.layer removeAllAnimations];
    for (MBBubbleControl *control in self.controls.allValues) { [control.layer removeAllAnimations]; [control removeFromSuperview]; }
    [self.controls removeAllObjects];
    self.order = @[];
    self.expanded = NO;
    self.hasAnchor = NO;
    self.anchor = (MBPoint){0};
    self.lastSafe = (MBRect){0};
    self.dragAnchor = (MBPoint){0};
    self.dragOrigin = CGPointZero;
    self.dragIndex = 0;
    self.totalUnread = 0;
    self.window.rootViewController = nil;
    self.window = nil;
    self.canvas = nil;
    self.dismissTarget = nil;
    self.purging = NO;
}
@end
