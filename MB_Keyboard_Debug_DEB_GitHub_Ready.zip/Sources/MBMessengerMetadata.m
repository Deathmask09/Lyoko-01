// SPDX-License-Identifier: MIT
#import "MBMessengerMetadata.h"
#import "MBMessengerMetadataSQL.h"
#include <string.h>

@interface MBMessengerCryptoThreadMetadata ()
@property(nonatomic, readwrite, copy) NSString *accountID, *modelID, *transportThreadID;
@property(nonatomic, readwrite) int64_t clientPK, localThreadKey, observedUnread;
@property(nonatomic, readwrite) BOOL groupThread;
@property(nonatomic, readwrite, copy, nullable) NSString *avatarReference, *avatarFallbackReference;
- (instancetype)initPrivate;
@end
@implementation MBMessengerCryptoThreadMetadata
- (instancetype)initPrivate { return [super init]; }
@end

static MBMessengerCryptoThreadMetadata *MBMetadataFailure(NSError **error, NSInteger code) {
    if (error) *error = [NSError errorWithDomain:@"com.lyoko-01.messengerbubbles.metadata" code:code
        userInfo:@{NSLocalizedDescriptionKey:@"Metadata unavailable or snapshot contract not satisfied."}];
    return nil; // Fixed error text, never include a path, ID, URL or SQLite value.
}
static BOOL MBMetadataIdentifier(NSString *text, BOOL account) {
    if (![text isKindOfClass:NSString.class] || text.length == 0 || text.length > (account ? 64 : 512)) return NO;
    for (NSUInteger i = 0; i < text.length; ++i) {
        unichar c = [text characterAtIndex:i];
        if (account ? (c < '0' || c > '9') : (c < 0x21 || c > 0x7e)) return NO;
    }
    return YES;
}
static NSString *MBMetadataText(sqlite3_stmt *statement, int column, int maximum) {
    if (sqlite3_column_type(statement, column) != SQLITE_TEXT) return nil;
    int count = sqlite3_column_bytes(statement, column);
    const unsigned char *bytes = sqlite3_column_text(statement, column);
    if (!bytes || count <= 0 || count > maximum || memchr(bytes, 0, (size_t)count)) return nil;
    return [[NSString alloc] initWithBytes:bytes length:(NSUInteger)count encoding:NSUTF8StringEncoding];
}
static NSString *MBMetadataSingleAvatar(NSString *text) {
    if (!text.length || text.length > 4096 ||
        [text rangeOfCharacterFromSet:NSCharacterSet.whitespaceAndNewlineCharacterSet].location != NSNotFound ||
        [text containsString:@","] || [text containsString:@"["] || [text containsString:@"]"]) return nil;
    NSURLComponents *url = [NSURLComponents componentsWithString:text];
    if (![url.scheme.lowercaseString isEqualToString:@"https"] || !url.host.length || url.user || url.password || url.fragment) return nil;
    // Keep the opaque reference only. Fetching, expiry validation, CDN policy and
    // cache generations belong to the future verified avatar source, not here.
    return text;
}
MBMessengerCryptoThreadMetadata *MBMessengerReadCryptoThreadMetadata(sqlite3 *database,
    NSString *account, NSString *transportID, NSError **error) {
    if (error) *error = nil;
    if (!database || NSThread.isMainThread || !MBMetadataIdentifier(account, YES) ||
        !MBMetadataIdentifier(transportID, NO) || sqlite3_db_readonly(database, "main") != 1 ||
        sqlite3_get_autocommit(database) != 0) return MBMetadataFailure(error, 1);
    sqlite3_stmt *statement = NULL;
    int prepared = sqlite3_prepare_v2(database, MBMessengerCryptoMetadataSQL, -1, &statement, NULL);
    if (prepared != SQLITE_OK || !statement || !sqlite3_stmt_readonly(statement)) {
        if (statement) sqlite3_finalize(statement);
        return MBMetadataFailure(error, 2);
    }
    int bound = sqlite3_bind_text(statement, 1, transportID.UTF8String, -1, SQLITE_TRANSIENT);
    if (bound != SQLITE_OK || sqlite3_step(statement) != SQLITE_ROW) {
        sqlite3_finalize(statement); return MBMetadataFailure(error, 3);
    }
    BOOL integerKeys = sqlite3_column_type(statement, 0) == SQLITE_INTEGER && sqlite3_column_type(statement, 1) == SQLITE_INTEGER;
    int64_t clientPK = sqlite3_column_int64(statement, 0), localKey = sqlite3_column_int64(statement, 1);
    NSString *actualID = MBMetadataText(statement, 2, 512);
    int64_t group = sqlite3_column_int64(statement, 3);
    BOOL groupValid = sqlite3_column_type(statement, 3) == SQLITE_INTEGER && (group == 0 || group == 1);
    if (!integerKeys || clientPK <= 0 || ![actualID isEqualToString:transportID] || !groupValid) {
        sqlite3_finalize(statement); return MBMetadataFailure(error, 4);
    }
    MBMessengerCryptoThreadMetadata *row = [[MBMessengerCryptoThreadMetadata alloc] initPrivate];
    row.accountID = account; row.transportThreadID = actualID;
    row.modelID = [NSString stringWithFormat:@"account:%lu:%@|act:%lu:%@", (unsigned long)account.length,
        account, (unsigned long)actualID.length, actualID];
    row.clientPK = clientPK; row.localThreadKey = localKey; row.groupThread = group == 1;
    row.observedUnread = sqlite3_column_type(statement, 4) == SQLITE_INTEGER ? sqlite3_column_int64(statement, 4) : -1;
    row.avatarReference = MBMetadataSingleAvatar(MBMetadataText(statement, 5, 4096));
    row.avatarFallbackReference = MBMetadataSingleAvatar(MBMetadataText(statement, 6, 4096));
    // LIMIT 2 detects ambiguous mappings instead of arbitrarily taking the first.
    int next = sqlite3_step(statement);
    sqlite3_finalize(statement);
    if (next != SQLITE_DONE) return MBMetadataFailure(error, 5);
    return row;
}
