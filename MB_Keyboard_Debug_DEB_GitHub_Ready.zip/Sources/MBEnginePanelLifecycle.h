// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>
#include <stdint.h>

// Cache a viewport only within the SAME presentation, not just the same app
// scene/size. A collapse/reopen can reuse both while replacing the presenter.
static inline bool MBEnginePanelStateReusable(bool sameScene, bool sameTarget,
    uint64_t stateEpoch, uint64_t currentEpoch,
    uint64_t statePresentation, uint64_t currentPresentation) {
    return sameScene && sameTarget && stateEpoch == currentEpoch &&
        statePresentation == currentPresentation;
}

// Initial transaction plus at most two repairs of a competing native update.
// The caller also retains the existing absolute four-second host-watch deadline.
#define MB_ENGINE_PANEL_REQUEST_LIMIT 3u
static inline bool MBEnginePanelMayRequest(unsigned attempts, bool pending, bool withinDeadline) {
    return !pending && withinDeadline && attempts < MB_ENGINE_PANEL_REQUEST_LIMIT;
}

// A correctly sized OLD buffer is not acknowledgement of scene configuration.
static inline bool MBEnginePanelMayFinish(bool settingsWritten, bool sceneMatches, bool bufferMatches) {
    return settingsWritten && sceneMatches && bufferMatches;
}
