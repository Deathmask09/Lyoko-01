// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#include <stdint.h>

// A shape-only snapshot: no object, string, ID, numeric value, URL or image bytes.
typedef NS_ENUM(uint8_t, MBHybridShapeKind) {
    MBHybridShapeMissing, MBHybridShapeNull, MBHybridShapeString,
    MBHybridShapeNumber, MBHybridShapeBoolean, MBHybridShapeDictionary,
    MBHybridShapeArray, MBHybridShapeData, MBHybridShapeOpaque,
};
typedef NS_ENUM(uint8_t, MBHybridShapeField) {
    MBHybridShapeThread, MBHybridShapeGroup, MBHybridShapeAvatar,
    MBHybridShapeUnread, MBHybridShapeBadge, MBHybridShapeMessage, MBHybridShapeFieldCount,
};
typedef struct { uint8_t key, container, kind; } MBHybridShapeHit;
typedef struct {
    uint8_t rootKind, dictionaries, truncated, exception;
    MBHybridShapeHit fields[MBHybridShapeFieldCount];
} MBHybridShape;
FOUNDATION_EXPORT MBHybridShapeKind MBHybridValueKind(id value);
FOUNDATION_EXPORT MBHybridShape MBHybridInspectShape(id payload);
// These names are fixed source literals, never values supplied by a notification.
FOUNDATION_EXPORT const char *MBHybridShapeKeyName(unsigned key);
FOUNDATION_EXPORT const char *MBHybridShapeFieldName(unsigned field);
FOUNDATION_EXPORT const char *MBHybridShapeContainerName(unsigned container);
