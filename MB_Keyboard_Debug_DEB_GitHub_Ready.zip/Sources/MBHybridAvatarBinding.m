// SPDX-License-Identifier: MIT
#import "MBHybridAvatarBinding.h"
@interface MBHybridAvatarBinding ()
@property(nonatomic, weak) UIImageView *imageView;
@property(nonatomic, strong) MBHybridAvatarCache *cache;
@property(nonatomic, strong) id<MBHybridAvatarTask> task;
@property(nonatomic, copy) NSString *threadID, *avatarKey;
@property(nonatomic) uint64_t generation;
@end
@implementation MBHybridAvatarBinding
- (instancetype)initWithImageView:(UIImageView *)imageView cache:(MBHybridAvatarCache *)cache {
    if (!imageView || !cache) return nil;
    if ((self = [super init])) { _imageView = imageView; _cache = cache; }
    return self;
}
- (void)prepareForReuse {
    if (!NSThread.isMainThread) return;
    ++self.generation;
    [self.task cancel]; self.task = nil;
    self.threadID = nil; self.avatarKey = nil; self.imageView.image = nil;
}
- (void)bindThreadID:(NSString *)threadID avatarKey:(NSString *)avatarKey {
    if (!NSThread.isMainThread) return;
    BOOL valid = [threadID isKindOfClass:NSString.class] && threadID.length && threadID.length <= 256 &&
        [avatarKey isKindOfClass:NSString.class] && avatarKey.length && avatarKey.length <= 512;
    if (!valid) { [self prepareForReuse]; return; }
    NSString *stableThread = [threadID copy], *stableKey = [avatarKey copy];
    if ([stableThread isEqualToString:self.threadID] && [stableKey isEqualToString:self.avatarKey]) return;
    [self prepareForReuse]; // Clear A immediately, before B's async/cache callback.
    self.threadID = stableThread; self.avatarKey = stableKey;
    uint64_t generation = self.generation;
    __weak typeof(self) weakSelf = self;
    self.task = [self.cache requestKey:stableKey completion:^(UIImage *image) {
        MBHybridAvatarBinding *binding = weakSelf;
        if (!binding || binding.generation != generation ||
            ![binding.threadID isEqualToString:stableThread] || ![binding.avatarKey isEqualToString:stableKey]) return;
        binding.imageView.image = image;
        binding.task = nil;
    }];
}
- (void)dealloc { [_task cancel]; }
@end
