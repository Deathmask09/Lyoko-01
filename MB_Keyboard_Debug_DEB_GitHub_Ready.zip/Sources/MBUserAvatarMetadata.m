// SPDX-License-Identifier: MIT
#import "MBUserAvatarMetadata.h"
#import "MBMessengerMetadataSQL.h"
#include <string.h>

@interface MBUserAvatarMetadata ()
@property(nonatomic, readwrite, copy) NSString *accountID, *subjectID, *reference;
@property(nonatomic, readwrite, copy, nullable) NSString *fallbackReference;
@property(nonatomic, readwrite) BOOL groupSubject;
@property(nonatomic, readwrite) int64_t expirationTimestampMS;
- (instancetype)initPrivate;
@end
@implementation MBUserAvatarMetadata
- (instancetype)initPrivate { return [super init]; }
@end

static MBUserAvatarMetadata *MBUserAvatarMetadataFailure(NSError **error, NSInteger code) {
    if (error) *error = [NSError errorWithDomain:@"com.lyoko-01.messengerbubbles.avatar-metadata"
        code:code userInfo:@{NSLocalizedDescriptionKey:@"Avatar identity unavailable or snapshot contract not satisfied."}];
    return nil; // No identifier, URL, path or SQLite value in errors/logs.
}
static sqlite3_stmt *MBUserAvatarStatement(sqlite3 *database, const char *sql) {
    sqlite3_stmt *statement = NULL;
    if (sqlite3_prepare_v2(database, sql, -1, &statement, NULL) != SQLITE_OK || !statement ||
        !sqlite3_stmt_readonly(statement)) {
        if (statement) sqlite3_finalize(statement);
        return NULL;
    }
    return statement;
}
static NSString *MBUserAvatarText(sqlite3_stmt *statement, int column) {
    if (sqlite3_column_type(statement, column) != SQLITE_TEXT) return nil;
    int size = sqlite3_column_bytes(statement, column);
    const unsigned char *bytes = sqlite3_column_text(statement, column);
    if (!bytes || size <= 0 || size > 4096 || memchr(bytes, 0, (size_t)size)) return nil;
    NSString *text = [[NSString alloc] initWithBytes:bytes length:(NSUInteger)size encoding:NSUTF8StringEncoding];
    if (!text || [text rangeOfCharacterFromSet:NSCharacterSet.whitespaceAndNewlineCharacterSet].location != NSNotFound ||
        [text containsString:@","] || [text containsString:@"["] || [text containsString:@"]"]) return nil;
    NSURLComponents *url = [NSURLComponents componentsWithString:text];
    if (![url.scheme.lowercaseString isEqualToString:@"https"] || !url.host.length || url.user || url.password || url.fragment) return nil;
    return text;
}
static int64_t MBUserAvatarPositiveInteger(sqlite3_stmt *statement, int column) {
    if (sqlite3_column_type(statement, column) != SQLITE_INTEGER) return -1;
    int64_t number = sqlite3_column_int64(statement, column);
    return number > 0 ? number : -1;
}
static int64_t MBUserAvatarOwner(sqlite3 *database, NSString *accountID) {
    sqlite3_stmt *statement = MBUserAvatarStatement(database, MBMessengerAvatarOwnerSQL);
    if (!statement) return -1;
    int64_t owner = sqlite3_step(statement) == SQLITE_ROW ? MBUserAvatarPositiveInteger(statement, 0) : -1;
    NSString *canonical = owner > 0 ? [NSString stringWithFormat:@"%lld", (long long)owner] : nil;
    BOOL valid = [canonical isEqualToString:accountID] && sqlite3_step(statement) == SQLITE_DONE;
    sqlite3_finalize(statement);
    return valid ? owner : -1;
}
MBUserAvatarMetadata *MBUserAvatarReadForTransport(sqlite3 *database, NSString *accountID,
    NSString *transportID, NSError **error) {
    if (error) *error = nil;
    if (!database || NSThread.isMainThread || ![accountID isKindOfClass:NSString.class] ||
        !accountID.length || accountID.length > 64 || ![transportID isKindOfClass:NSString.class] ||
        !transportID.length || transportID.length > 512 || sqlite3_db_readonly(database, "main") != 1 ||
        sqlite3_get_autocommit(database) != 0) return MBUserAvatarMetadataFailure(error, 1);
    for (NSUInteger i = 0; i < transportID.length; ++i) {
        unichar c = [transportID characterAtIndex:i];
        if (c < 0x21 || c > 0x7e) return MBUserAvatarMetadataFailure(error, 1);
    }
    int64_t owner = MBUserAvatarOwner(database, accountID);
    if (owner <= 0) return MBUserAvatarMetadataFailure(error, 2);
    sqlite3_stmt *statement = MBUserAvatarStatement(database, MBMessengerAvatarThreadSQL);
    if (!statement) return MBUserAvatarMetadataFailure(error, 3);
    int bound = sqlite3_bind_text(statement, 1, transportID.UTF8String, -1, SQLITE_TRANSIENT);
    if (bound != SQLITE_OK || sqlite3_step(statement) != SQLITE_ROW) {
        sqlite3_finalize(statement); return MBUserAvatarMetadataFailure(error, 3);
    }
    int64_t threadPK = MBUserAvatarPositiveInteger(statement, 0);
    int idType = sqlite3_column_type(statement, 1);
    const unsigned char *actualID = sqlite3_column_text(statement, 1);
    int idSize = sqlite3_column_bytes(statement, 1);
    BOOL validID = idType == SQLITE_TEXT && actualID && idSize > 0 &&
        idSize <= 512 && !memchr(actualID, 0, (size_t)idSize);
    NSString *actual = validID ? [[NSString alloc] initWithBytes:actualID length:(NSUInteger)idSize encoding:NSUTF8StringEncoding] : nil;
    int64_t groupValue = sqlite3_column_int64(statement, 2);
    BOOL valid = threadPK > 0 && [actual isEqualToString:transportID] &&
        sqlite3_column_type(statement, 2) == SQLITE_INTEGER && (groupValue == 0 || groupValue == 1);
    BOOL group = groupValue == 1;
    NSString *subject = group ? actual : nil;
    NSString *reference = group ? MBUserAvatarText(statement, 3) : nil;
    NSString *fallback = group ? MBUserAvatarText(statement, 4) : nil;
    int64_t expiry = group ? MBUserAvatarPositiveInteger(statement, 5) : -1;
    int next = sqlite3_step(statement); sqlite3_finalize(statement);
    if (!valid || next != SQLITE_DONE) return MBUserAvatarMetadataFailure(error, 4);
    if (!group) {
        statement = MBUserAvatarStatement(database, MBMessengerPersonAvatarSQL);
        if (!statement) return MBUserAvatarMetadataFailure(error, 5);
        bound = sqlite3_bind_int64(statement, 1, threadPK);
        if (bound == SQLITE_OK) bound = sqlite3_bind_int64(statement, 2, owner);
        if (bound != SQLITE_OK || sqlite3_step(statement) != SQLITE_ROW) {
            sqlite3_finalize(statement); return MBUserAvatarMetadataFailure(error, 5);
        }
        int64_t participant = MBUserAvatarPositiveInteger(statement, 0);
        int64_t clientContact = MBUserAvatarPositiveInteger(statement, 2);
        int64_t serverUser = MBUserAvatarPositiveInteger(statement, 3);
        int64_t contactUser = MBUserAvatarPositiveInteger(statement, 4);
        valid = participant > 0 && participant == clientContact && serverUser > 0 &&
            serverUser == contactUser && serverUser != owner &&
            sqlite3_column_type(statement, 1) == SQLITE_INTEGER && sqlite3_column_int64(statement, 1) == 0;
        if (valid) subject = [NSString stringWithFormat:@"%lld", (long long)serverUser];
        reference = MBUserAvatarText(statement, 5); fallback = MBUserAvatarText(statement, 6);
        expiry = MBUserAvatarPositiveInteger(statement, 7);
        // Retain unresolved other participants; do not silently select LIMIT1.
        next = sqlite3_step(statement); sqlite3_finalize(statement);
        if (!valid || next != SQLITE_DONE) return MBUserAvatarMetadataFailure(error, 6);
    }
    if (!reference) { reference = fallback; fallback = nil; expiry = -1; } // Primary expiry does not describe the fallback URL.
    if (!reference || !subject.length) return MBUserAvatarMetadataFailure(error, 7);
    MBUserAvatarMetadata *metadata = [[MBUserAvatarMetadata alloc] initPrivate];
    metadata.accountID = accountID; metadata.subjectID = subject; metadata.groupSubject = group;
    metadata.reference = reference; metadata.fallbackReference = fallback; metadata.expirationTimestampMS = expiry;
    return metadata;
}
