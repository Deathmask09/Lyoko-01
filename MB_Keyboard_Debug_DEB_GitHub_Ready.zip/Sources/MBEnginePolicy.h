// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>

// The engine hosts one APPLICATION, not individual Messenger threads.
bool MBEngineAllowsBundle(const char *bundle, bool enabled, bool userSession);
// Transient new-notification count for this bubble session, not server unread.
#define MB_ENGINE_INCOMING_COUNT_CAP 100u // rendered as 99+
unsigned MBEngineNextIncomingCount(unsigned current, bool realEvent, bool panelOpen);
bool MBEngineWatchMayContinue(double start, double now, bool userSession);

typedef enum {
    MBEngineForegroundUnknown = 0,
    MBEngineForegroundElsewhere = 1, // Home or a known different app.
    MBEngineForegroundMessenger = 2
} MBEngineForeground;
bool MBEngineShouldAutoBubble(bool enabled, bool unlocked, bool captured, MBEngineForeground foreground);
bool MBEngineEventIsFresh(double eventTime, double now);
bool MBEngineIngressMayDispatch(unsigned long long capturedEpoch, unsigned long long currentEpoch,
                               double received, double now);
#define MB_ENGINE_DEBUG_TEST_DELAY 10.0
bool MBEngineDebugTestMayFire(unsigned long long capturedEpoch, unsigned long long currentEpoch,
                            double scheduled, double now, bool enabled);
