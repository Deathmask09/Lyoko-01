// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>
#include <stdint.h>

// Pure geometry policy for the isolated keyboard patch. These expressions are
// shared with compile-time fixtures, not duplicated in Python. Arguments must be
// stable scalar values without side effects. No UI, timer, rendering or I/O.
#define MB_KV_POINT_OK(value) ((value) >= 1.0 && (value) <= 4096.0)
#define MB_KV_PIXEL_OK(value) ((value) >= 1.0 && (value) <= 32768.0)
#define MB_KV_SCALE(points, pixels) ((1.0 * (pixels)) / (points))
#define MB_KV_HEIGHT_ERROR(sw, sh, pw, ph) ((sh) * MB_KV_SCALE(sw, pw) - (ph))
#define MB_KV_SOURCE_OK(sw, sh, pw, ph) \
    (MB_KV_POINT_OK(sw) && MB_KV_POINT_OK(sh) && MB_KV_PIXEL_OK(pw) && MB_KV_PIXEL_OK(ph) && \
     MB_KV_SCALE(sw, pw) >= 1.0 && MB_KV_SCALE(sw, pw) <= 4.0 && \
     MB_KV_SCALE(sh, ph) >= 1.0 && MB_KV_SCALE(sh, ph) <= 4.0 && \
     MB_KV_HEIGHT_ERROR(sw, sh, pw, ph) >= -1.0 && MB_KV_HEIGHT_ERROR(sw, sh, pw, ph) <= 1.0)
#define MB_KV_PROJECTION_OK(sw, sh, pw, ph, tw, th) \
    (MB_KV_SOURCE_OK(sw, sh, pw, ph) && MB_KV_POINT_OK(tw) && MB_KV_POINT_OK(th))
// Only called after validation: max 4096pt * 4 = 16384px, so no uint32 overflow.
// Both axes use the SAME source scale. Rounding is <= 0.5 physical pixel per axis.
#define MB_KV_ROUND_PIXELS(points, scale) ((uint32_t)((1.0 * (points)) * (scale) + 0.5))

typedef struct {
    uint32_t widthPixels, heightPixels;
    double scale;
} MBKeyboardViewportProjection;

static inline bool MBKeyboardProjectViewportPixels(double sourceWidth, double sourceHeight,
                                                    double sourcePixelsWidth, double sourcePixelsHeight,
                                                    double targetWidth, double targetHeight,
                                                    MBKeyboardViewportProjection *out) {
    if (!out || !MB_KV_PROJECTION_OK(sourceWidth, sourceHeight, sourcePixelsWidth, sourcePixelsHeight,
                                    targetWidth, targetHeight)) return false;
    // Range comparisons also reject NaN and infinities before divisions/casts.
    double scale = MB_KV_SCALE(sourceWidth, sourcePixelsWidth);
    *out = (MBKeyboardViewportProjection){MB_KV_ROUND_PIXELS(targetWidth, scale),
                                         MB_KV_ROUND_PIXELS(targetHeight, scale), scale};
    return true;
}
