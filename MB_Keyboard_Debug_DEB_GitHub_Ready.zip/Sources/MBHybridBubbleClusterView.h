// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
#import "MBHybridBubbleManager.h"
#import "MBHybridAvatarCache.h"
NS_ASSUME_NONNULL_BEGIN
// Passive reusable content view, NOT another window/panel/scene. The verified
// engine integration must attach exactly one instance and provide its layout.
// Owns manager.onChange while displayed. Main queue only; no fake events.
@interface MBHybridBubbleClusterView : UIView
@property(nonatomic) CGFloat maximumPickerWidth;
- (instancetype)initWithManager:(MBHybridBubbleManager *)manager avatarCache:(MBHybridAvatarCache *)cache;
@end
NS_ASSUME_NONNULL_END
