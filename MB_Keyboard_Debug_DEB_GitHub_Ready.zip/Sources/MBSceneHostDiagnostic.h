// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdatomic.h>

// Passive metadata catalog only. No scene lookup/getter invocation, instances,
// attachment, settings mutation, input forwarding or policy decisions.
typedef NS_ENUM(unsigned, MBSceneHostImage) {
    MBSceneHostUIKitCore = 0, MBSceneHostFrontBoard, MBSceneHostFrontBoardServices,
    MBSceneHostImageCount,
};
typedef NS_ENUM(unsigned, MBSceneHostImageState) {
    MBSceneHostImageUnknown = 0, MBSceneHostImageLoaded,
    MBSceneHostImageNotLoaded, MBSceneHostImageLimit,
};
typedef NS_ENUM(unsigned, MBSceneHostMetadataStatus) {
    MBSceneHostMetadataMatch = 0,
    MBSceneHostFactsUnavailable, MBSceneHostProcessMismatch,
    // First failing guard only, using existing facts. Never log actual values
    // or weaken process identity. The generic mismatch remains a valid enum.
    MBSceneHostBundleIdentifierMismatch, MBSceneHostPackageTypeMismatch,
    MBSceneHostExecutableNameMismatch, MBSceneHostExtensionProcess,
    MBSceneHostMainTypeMismatch, MBSceneHostMainPathMismatch, MBSceneHostBundlePathMismatch,
    MBSceneHostOSMismatch,
    MBSceneHostImageUnavailable, MBSceneHostImageAbsent, MBSceneHostImageScanLimit,
    MBSceneHostClassMissing, MBSceneHostSuperclassMismatch, MBSceneHostClassImageMismatch,
    MBSceneHostMethodMissing, MBSceneHostABIMismatch, MBSceneHostIMPImageMismatch,
    MBSceneHostProtocolMissing, MBSceneHostProtocolMethodMissing, MBSceneHostProtocolABIMismatch,
    MBSceneHostInspectionLimit, MBSceneHostInspectionException,
    // Append only: preserve earlier numeric values and the generic legacy
    // mismatch. Both refine the same rejection, never an acceptance fallback.
    MBSceneHostIMPBaseMismatch, MBSceneHostIMPPathMismatch,
    MBSceneHostStatusMax = MBSceneHostIMPPathMismatch,
};
typedef NS_ENUM(unsigned, MBSceneHostContractKind) {
    MBSceneHostInstanceMethod = 0, MBSceneHostClassMethod,
    MBSceneHostProtocolInstanceMethod,
};
typedef struct {
    const char *feature, *className, *selectorName, *returnType;
    const char *argumentTypes[4];
    unsigned argumentCount;
    MBSceneHostImage image;
    MBSceneHostContractKind kind;
    // Optional immediate superclass check; no class objects are messaged.
    const char *superclassName;
    // iOS 17 header-only rows are not observed 16.5 metadata.
    BOOL referenceOnly;
} MBSceneHostContract;
#define MB_SCENE_HOST_CATALOG_MAX 96u
#define MB_SCENE_HOST_INSPECTION_MAX 4096u
// INITIAL diagnostic lines only, excluding retained Apelin marker/hook messages.
// Readout replay has a separate finite budget in the readout module:
// one arming + at most three progress + process + complete, then catalog rows.
#define MB_SCENE_HOST_PROGRESS_MAX 3u
#define MB_SCENE_HOST_LOG_OVERHEAD (1u + MB_SCENE_HOST_PROGRESS_MAX + 2u)
#define MB_SCENE_HOST_LOG_LINE_MAX (MB_SCENE_HOST_CATALOG_MAX + MB_SCENE_HOST_LOG_OVERHEAD)

// Finite observations only, not process authorization or a replacement guard.
// No address/path/raw Mach-O value is retained in a report. Zero means that
// collection did not reach this observation, not a negative runtime outcome.
typedef NS_ENUM(unsigned, MBSceneMainHeaderRead) {
    MBSceneMainHeaderUnobserved = 0, MBSceneMainHeaderMissing,
    MBSceneMainHeaderUnreadable, MBSceneMainHeaderCopied,
};
typedef NS_ENUM(unsigned, MBSceneMainMagic) {
    MBSceneMainMagicUnobserved = 0, MBSceneMainMagicNative32, MBSceneMainMagicNative64,
    MBSceneMainMagicSwapped32, MBSceneMainMagicSwapped64, MBSceneMainMagicOther,
};
typedef NS_ENUM(unsigned, MBSceneMainFileType) {
    MBSceneMainTypeUnobserved = 0, MBSceneMainTypeExecute, MBSceneMainTypeDylib,
    MBSceneMainTypeDylinker, MBSceneMainTypeBundle, MBSceneMainTypeOther,
};
typedef NS_ENUM(unsigned, MBSceneMainPath) {
    MBSceneMainPathUnobserved = 0, MBSceneMainPathMatch, MBSceneMainPathMismatch,
};
typedef struct {
    MBSceneMainHeaderRead headerRead;
    MBSceneMainMagic magic;
    MBSceneMainFileType fileType;
    MBSceneMainPath bundleExecutablePath, mainExecutablePath, bundleLocation;
} MBSceneMainImageObservation;

typedef struct {
    char bundleIdentifier[96], packageType[8], executableName[64];
    NSInteger osMajor, osMinor, osPatch;
    BOOL isExtension, mainIsExecutable, mainMatchesBundle, systemSpringBoardBundle;
    MBSceneMainImageObservation mainImage;
    MBSceneHostImageState imageStates[MBSceneHostImageCount];
    const void *imageHeaders[MBSceneHostImageCount];
} MBSceneHostProcessFacts;
// Trusted synchronous collector input, not IPC/prefs or an alternate identity
// authority. Production gets header from CRT _NSGetMachExecuteHeader, and base/
// path from one successful dladdr(header). Inputs stay valid until return.
// No pointer or path is retained in facts.mainImage or in any report.
typedef struct {
    const void *header, *resolvedImageBase;
    const char *resolvedImagePath, *bundleExecutablePath, *bundlePath;
} MBSceneMainExecutableInput;
FOUNDATION_EXPORT void MBApplySceneMainExecutableFacts(MBSceneHostProcessFacts *, MBSceneMainExecutableInput);
// Trusted synchronous resolved-origin facts, not IPC/prefs. Production supplies
// these from its existing single dladdr call. Borrowed strings must be valid if
// reached; bases are compared, never dereferenced or retained in a report.
// Class-only class_getImageName remains lazy in the verifier, outside this seam.
typedef struct {
    const void *expectedImageBase, *resolvedImageBase;
    const char *resolvedImagePath;
    BOOL isMethod;
} MBSceneHostOriginInput;
FOUNDATION_EXPORT MBSceneHostMetadataStatus MBClassifySceneHostResolvedOrigin(MBSceneHostImage, MBSceneHostOriginInput);
typedef struct {
    MBSceneHostMetadataStatus processStatus;
    MBSceneMainImageObservation mainImage;
    MBSceneHostMetadataStatus items[MB_SCENE_HOST_CATALOG_MAX];
    size_t count;
} MBSceneHostDiagnosticReport;

// Trusted offline seams, never exposed through preferences/IPC. Raw non-owning
// handles avoid ARC retain/autorelease and private +initialize side effects.
typedef BOOL (*MBSceneHostFactCollector)(MBSceneHostProcessFacts *, void *);
typedef void *(*MBSceneHostClassLookup)(const char *, void *);
typedef void *(*MBSceneHostProtocolLookup)(const char *, void *);
typedef MBSceneHostMetadataStatus (*MBSceneHostOriginVerifier)(void *, Method,
    MBSceneHostImage, const MBSceneHostProcessFacts *, void *);
typedef void (*MBSceneHostDiagnosticSink)(const MBSceneHostDiagnosticReport *, void *);
typedef void (*MBSceneHostDiagnosticEnqueue)(dispatch_block_t, void *);
// Finite provenance/progress only. A lifecycle event is not proof that a scene
// can be hosted. Never accept trigger strings or expose this through IPC/prefs.
typedef NS_ENUM(unsigned, MBSceneHostDiagnosticTrigger) {
    MBSceneHostTriggerUnknown = 0, MBSceneHostTriggerPublicLaunch,
    MBSceneHostTriggerPublicActive, MBSceneHostTriggerSpringBoardLaunchHook,
    MBSceneHostTriggerPublicActiveCatchUp,
};
typedef NS_ENUM(unsigned, MBSceneHostDiagnosticStage) {
    MBSceneHostStageAccepted = 0, MBSceneHostStageExecuting, MBSceneHostStageFinished,
    MBSceneHostStageEnqueueException, MBSceneHostStageDeliveryException,
};
typedef void (*MBSceneHostDiagnosticProgress)(MBSceneHostDiagnosticStage,
    MBSceneHostDiagnosticTrigger, void *);
typedef struct {
    MBSceneHostFactCollector collect;
    MBSceneHostClassLookup lookup;
    MBSceneHostProtocolLookup protocolLookup;
    MBSceneHostOriginVerifier origin;
    MBSceneHostDiagnosticSink sink;
    MBSceneHostDiagnosticEnqueue enqueue;
    MBSceneHostDiagnosticProgress progress; // optional, trusted offline seam
    MBSceneHostDiagnosticTrigger trigger;
    void *context; // caller keeps this alive until the executor has finished
} MBSceneHostDiagnosticDependencies;
typedef struct { atomic_uint phase; } MBSceneHostDiagnosticOnce;
#define MB_SCENE_HOST_DIAGNOSTIC_ONCE_INIT { .phase = ATOMIC_VAR_INIT(0) }

// Copies only sizeof(mach_header) from the current task via vm_read_overwrite;
// never dereferences or retains the borrowed address. Paths remain unobserved.
FOUNDATION_EXPORT MBSceneMainImageObservation MBObserveSceneMainHeader(const void *address);
FOUNDATION_EXPORT BOOL MBSceneMainImageObservationIsValid(MBSceneMainImageObservation);
FOUNDATION_EXPORT const char *MBSceneMainHeaderReadName(MBSceneMainHeaderRead);
FOUNDATION_EXPORT const char *MBSceneMainMagicName(MBSceneMainMagic);
FOUNDATION_EXPORT const char *MBSceneMainFileTypeName(MBSceneMainFileType);
FOUNDATION_EXPORT const char *MBSceneMainPathName(MBSceneMainPath);
FOUNDATION_EXPORT size_t MBSceneHostCatalogCount(void);
FOUNDATION_EXPORT const MBSceneHostContract *MBSceneHostCatalogItem(size_t index);
FOUNDATION_EXPORT const char *MBSceneHostExpectedImage(MBSceneHostImage image);
FOUNDATION_EXPORT BOOL MBCollectSceneHostProcessFacts(MBSceneHostProcessFacts *, void *);
FOUNDATION_EXPORT MBSceneHostMetadataStatus MBVerifySceneHostLoadedOrigin(void *, Method,
    MBSceneHostImage, const MBSceneHostProcessFacts *, void *);
FOUNDATION_EXPORT MBSceneHostDiagnosticReport MBEvaluateSceneHostDiagnostic(MBSceneHostDiagnosticDependencies);
FOUNDATION_EXPORT BOOL MBQueueSceneHostDiagnostic(MBSceneHostDiagnosticOnce *, MBSceneHostDiagnosticDependencies);
FOUNDATION_EXPORT const char *MBSceneHostDiagnosticReason(MBSceneHostMetadataStatus);
FOUNDATION_EXPORT const char *MBSceneHostDiagnosticDisposition(MBSceneHostMetadataStatus);
FOUNDATION_EXPORT const char *MBSceneHostDiagnosticTriggerName(MBSceneHostDiagnosticTrigger);
FOUNDATION_EXPORT const char *MBSceneHostDiagnosticStageName(MBSceneHostDiagnosticStage);

// Fixed production dependencies and actual main-bundle/dyld/OS facts. All
// lifecycle sources share one attempt/process; no retry or framework loading.
// finished means the report sink returned, not that a log reader received it.
FOUNDATION_EXPORT void MBStartPassiveSceneHostDiagnostic(MBSceneHostDiagnosticTrigger trigger);
// Emits a retained metadata-only report; replay does not collect or re-cache.
// Caller owns a valid immutable report for the entire synchronous call.
FOUNDATION_EXPORT void MBEmitSceneHostDiagnosticReport(const MBSceneHostDiagnosticReport *, BOOL replay);
