// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
// Debug-only passive observation; never opens a chat, mutates a payload or sends.
FOUNDATION_EXPORT void MBStartHybridMetadataObserver(void);
// Called only after the adapter accepted a fresh Messenger notification token.
FOUNDATION_EXPORT void MBHybridObserveBulletin(id bulletin, BOOL allowed);
