// SPDX-License-Identifier: MIT
#import "MBHybridBubbleClusterView.h"
#import "MBHybridAvatarBinding.h"
#import "MBEngineIncomingBadge.h"

@interface MBHybridAvatarCell : UIControl
@property(nonatomic, strong) UIImageView *avatar;
@property(nonatomic, strong) MBHybridAvatarBinding *binding;
@property(nonatomic, strong) UIButton *closeButton;
@property(nonatomic, copy) void (^openAction)(void);
@property(nonatomic, copy) void (^closeAction)(void);
@end
@implementation MBHybridAvatarCell
- (instancetype)initWithCache:(MBHybridAvatarCache *)cache {
    if ((self = [super initWithFrame:CGRectMake(0, 0, 78, 88)])) {
        self.accessibilityLabel = @"Mở hội thoại";
        self.isAccessibilityElement = YES;
        _avatar = [UIImageView new]; _avatar.clipsToBounds = YES;
        _avatar.contentMode = UIViewContentModeScaleAspectFill;
        _avatar.backgroundColor = UIColor.secondarySystemBackgroundColor;
        _avatar.layer.borderColor = UIColor.systemBlueColor.CGColor; _avatar.layer.borderWidth = 2;
        [self addSubview:_avatar];
        _binding = [[MBHybridAvatarBinding alloc] initWithImageView:_avatar cache:cache];
        _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_closeButton setImage:[UIImage systemImageNamed:@"xmark.circle.fill"] forState:UIControlStateNormal];
        _closeButton.accessibilityLabel = @"Đóng hội thoại này";
        [_closeButton addTarget:self action:@selector(closeTapped) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_closeButton];
        [self addTarget:self action:@selector(openTapped) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    self.avatar.frame = CGRectMake(5, 8, 65, 65); self.avatar.layer.cornerRadius = 32.5;
    self.closeButton.frame = CGRectMake(54, 0, 24, 24);
}
- (void)openTapped { if (self.openAction) self.openAction(); }
- (void)closeTapped { if (self.closeAction) self.closeAction(); }
@end

@interface MBHybridBubbleClusterView () <UIScrollViewDelegate, UIContextMenuInteractionDelegate>
@property(nonatomic, strong) MBHybridBubbleManager *manager;
@property(nonatomic, strong) MBHybridAvatarCache *cache;
@property(nonatomic, strong) MBHybridSnapshot *state;
@property(nonatomic, strong) UIControl *rootButton;
@property(nonatomic, strong) NSArray<UIImageView *> *rootImages;
@property(nonatomic, strong) NSArray<MBHybridAvatarBinding *> *rootBindings;
@property(nonatomic, strong) UIScrollView *picker;
@property(nonatomic, strong) NSMutableDictionary<NSString *, MBHybridAvatarCell *> *cells;
@end
@implementation MBHybridBubbleClusterView
- (instancetype)initWithManager:(MBHybridBubbleManager *)manager avatarCache:(MBHybridAvatarCache *)cache {
    if (!manager || !cache || !NSThread.isMainThread) return nil;
    if ((self = [super initWithFrame:CGRectMake(0, 0, 65, 65)])) {
        _manager = manager; _cache = cache; _maximumPickerWidth = 390; _cells = [NSMutableDictionary new];
        _rootButton = [UIControl new]; _rootButton.isAccessibilityElement = YES;
        [_rootButton addTarget:self action:@selector(rootTapped) forControlEvents:UIControlEventTouchUpInside];
        [_rootButton addInteraction:[[UIContextMenuInteraction alloc] initWithDelegate:self]];
        [self addSubview:_rootButton];
        NSMutableArray *images = [NSMutableArray new], *bindings = [NSMutableArray new];
        for (unsigned i = 0; i < 3; ++i) {
            UIImageView *image = [UIImageView new]; image.contentMode = UIViewContentModeScaleAspectFill;
            image.clipsToBounds = YES; image.backgroundColor = UIColor.secondarySystemBackgroundColor;
            image.layer.borderColor = UIColor.systemBlueColor.CGColor; image.layer.borderWidth = 2;
            image.layer.cornerCurve = kCACornerCurveCircular;
            [images addObject:image]; [bindings addObject:[[MBHybridAvatarBinding alloc] initWithImageView:image cache:cache]];
            [_rootButton insertSubview:image atIndex:0];
        }
        _rootImages = images; _rootBindings = bindings;
        _picker = [UIScrollView new]; _picker.delegate = self; _picker.showsHorizontalScrollIndicator = NO;
        _picker.backgroundColor = UIColor.clearColor; [self addSubview:_picker];
        __weak typeof(self) weakSelf = self;
        manager.onChange = ^(MBHybridSnapshot *snapshot) { [weakSelf applySnapshot:snapshot]; };
        [self applySnapshot:manager.snapshot];
    }
    return self;
}
- (void)setMaximumPickerWidth:(CGFloat)maximumPickerWidth {
    if (!NSThread.isMainThread || !isfinite(maximumPickerWidth) || maximumPickerWidth < 65 || maximumPickerWidth > 4096) return;
    _maximumPickerWidth = maximumPickerWidth; [self invalidateIntrinsicContentSize]; [self setNeedsLayout];
}
- (CGSize)intrinsicContentSize { return self.state.pickerExpanded ? CGSizeMake(self.maximumPickerWidth, 163) : CGSizeMake(65, 65); }
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    (void)event;
    return (!self.rootButton.hidden && CGRectContainsPoint(self.rootButton.frame, point)) ||
        (!self.picker.hidden && CGRectContainsPoint(self.picker.frame, point));
}
- (void)rootTapped { [self.manager onStackTap]; }
- (void)applySnapshot:(MBHybridSnapshot *)snapshot {
    if (!NSThread.isMainThread) return;
    self.state = snapshot;
    self.rootButton.hidden = snapshot.style == MBHybridPresentationHidden;
    self.picker.hidden = !snapshot.pickerExpanded;
    NSUInteger count = MIN((NSUInteger)3, snapshot.items.count);
    for (NSUInteger i = 0; i < 3; ++i) {
        self.rootImages[i].hidden = i >= count;
        if (i < count) {
            MBHybridBubble *bubble = snapshot.items[i];
            [self.rootBindings[i] bindThreadID:bubble.threadID avatarKey:bubble.avatarKey];
        } else [self.rootBindings[i] prepareForReuse];
    }
    self.rootButton.accessibilityLabel = snapshot.style == MBHybridPresentationSingle ? @"Mở hội thoại" : @"Chọn hội thoại";
    NSMutableSet<NSString *> *ids = [NSMutableSet new];
    for (MBHybridBubble *bubble in snapshot.items) [ids addObject:bubble.threadID];
    for (NSString *thread in [self.cells.allKeys copy]) {
        if ([ids containsObject:thread]) continue;
        MBHybridAvatarCell *cell = self.cells[thread];
        [cell.binding prepareForReuse]; [cell removeFromSuperview]; [self.cells removeObjectForKey:thread];
    }
    if (!snapshot.pickerExpanded) {
        for (MBHybridAvatarCell *cell in self.cells.allValues) [cell.binding prepareForReuse];
    }
    if (snapshot.pickerExpanded) {
        __weak MBHybridBubbleManager *weakManager = self.manager;
        for (MBHybridBubble *bubble in snapshot.items) {
            if (self.cells[bubble.threadID]) continue;
            MBHybridAvatarCell *cell = [[MBHybridAvatarCell alloc] initWithCache:self.cache];
            NSString *thread = bubble.threadID;
            cell.openAction = ^{ [weakManager onAvatarTap:thread]; };
            cell.closeAction = ^{ [weakManager onBubbleClose:thread]; };
            cell.accessibilityLabel = bubble.groupThread ? @"Mở hội thoại nhóm" : @"Mở hội thoại cá nhân";
            self.cells[thread] = cell; [self.picker addSubview:cell];
        }
    }
    [self invalidateIntrinsicContentSize]; [self setNeedsLayout];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    self.rootButton.frame = CGRectMake(0, 0, 65, 65);
    NSUInteger count = MIN((NSUInteger)3, self.state.items.count);
    for (NSUInteger i = 0; i < 3; ++i) {
        CGFloat diameter = count <= 1 ? 65 : 53;
        CGFloat offset = count <= 1 ? 0 : MIN((NSUInteger)2, i) * 6;
        self.rootImages[i].frame = CGRectMake(offset, 12 - (count <= 1 ? 12 : offset), diameter, diameter);
        self.rootImages[i].layer.cornerRadius = diameter / 2;
    }
    unsigned badge = self.state.badgeIsExact ? (unsigned)MIN((NSUInteger)100, self.state.totalUnread) : 0;
    MBEngineUpdateIncomingBadge(self.rootButton, badge);
    if (badge) self.rootButton.accessibilityValue = self.state.totalUnread > 99 ? @"Hơn 99 tin chưa đọc" :
        [NSString stringWithFormat:@"%lu tin chưa đọc", (unsigned long)self.state.totalUnread];
    self.picker.frame = CGRectMake(0, 75, MIN(self.maximumPickerWidth, MAX((CGFloat)65, self.bounds.size.width)), 88);
    self.picker.contentSize = CGSizeMake(self.state.items.count * 78, 88);
    if (!self.picker.hidden) {
        NSUInteger index = 0;
        for (MBHybridBubble *bubble in self.state.items) self.cells[bubble.threadID].frame = CGRectMake(index++ * 78, 0, 78, 88);
        [self bindVisibleCells];
    }
}
- (void)bindVisibleCells {
    if (self.picker.hidden) return;
    CGRect viewport = self.picker.bounds;
    for (MBHybridBubble *bubble in self.state.items) {
        MBHybridAvatarCell *cell = self.cells[bubble.threadID];
        if (CGRectIntersectsRect(viewport, cell.frame)) [cell.binding bindThreadID:bubble.threadID avatarKey:bubble.avatarKey];
        else [cell.binding prepareForReuse];
    }
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView { if (scrollView == self.picker) [self bindVisibleCells]; }
- (UIContextMenuConfiguration *)contextMenuInteraction:(UIContextMenuInteraction *)interaction
    configurationForMenuAtLocation:(CGPoint)location {
    (void)interaction; (void)location;
    if (self.state.items.count != 1) return nil;
    NSString *thread = self.state.items.firstObject.threadID;
    __weak MBHybridBubbleManager *weakManager = self.manager;
    return [UIContextMenuConfiguration configurationWithIdentifier:nil previewProvider:nil actionProvider:^UIMenu *(__unused NSArray<UIMenuElement *> *suggested) {
        UIAction *close = [UIAction actionWithTitle:@"Đóng hội thoại này" image:[UIImage systemImageNamed:@"xmark.circle"] identifier:nil handler:^(__unused UIAction *action) {
            [weakManager onBubbleClose:thread];
        }];
        return [UIMenu menuWithTitle:@"" children:@[close]];
    }];
}
@end
