// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#import "MBKeyboardRelayWire.h"

// Main queue only. This relay cannot open a bubble, navigate, type or send a chat.
// A server-issued, per-panel capability is required before any frame is delivered.
FOUNDATION_EXPORT void MBStartKeyboardRelayServer(void (^receive)(MBKeyboardWire frame));
FOUNDATION_EXPORT void MBKeyboardRelaySetPanelActive(BOOL active);
FOUNDATION_EXPORT void MBStartKeyboardRelayClient(void);
