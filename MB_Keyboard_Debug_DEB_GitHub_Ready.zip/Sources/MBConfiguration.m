// SPDX-License-Identifier: MIT
#import "MBConfiguration.h"
#import <CoreFoundation/CoreFoundation.h>

@implementation MBConfiguration
- (instancetype)initWithEnabled:(BOOL)enabled safeApplications:(NSSet<NSString *> *)applications {
    self = [super init];
    if (self) { _enabled = enabled; _safeApplications = [applications copy]; }
    return self;
}
@end

NSSet<NSString *> *MBParseSafeApplications(id value) {
    if (![value isKindOfClass:NSString.class] || [value length] > 4096) return [NSSet set];
    NSMutableSet<NSString *> *allowed = [NSMutableSet set];
    NSCharacterSet *valid = [NSCharacterSet characterSetWithCharactersInString:
        @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-."];
    for (NSString *part in [value componentsSeparatedByString:@","]) {
        NSString *bundle = [part stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (!bundle.length) continue;
        if (bundle.length > 255 || [bundle rangeOfCharacterFromSet:valid.invertedSet].location != NSNotFound) return [NSSet set];
        NSArray<NSString *> *components = [bundle componentsSeparatedByString:@"."];
        if (components.count < 2 || [components containsObject:@""]) return [NSSet set];
        NSString *lower = bundle.lowercaseString;
        // Extra conservative exclusions, NOT a complete bank detector. The
        // allowlist, reviewed transition adapter and default-deny remain required.
        if ([lower containsString:@"bank"] || [lower containsString:@"wallet"] ||
            [lower containsString:@"payment"] || [bundle isEqualToString:@"com.facebook.Messenger"]) return [NSSet set];
        [allowed addObject:bundle];
        if (allowed.count > 32) return [NSSet set];
    }
    return [allowed copy];
}

void MBLoadConfiguration(void (^completion)(MBConfiguration *)) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ queue = dispatch_queue_create("messengerbubbles.configuration", DISPATCH_QUEUE_SERIAL); });
    dispatch_async(queue, ^{
        CFStringRef domain = CFSTR(APELIN_PACKAGE_ID);
        BOOL synchronized = CFPreferencesAppSynchronize(domain);
        if (!synchronized) {
            MBConfiguration *disabled = [[MBConfiguration alloc] initWithEnabled:NO safeApplications:[NSSet set]];
            dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(disabled); });
            return; // Never trust an old enabled cache after a failed sync.
        }
        CFPropertyListRef enabledValue = CFPreferencesCopyAppValue(CFSTR("Enabled"), domain);
        BOOL enabled = enabledValue && CFGetTypeID(enabledValue) == CFBooleanGetTypeID() && CFBooleanGetValue((CFBooleanRef)enabledValue);
        if (enabledValue) CFRelease(enabledValue);
        id applications = CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("SafeApplications"), domain));
        MBConfiguration *configuration = [[MBConfiguration alloc] initWithEnabled:enabled safeApplications:MBParseSafeApplications(applications)];
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(configuration); });
    });
}
