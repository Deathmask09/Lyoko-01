// SPDX-License-Identifier: MIT
#import "MBKeyboardRelay.h"
#import "MBRuntime.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/message.h>
#import <mach/mach.h>
#import <os/log.h>
#import <os/lock.h>
#import <dlfcn.h>
#include <stdatomic.h>
#include <stddef.h>
#include <unistd.h>
// Values from XNU osfmk/kern/cs_blobs.h; not private headers shipped in the SDK.
static const uint32_t MBRelayCSValid = UINT32_C(0x00000001);
static const uint32_t MBRelayCSPlatform = UINT32_C(0x04000000);

// These launchd declarations are absent from the iPhone SDK headers; their
// symbols remain in libSystem. No launch daemon or bootstrap setting is changed.
extern kern_return_t bootstrap_register(mach_port_t, const char *, mach_port_t);
extern kern_return_t bootstrap_look_up(mach_port_t, const char *, mach_port_t *);
static const char *MBRelayService = APELIN_PACKAGE_ID ".keyboard-relay.v1";
static const mach_msg_id_t MBRelayMessageID = 0x4d424b31;

typedef struct { mach_msg_header_t header; MBKeyboardWire wire; } MBKeyboardMachMessage;
typedef union {
    max_align_t alignment;
    unsigned char bytes[sizeof(MBKeyboardMachMessage) + sizeof(mach_msg_max_trailer_t) + 8];
} MBKeyboardReceiveBuffer;
_Static_assert(sizeof(MBKeyboardWire) == 152, "Version 1 wire layout must stay fixed");

static os_log_t MBRelayLog(void) {
    static os_log_t log; static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "keyboard-relay"); });
    return log;
}

// Kernel audit identity + exact currently installed executable, not a PID/string
// claimed by the packet. Missing API/path/signing metadata fails closed. This is
// a process boundary, not attestation against root or other injected code.
static BOOL MBRelayAuthenticate(audit_token_t audit, BOOL server, NSString *expectedPath) {
    if (audit.val[1] != 501 || audit.val[5] == 0 || audit.val[5] > INT32_MAX ||
        audit.val[7] == 0 || !expectedPath.length) return NO;
    static void *security;
    static CFTypeRef (*createTask)(CFAllocatorRef, audit_token_t);
    static CFStringRef (*copyIdentifier)(CFTypeRef, CFErrorRef *);
    static uint32_t (*codeStatus)(CFTypeRef);
    static int (*pidPath)(int, void *, uint32_t);
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        security = dlopen("/System/Library/Frameworks/Security.framework/Security", RTLD_NOW | RTLD_LOCAL);
        if (security) {
            createTask = dlsym(security, "SecTaskCreateWithAuditToken");
            copyIdentifier = dlsym(security, "SecTaskCopySigningIdentifier");
            codeStatus = dlsym(security, "SecTaskGetCodeSignStatus");
        }
        static void *processLibrary;
        processLibrary = dlopen("/usr/lib/libproc.dylib", RTLD_NOW | RTLD_LOCAL);
        if (processLibrary) pidPath = dlsym(processLibrary, "proc_pidpath");
    });
    if (!createTask || !copyIdentifier || !codeStatus || !pidPath) return NO;
    CFTypeRef task = createTask(kCFAllocatorDefault, audit);
    if (!task) return NO;
    CFStringRef identifier = copyIdentifier(task, NULL);
    CFStringRef expected = server ? CFSTR("com.facebook.Messenger") : CFSTR("com.apple.springboard");
    uint32_t status = codeStatus(task);
    char path[4096] = {0};
    int count = pidPath((int)audit.val[5], path, sizeof(path));
    BOOL valid = identifier && CFGetTypeID(identifier) == CFStringGetTypeID() && CFEqual(identifier, expected) &&
        (status & MBRelayCSValid) && (server || (status & MBRelayCSPlatform)) &&
        count > 0 && count < (int)sizeof(path) && memchr(path, 0, sizeof(path)) &&
        [[@(path) stringByResolvingSymlinksInPath] isEqualToString:expectedPath] && (codeStatus(task) & MBRelayCSValid);
    if (identifier) CFRelease(identifier);
    CFRelease(task);
    return valid;
}
static NSString *MBRelayMessengerExecutable(void) {
    // Read bundle metadata only. No container data, database or executable loading.
    Class cls = objc_lookUpClass("LSApplicationProxy");
    SEL selector = sel_registerName("applicationProxyForIdentifier:");
    const char *arguments[] = {"@"};
    if (!MBMethodMatches(object_getClass(cls), selector, "@", 1, arguments)) return nil;
    @try {
        id proxy = ((id (*)(id, SEL, id))objc_msgSend)(cls, selector, @"com.facebook.Messenger");
        id url = MBReadObject(proxy, sel_registerName("bundleURL"));
        if (![url isKindOfClass:NSURL.class] || ![url isFileURL]) return nil;
        NSBundle *bundle = [NSBundle bundleWithURL:url];
        if (![bundle.bundleIdentifier isEqualToString:@"com.facebook.Messenger"]) return nil;
        NSString *executable = bundle.executablePath.stringByResolvingSymlinksInPath;
        return executable.length < 4096 ? executable : nil;
    } @catch (__unused NSException *exception) { return nil; }
}

typedef struct { audit_token_t audit; double nextAttempt; BOOL used; } MBRelayHandshakeSlot;

@interface MBKeyboardRelayEndpoint : NSObject {
    dispatch_queue_t _queue;
    dispatch_source_t _source, _peerSource;
    mach_port_t _receivePort, _peerPort;
    BOOL _server, _started, _authenticated, _leased, _loggedFailure, _awaitingLease;
    double _helloTime, _nextHandshakeAt;
    NSString *_expectedExecutable;
    audit_token_t _peerAudit;
    uint8_t _challenge[16], _session[16];
    uint64_t _sendSequence, _receiveSequence, _leaseEpoch;
    atomic_ullong _mainEpoch, _peerEpoch;
    atomic_bool _connectScheduled;
    os_unfair_lock _deliveryLock, _outgoingLock;
    MBKeyboardWire _latestDelivery, _latestOutgoing;
    uint64_t _deliveryEpoch, _deliveryPeerEpoch, _outgoingEpoch;
    BOOL _deliveryScheduled, _sendScheduled;
    MBRelayHandshakeSlot _handshakes[16];
    unsigned _nextHandshakeSlot;
    MBKeyboardWire _lastFrame; // Main queue; never replayed across a lease boundary.
    uint64_t _lastFrameEpoch;
    BOOL _hasLastFrame;
}
@property(nonatomic, copy) void (^receive)(MBKeyboardWire frame);
- (instancetype)initWithServer:(BOOL)server expectedExecutable:(NSString *)executable;
- (void)start;
- (void)connect;
- (void)setPanelActive:(BOOL)active;
- (void)observeKeyboard:(NSNotification *)notification;
- (void)forgetKeyboard;
@end

@implementation MBKeyboardRelayEndpoint
- (instancetype)initWithServer:(BOOL)server expectedExecutable:(NSString *)executable {
    if ((self = [super init])) {
        _server = server; _expectedExecutable = [executable copy];
        _queue = dispatch_queue_create(APELIN_PACKAGE_ID ".keyboard-relay", DISPATCH_QUEUE_SERIAL);
        atomic_init(&_mainEpoch, 1); atomic_init(&_peerEpoch, 1); atomic_init(&_connectScheduled, false);
        _deliveryLock = (os_unfair_lock)OS_UNFAIR_LOCK_INIT;
        _outgoingLock = (os_unfair_lock)OS_UNFAIR_LOCK_INIT;
    }
    return self;
}
- (void)logFailure:(const char *)reason {
    if (_loggedFailure) return;
    _loggedFailure = YES;
    os_log_error(MBRelayLog(), "MBKeyboardRelay unavailable build=%{public}s reason=%{public}s", APELIN_BUILD_ID, reason);
}
- (void)dropPeer {
    atomic_fetch_add(&_peerEpoch, 1);
    if (_peerSource) { dispatch_source_cancel(_peerSource); _peerSource = nil; }
    if (MACH_PORT_VALID(_peerPort)) mach_port_deallocate(mach_task_self(), _peerPort);
    _peerPort = MACH_PORT_NULL; _authenticated = NO; _awaitingLease = NO;
    _receiveSequence = 0; _sendSequence = 0;
    if (!_server) {
        _leased = NO;
        // Persistent invalidation: a later grant cannot cancel this boundary.
        atomic_fetch_add(&_mainEpoch, 1);
    }
}
- (BOOL)peerAlive {
    mach_port_type_t type = 0;
    return MACH_PORT_VALID(_peerPort) && mach_port_type(mach_task_self(), _peerPort, &type) == KERN_SUCCESS &&
        (type & MACH_PORT_TYPE_SEND) != 0;
}
- (BOOL)watchPeer {
    if (![self peerAlive] || mach_port_mod_refs(mach_task_self(), _peerPort, MACH_PORT_RIGHT_SEND, 1) != KERN_SUCCESS) return NO;
    // The source owns a separate uref until its cancellation handler runs. Never
    // drop the right under a live source or let a late death event drop a new peer.
    mach_port_t watched = _peerPort;
    uint64_t generation = atomic_load(&_peerEpoch);
    dispatch_source_t source = dispatch_source_create(DISPATCH_SOURCE_TYPE_MACH_SEND, watched, DISPATCH_MACH_SEND_DEAD, _queue);
    if (!source) { mach_port_deallocate(mach_task_self(), watched); return NO; }
    _peerSource = source;
    __weak MBKeyboardRelayEndpoint *weak = self;
    dispatch_source_set_event_handler(source, ^{
        MBKeyboardRelayEndpoint *endpoint = weak;
        if (endpoint && generation == atomic_load(&endpoint->_peerEpoch) && endpoint->_peerPort == watched)
            [endpoint dropPeer];
    });
    dispatch_source_set_cancel_handler(source, ^{ mach_port_deallocate(mach_task_self(), watched); });
    dispatch_resume(source);
    return YES;
}
- (BOOL)allowHandshakeAttempt:(audit_token_t)audit now:(double)now {
    if (audit.val[1] != 501 || audit.val[5] == 0 || audit.val[5] > INT32_MAX || audit.val[7] == 0) return NO;
    // An unrelated kernel audit identity cannot consume the legitimate peer's
    // cooldown. Fixed-size storage; no allocation or global unauthenticated gate.
    for (unsigned i = 0; i < 16; ++i) {
        MBRelayHandshakeSlot *slot = &_handshakes[i];
        if (slot->used && memcmp(&slot->audit, &audit, sizeof(audit)) == 0) {
            if (now < slot->nextAttempt) return NO;
            slot->nextAttempt = now + 0.25; return YES;
        }
    }
    _handshakes[_nextHandshakeSlot++ % 16] = (MBRelayHandshakeSlot){ .audit = audit, .nextAttempt = now + 0.25, .used = YES };
    return YES;
}
- (BOOL)sendWire:(MBKeyboardWire)wire {
    if (!MACH_PORT_VALID(_peerPort) || !MACH_PORT_VALID(_receivePort)) return NO;
    MBKeyboardMachMessage message = {0};
    message.header.msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, MACH_MSG_TYPE_MAKE_SEND);
    message.header.msgh_size = sizeof(message);
    message.header.msgh_remote_port = _peerPort;
    message.header.msgh_local_port = _receivePort;
    message.header.msgh_id = MBRelayMessageID;
    message.wire = wire;
    mach_msg_return_t result = mach_msg(&message.header, MACH_SEND_MSG | MACH_SEND_TIMEOUT,
        sizeof(message), 0, MACH_PORT_NULL, 0, MACH_PORT_NULL);
    if (result != MACH_MSG_SUCCESS) {
        // Recoverable errors pseudo-receive the unsent header. mach_msg_destroy
        // deliberately skips msgh_local_port: release ONLY a returned send right,
        // never the original MAKE_SEND receive right. Match libsyscall's
        // mach_msg_server_consume_unsent_message contract.
        if (result == MACH_SEND_TIMED_OUT || result == MACH_SEND_INTERRUPTED || result == MACH_SEND_INVALID_DEST) {
            mach_msg_type_name_t local = MACH_MSGH_BITS_LOCAL(message.header.msgh_bits);
            if (MACH_PORT_VALID(message.header.msgh_local_port) &&
                (local == MACH_MSG_TYPE_MOVE_SEND || local == MACH_MSG_TYPE_MOVE_SEND_ONCE)) {
                mach_port_deallocate(mach_task_self(), message.header.msgh_local_port);
                message.header.msgh_local_port = MACH_PORT_NULL;
            }
            mach_msg_destroy(&message.header);
        }
        // A transient/full port does not start a retry loop or block SpringBoard.
        [self dropPeer];
        return NO;
    }
    return YES;
}
- (MBKeyboardWire)packet:(MBKeyboardWireKind)kind {
    MBKeyboardWire wire = {0};
    wire.magic = MB_KEYBOARD_WIRE_MAGIC; wire.version = MB_KEYBOARD_WIRE_VERSION;
    wire.kind = kind; wire.timestamp = CACurrentMediaTime();
    memcpy(wire.challenge, _challenge, sizeof(_challenge));
    memcpy(wire.session, _session, sizeof(_session));
    return wire;
}
- (void)sendLease {
    if (!_server || !_authenticated) return;
    if (_sendSequence == UINT64_MAX) { [self dropPeer]; return; }
    MBKeyboardWire wire = [self packet:MBKeyboardWireLease];
    wire.sequence = ++_sendSequence;
    wire.flags = _leased ? 1 : 0;
    [self sendWire:wire];
}
- (void)startOnQueue {
    if (_started) return;
    _started = YES;
    if (!_expectedExecutable.length || mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &_receivePort) != KERN_SUCCESS) {
        [self logFailure:"identity-or-receive-port"]; return;
    }
    mach_port_limits_t limits = { .mpl_qlimit = 8 };
    mach_port_set_attributes(mach_task_self(), _receivePort, MACH_PORT_LIMITS_INFO,
        (mach_port_info_t)&limits, MACH_PORT_LIMITS_INFO_COUNT);
    if (_server) {
        kern_return_t inserted = mach_port_insert_right(mach_task_self(), _receivePort, _receivePort, MACH_MSG_TYPE_MAKE_SEND);
        kern_return_t registered = inserted == KERN_SUCCESS ?
            bootstrap_register(bootstrap_port, MBRelayService, _receivePort) : inserted;
        if (inserted == KERN_SUCCESS) mach_port_deallocate(mach_task_self(), _receivePort);
        if (registered != KERN_SUCCESS) {
            mach_port_mod_refs(mach_task_self(), _receivePort, MACH_PORT_RIGHT_RECEIVE, -1); _receivePort = MACH_PORT_NULL;
            [self logFailure:"service-registration"]; return;
        }
    }
    _source = dispatch_source_create(DISPATCH_SOURCE_TYPE_MACH_RECV, _receivePort, 0, _queue);
    if (!_source) {
        mach_port_mod_refs(mach_task_self(), _receivePort, MACH_PORT_RIGHT_RECEIVE, -1); _receivePort = MACH_PORT_NULL;
        [self logFailure:"receive-source"]; return;
    }
    __weak MBKeyboardRelayEndpoint *weak = self;
    dispatch_source_set_event_handler(_source, ^{ [weak drain]; });
    dispatch_resume(_source);
}
- (void)start { dispatch_async(_queue, ^{ [self startOnQueue]; }); }
- (void)connect {
    if (_server || atomic_exchange(&_connectScheduled, true)) return;
    dispatch_async(_queue, ^{
        atomic_store(&self->_connectScheduled, false);
        [self startOnQueue];
        if (!MACH_PORT_VALID(self->_receivePort)) return;
        if (self->_authenticated && [self peerAlive]) return;
        if (self->_awaitingLease && [self peerAlive] && CACurrentMediaTime() - self->_helloTime < 1.0) return;
        [self dropPeer];
        arc4random_buf(self->_challenge, sizeof(self->_challenge));
        memset(self->_session, 0, sizeof(self->_session));
        kern_return_t found = bootstrap_look_up(bootstrap_port, MBRelayService, &self->_peerPort);
        if (found != KERN_SUCCESS || !MACH_PORT_VALID(self->_peerPort)) {
            self->_peerPort = MACH_PORT_NULL; [self logFailure:"service-lookup-or-sandbox"]; return;
        }
        if (![self watchPeer]) { [self dropPeer]; [self logFailure:"peer-monitor"]; return; }
        MBKeyboardWire wire = [self packet:MBKeyboardWireHello];
        self->_helloTime = CACurrentMediaTime(); self->_awaitingLease = YES;
        [self sendWire:wire];
    });
}
- (void)setPanelActive:(BOOL)active {
    if (!_server || !NSThread.isMainThread) return;
    uint64_t epoch = atomic_fetch_add(&_mainEpoch, 1) + 1; // Invalidate already queued deliveries.
    dispatch_async(_queue, ^{
        self->_leaseEpoch = epoch; self->_leased = active; self->_receiveSequence = 0;
        arc4random_buf(self->_session, sizeof(self->_session));
        [self sendLease];
    });
}
- (void)acceptWire:(MBKeyboardWire)wire audit:(audit_token_t)audit replyPort:(mach_port_t)port {
    if (!MBKeyboardWireEnvelopeValid(&wire, CACurrentMediaTime()) || !MACH_PORT_VALID(port)) return;
    if (_server && wire.kind == MBKeyboardWireHello && wire.flags == 0 && wire.sequence == 0 &&
        !MBKeyboardNoncePresent(wire.session)) {
        double now = CACurrentMediaTime();
        BOOL samePeer = _authenticated && memcmp(&_peerAudit, &audit, sizeof(audit)) == 0;
        if (samePeer && MBKeyboardNonceEqual(wire.challenge, _challenge)) return; // Replay cannot reset sequence.
        if (![self allowHandshakeAttempt:audit now:now] || !MBRelayAuthenticate(audit, YES, _expectedExecutable)) return;
        if (samePeer && now < _nextHandshakeAt) return;
        if (mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_SEND, 1) != KERN_SUCCESS) return;
        [self dropPeer]; _peerPort = port; _peerAudit = audit; _authenticated = YES;
        _nextHandshakeAt = now + 0.25; // Only an authenticated peer can consume this cooldown.
        if (![self watchPeer]) { [self dropPeer]; [self logFailure:"peer-monitor"]; return; }
        memcpy(_challenge, wire.challenge, sizeof(_challenge));
        arc4random_buf(_session, sizeof(_session));
        [self sendLease];
        return;
    }
    if (!_server && MBKeyboardWireAcceptLease(&wire, CACurrentMediaTime(), _challenge,
        _authenticated ? _receiveSequence : 0)) {
        if (!MBRelayAuthenticate(audit, NO, _expectedExecutable)) return;
        if (_authenticated && memcmp(&_peerAudit, &audit, sizeof(audit)) == 0 && wire.sequence <= _receiveSequence) return;
        uint64_t leaseSequence = wire.sequence;
        if (mach_port_mod_refs(mach_task_self(), port, MACH_PORT_RIGHT_SEND, 1) != KERN_SUCCESS) return;
        [self dropPeer]; _peerPort = port; _peerAudit = audit; _authenticated = YES; _leased = wire.flags == 1;
        _receiveSequence = leaseSequence;
        memcpy(_session, wire.session, sizeof(_session));
        if (![self watchPeer]) { [self dropPeer]; [self logFailure:"peer-monitor"]; return; }
        // dropPeer advanced the observation generation even for a rapid
        // inactive/active pair. Do not resubmit a frame captured before this lease.
        return;
    }
    if (!_server || !_authenticated || !_leased || memcmp(&_peerAudit, &audit, sizeof(audit)) != 0 ||
        !MBKeyboardWireAcceptFrame(&wire, CACurrentMediaTime(), _challenge, _session, _receiveSequence)) return;
    _receiveSequence = wire.sequence;
    os_unfair_lock_lock(&_deliveryLock);
    _latestDelivery = wire; _deliveryEpoch = _leaseEpoch; _deliveryPeerEpoch = atomic_load(&_peerEpoch);
    BOOL scheduled = _deliveryScheduled; _deliveryScheduled = YES;
    os_unfair_lock_unlock(&_deliveryLock);
    if (scheduled) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        os_unfair_lock_lock(&self->_deliveryLock);
        MBKeyboardWire latest = self->_latestDelivery;
        uint64_t epoch = self->_deliveryEpoch, peerEpoch = self->_deliveryPeerEpoch;
        self->_deliveryScheduled = NO;
        os_unfair_lock_unlock(&self->_deliveryLock);
        if (epoch == atomic_load(&self->_mainEpoch) && peerEpoch == atomic_load(&self->_peerEpoch) &&
            MBKeyboardWireFrameValid(&latest, CACurrentMediaTime()) && self.receive)
            self.receive(latest);
    });
}
- (void)drain {
    // At most eight non-blocking receives per source dispatch. Oversized messages
    // are discarded by mach_msg (no MACH_RCV_LARGE); never allocate from wire sizes.
    for (unsigned i = 0; i < 8; ++i) {
        MBKeyboardReceiveBuffer buffer = {0};
        mach_msg_header_t *header = (void *)buffer.bytes;
        mach_msg_return_t received = mach_msg(header, MACH_RCV_MSG | MACH_RCV_TIMEOUT |
            MACH_RCV_TRAILER_TYPE(MACH_MSG_TRAILER_FORMAT_0) | MACH_RCV_TRAILER_ELEMENTS(MACH_RCV_TRAILER_AUDIT),
            0, sizeof(buffer), _receivePort, 0, MACH_PORT_NULL);
        if (received == MACH_RCV_TOO_LARGE) continue;
        if (received != MACH_MSG_SUCCESS) break;
        size_t trailerOffset = (header->msgh_size + 3u) & ~(size_t)3u;
        if (header->msgh_id == MBRelayMessageID && header->msgh_size == sizeof(MBKeyboardMachMessage) &&
            !(header->msgh_bits & MACH_MSGH_BITS_COMPLEX) &&
            MACH_MSGH_BITS_REMOTE(header->msgh_bits) == MACH_MSG_TYPE_PORT_SEND &&
            trailerOffset + sizeof(mach_msg_audit_trailer_t) <= sizeof(buffer)) {
            mach_msg_audit_trailer_t trailer;
            memcpy(&trailer, buffer.bytes + trailerOffset, sizeof(trailer));
            if (trailer.msgh_trailer_type == MACH_MSG_TRAILER_FORMAT_0 && trailer.msgh_trailer_size >= sizeof(trailer)) {
                MBKeyboardWire wire;
                memcpy(&wire, &((MBKeyboardMachMessage *)header)->wire, sizeof(wire));
                [self acceptWire:wire audit:trailer.msgh_audit replyPort:header->msgh_remote_port];
            }
        }
        // Releases every temporary reply right, including rejected messages.
        mach_msg_destroy(header);
    }
}
- (void)submitFrame:(MBKeyboardWire)frame observedEpoch:(uint64_t)observedEpoch {
    // At most one queued send. A burst replaces geometry, including its final hide.
    // Preserve the observation generation instead of stamping old data with a new lease.
    os_unfair_lock_lock(&_outgoingLock);
    _latestOutgoing = frame; _outgoingEpoch = observedEpoch;
    BOOL scheduled = _sendScheduled; _sendScheduled = YES;
    os_unfair_lock_unlock(&_outgoingLock);
    if (scheduled) return;
    dispatch_async(_queue, ^{
        os_unfair_lock_lock(&self->_outgoingLock);
        MBKeyboardWire outgoing = self->_latestOutgoing;
        uint64_t epoch = self->_outgoingEpoch;
        self->_sendScheduled = NO;
        os_unfair_lock_unlock(&self->_outgoingLock);
        if (epoch != atomic_load(&self->_mainEpoch) || !self->_authenticated || !self->_leased ||
            !MBKeyboardWireEnvelopeValid(&outgoing, CACurrentMediaTime())) return;
        if (self->_sendSequence == UINT64_MAX) { [self dropPeer]; return; }
        outgoing.sequence = ++self->_sendSequence;
        memcpy(outgoing.challenge, self->_challenge, sizeof(self->_challenge));
        memcpy(outgoing.session, self->_session, sizeof(self->_session));
        if (MBKeyboardWireFrameValid(&outgoing, CACurrentMediaTime())) [self sendWire:outgoing];
    });
}
- (void)forgetKeyboard {
    if (_server || !NSThread.isMainThread) return;
    if (_hasLastFrame && _lastFrameEpoch == atomic_load(&_mainEpoch)) {
        MBKeyboardWire hidden = _lastFrame;
        hidden.timestamp = CACurrentMediaTime(); hidden.flags = 1; hidden.duration = 0.15;
        hidden.frameX = hidden.screenX; hidden.frameY = hidden.screenY + hidden.screenHeight;
        hidden.frameWidth = hidden.screenWidth; hidden.frameHeight = 0;
        [self submitFrame:hidden observedEpoch:_lastFrameEpoch];
    }
    _hasLastFrame = NO; _lastFrameEpoch = 0; memset(&_lastFrame, 0, sizeof(_lastFrame));
}
- (void)observeKeyboard:(NSNotification *)notification {
    if (_server || !NSThread.isMainThread || UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    @try {
        UIWindowScene *scene = nil; NSUInteger activeScenes = 0;
        for (UIScene *candidate in UIApplication.sharedApplication.connectedScenes) {
            if ([candidate isKindOfClass:UIWindowScene.class] && candidate.activationState == UISceneActivationStateForegroundActive &&
                ((UIWindowScene *)candidate).screen == UIScreen.mainScreen) { scene = (UIWindowScene *)candidate; ++activeScenes; }
        }
        if (activeScenes != 1 || !scene) return;
        BOOL hiding = [notification.name isEqualToString:UIKeyboardWillHideNotification];
        NSValue *value = notification.userInfo[UIKeyboardFrameEndUserInfoKey];
        if (![value isKindOfClass:NSValue.class] || strcmp(value.objCType, @encode(CGRect)) != 0) return;
        CGRect screen = scene.screen.bounds, rect = value.CGRectValue;
        NSNumber *duration = notification.userInfo[UIKeyboardAnimationDurationUserInfoKey];
        NSNumber *curve = notification.userInfo[UIKeyboardAnimationCurveUserInfoKey];
        if (![duration isKindOfClass:NSNumber.class] || ![curve isKindOfClass:NSNumber.class]) return;
        MBKeyboardWire frame = {0};
        frame.magic = MB_KEYBOARD_WIRE_MAGIC; frame.version = MB_KEYBOARD_WIRE_VERSION; frame.kind = MBKeyboardWireFrame;
        frame.timestamp = CACurrentMediaTime(); frame.flags = hiding ? 1 : 0;
        frame.screenX = screen.origin.x; frame.screenY = screen.origin.y;
        frame.screenWidth = screen.size.width; frame.screenHeight = screen.size.height;
        frame.frameX = rect.origin.x; frame.frameY = rect.origin.y;
        frame.frameWidth = rect.size.width; frame.frameHeight = rect.size.height;
        frame.duration = duration.doubleValue; frame.curve = curve.intValue; frame.orientation = (int32_t)scene.interfaceOrientation;
        // Placeholder nonces are LOCAL ONLY; replaced by the authenticated lease before send.
        frame.challenge[0] = 1; frame.session[0] = 1; frame.sequence = 1;
        if (!MBKeyboardWireFrameValid(&frame, CACurrentMediaTime())) return;
        _lastFrameEpoch = atomic_load(&_mainEpoch);
        _lastFrame = frame; _hasLastFrame = YES;
        [self connect]; [self submitFrame:frame observedEpoch:_lastFrameEpoch];
    } @catch (__unused NSException *exception) { /* No input/notification mutation on failure. */ }
}
@end

static MBKeyboardRelayEndpoint *MBRelayServer, *MBRelayClient;
void MBStartKeyboardRelayServer(void (^receive)(MBKeyboardWire frame)) {
    if (!NSThread.isMainThread || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        MBRelayServer = [[MBKeyboardRelayEndpoint alloc] initWithServer:YES expectedExecutable:MBRelayMessengerExecutable()];
        MBRelayServer.receive = receive;
        [MBRelayServer start];
    });
}
void MBKeyboardRelaySetPanelActive(BOOL active) {
    if (NSThread.isMainThread) [MBRelayServer setPanelActive:active];
}
void MBStartKeyboardRelayClient(void) {
    if (!NSThread.isMainThread || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.facebook.Messenger"]) return;
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    if (![info[@"CFBundleShortVersionString"] isEqual:@"579.0.0"] || ![info[@"CFBundleVersion"] isEqual:@"1068430635"]) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        MBRelayClient = [[MBKeyboardRelayEndpoint alloc] initWithServer:NO
            expectedExecutable:[@"/System/Library/CoreServices/SpringBoard.app/SpringBoard" stringByResolvingSymlinksInPath]];
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        for (NSNotificationName name in @[UIKeyboardWillChangeFrameNotification, UIKeyboardWillHideNotification])
            [center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
                [MBRelayClient observeKeyboard:note];
            }];
        for (NSNotificationName name in @[UIApplicationWillResignActiveNotification, UISceneWillDeactivateNotification])
            [center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) {
                [MBRelayClient forgetKeyboard];
            }];
        for (NSNotificationName name in @[UIApplicationDidBecomeActiveNotification, UISceneDidActivateNotification])
            [center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) {
                [MBRelayClient connect];
            }];
        [MBRelayClient connect];
    });
}
