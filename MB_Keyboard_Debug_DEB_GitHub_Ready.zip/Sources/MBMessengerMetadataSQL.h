// SPDX-License-Identifier: MIT
#pragma once
// Exact metadata projection verified on Messenger 579.0.0/1068430635.
// Not message content. Bind the transport ID as text; NEVER substitute local
// signed client keys, a bulletin tid, or a guessed FBID for this identity.
static const char *const MBMessengerCryptoMetadataSQL =
    "SELECT c.pk,c.thread_key,a.thread_id,c.is_group_thread,"
    "CASE WHEN typeof(c.unread_message_count)='integer' AND c.unread_message_count>=0 "
    "THEN c.unread_message_count ELSE NULL END,"
    "CASE WHEN c.is_group_thread=1 THEN c.thread_picture_url "
    "ELSE c.default_other_participant_profile_picture_url_list END,"
    "CASE WHEN c.is_group_thread=1 THEN c.thread_picture_url_fallback "
    "ELSE c.default_other_participant_profile_picture_fallback_url_list END "
    "FROM advanced_crypto_transport_threads AS a "
    "JOIN client_threads AS c ON c.pk=a.client_thread_pk "
    "WHERE a.thread_id=?1 AND c.is_shadow_thread=0 AND c.is_group_thread IN (0,1) "
    "ORDER BY c.pk LIMIT 2";

// Avatar identity joins verified on Messenger579 metadata. These are separate
// from unread/thread routing. LEFT JOIN retains unresolved participants so one
// missing mapping cannot silently select another user. LIMIT2 rejects ambiguity.
static const char *const MBMessengerAvatarOwnerSQL =
    "SELECT user_id FROM self_profile ORDER BY user_id LIMIT 2";
static const char *const MBMessengerPersonAvatarSQL =
    "SELECT p.contact_pk,p.is_pending,cc.pk,f.server_contact_id,k.id,"
    "k.profile_picture_url,k.profile_picture_fallback_url,"
    "k.profile_picture_url_expiration_timestamp_ms "
    "FROM client_participants AS p "
    "LEFT JOIN client_contacts AS cc ON cc.pk=p.contact_pk "
    "LEFT JOIN fb_transport_contacts AS f ON f.client_contact_pk=cc.pk "
    "LEFT JOIN contacts AS k ON k.id=f.server_contact_id "
    "WHERE p.thread_pk=?1 AND (p.is_pending=0 OR p.is_pending IS NULL) "
    "AND (f.server_contact_id IS NULL OR f.server_contact_id<>?2) "
    "ORDER BY p.pk LIMIT 2";
static const char *const MBMessengerAvatarThreadSQL =
    "SELECT c.pk,a.thread_id,c.is_group_thread,"
    "CASE WHEN c.is_group_thread=1 THEN c.thread_picture_url ELSE NULL END,"
    "CASE WHEN c.is_group_thread=1 THEN c.thread_picture_url_fallback ELSE NULL END,"
    "CASE WHEN c.is_group_thread=1 THEN c.thread_picture_url_expiration_timestamp_ms ELSE NULL END "
    "FROM advanced_crypto_transport_threads AS a "
    "JOIN client_threads AS c ON c.pk=a.client_thread_pk "
    "WHERE a.thread_id=?1 AND c.is_shadow_thread=0 AND c.is_group_thread IN (0,1) "
    "ORDER BY c.pk LIMIT 2";
