// SPDX-License-Identifier: MIT
#include "MBEventGate.h"

void MBEventGateInit(MBEventGate *gate) {
    if (gate) atomic_init(&gate->state, 2); // epoch 1, denied
}
uint64_t MBEventGateEpoch(const MBEventGate *gate) {
    return gate ? atomic_load_explicit(&gate->state, memory_order_acquire) >> 1 : 0;
}
uint64_t MBEventGateAllowedEpoch(const MBEventGate *gate) {
    if (!gate) return 0;
    uint_fast64_t state = atomic_load_explicit(&gate->state, memory_order_acquire);
    return (state & 1) ? state >> 1 : 0;
}
uint64_t MBEventGateInvalidate(MBEventGate *gate) {
    if (!gate) return 0;
    uint_fast64_t old = atomic_load_explicit(&gate->state, memory_order_acquire);
    for (;;) {
        if (!old) return 0;
        uint_fast64_t generation = old & ~(uint_fast64_t)1;
        uint_fast64_t next = generation >= UINT64_MAX - 1 ? 0 : generation + 2;
        if (atomic_compare_exchange_weak_explicit(&gate->state, &old, next,
                memory_order_acq_rel, memory_order_acquire)) return next >> 1;
    }
}
bool MBEventGatePublishAllowed(MBEventGate *gate, uint64_t epoch) {
    if (!gate || !epoch || epoch > (UINT64_MAX >> 1)) return false;
    uint_fast64_t expected = atomic_load_explicit(&gate->state, memory_order_acquire);
    if ((expected >> 1) != epoch) return false;
    return atomic_compare_exchange_strong_explicit(&gate->state, &expected, expected | 1,
        memory_order_acq_rel, memory_order_acquire);
}
