// SPDX-License-Identifier: MIT
#include "MBEnginePolicy.h"
#include <math.h>
#include <string.h>

bool MBEngineAllowsBundle(const char *bundle, bool enabled, bool userSession) {
    return enabled && userSession && bundle &&
        strcmp(bundle, "com.facebook.Messenger") == 0;
}

unsigned MBEngineNextIncomingCount(unsigned current, bool realEvent, bool panelOpen) {
    if (!realEvent) return current; // TEST never adds or clears a real count.
    if (panelOpen) return 0;
    return current >= MB_ENGINE_INCOMING_COUNT_CAP ? MB_ENGINE_INCOMING_COUNT_CAP : current + 1;
}

bool MBEngineShouldAutoBubble(bool enabled, bool unlocked, bool captured, MBEngineForeground foreground) {
    return enabled && unlocked && !captured && foreground == MBEngineForegroundElsewhere;
}

bool MBEngineEventIsFresh(double eventTime, double now) {
    return isfinite(eventTime) && isfinite(now) && eventTime > 0 &&
        now - eventTime >= -1.0 && now - eventTime <= 30.0;
}

bool MBEngineIngressMayDispatch(unsigned long long capturedEpoch, unsigned long long currentEpoch,
                               double received, double now) {
    return capturedEpoch > 0 && capturedEpoch == currentEpoch && isfinite(received) &&
        isfinite(now) && received > 0 && now >= received && now - received <= 1.0;
}

bool MBEngineDebugTestMayFire(unsigned long long capturedEpoch, unsigned long long currentEpoch,
                            double scheduled, double now, bool enabled) {
    return enabled && capturedEpoch > 0 && capturedEpoch == currentEpoch &&
        isfinite(scheduled) && isfinite(now) && scheduled > 0 &&
        now - scheduled >= MB_ENGINE_DEBUG_TEST_DELAY &&
        now - scheduled <= MB_ENGINE_DEBUG_TEST_DELAY + 5.0;
}

bool MBEngineWatchMayContinue(double start, double now, bool userSession) {
    return userSession && isfinite(start) && isfinite(now) &&
        start > 0.0 && now >= start && now - start < 4.0;
}
