// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#include <math.h>

/// Pure selection policy; URL/source validation happens separately before any GET.
/// A positive primary-photo deadline is never bypassed. An explicitly stored,
/// different fallback belongs to the same verified subject but has no independently
/// verified deadline: grant only a short local fetch lease, not CDN freshness proof.
static inline NSString * _Nullable MBUserAvatarChooseReference(
    NSString * _Nullable primary, NSString * _Nullable fallback, int64_t primaryExpiryMS,
    NSTimeInterval now, NSTimeInterval * _Nonnull lease) {
    *lease = 0;
    if (![primary isKindOfClass:NSString.class] || !primary.length || !isfinite(now)) return nil;
    *lease = 60;
    if (primaryExpiryMS <= 0) return primary;
    NSTimeInterval remaining = primaryExpiryMS / 1000.0 - now;
    if (remaining > 0) { *lease = MIN(*lease, remaining); return primary; }
    if (![fallback isKindOfClass:NSString.class] || !fallback.length || [fallback isEqualToString:primary]) {
        *lease = 0; return nil;
    }
    return fallback;
}
