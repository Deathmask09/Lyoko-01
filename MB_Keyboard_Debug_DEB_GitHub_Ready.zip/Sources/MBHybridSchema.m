// SPDX-License-Identifier: MIT
#import "MBHybridSchema.h"

// Candidate spellings are observations, NOT verified routing/unread semantics.
// In particular aps.badge is an app badge, never authoritative per-thread unread.
typedef struct { __unsafe_unretained NSString *key; uint8_t field; const char *label; } MBShapeKey;
static const MBShapeKey MBShapeKeys[] = {
    {@"threadId", MBHybridShapeThread, "threadId"}, {@"threadID", MBHybridShapeThread, "threadID"},
    {@"thread_id", MBHybridShapeThread, "thread_id"}, {@"threadIdentifier", MBHybridShapeThread, "threadIdentifier"},
    {@"tid", MBHybridShapeThread, "tid"},
    {@"groupId", MBHybridShapeGroup, "groupId"}, {@"group_id", MBHybridShapeGroup, "group_id"},
    {@"isGroup", MBHybridShapeGroup, "isGroup"}, {@"is_group", MBHybridShapeGroup, "is_group"},
    {@"avatarKey", MBHybridShapeAvatar, "avatarKey"}, {@"avatarURL", MBHybridShapeAvatar, "avatarURL"},
    {@"avatarUrl", MBHybridShapeAvatar, "avatarUrl"}, {@"avatar_url", MBHybridShapeAvatar, "avatar_url"},
    {@"avatar", MBHybridShapeAvatar, "avatar"},
    {@"unread", MBHybridShapeUnread, "unread"}, {@"unreadCount", MBHybridShapeUnread, "unreadCount"},
    {@"unread_count", MBHybridShapeUnread, "unread_count"},
    {@"badge", MBHybridShapeBadge, "badge"},
    {@"messageId", MBHybridShapeMessage, "messageId"}, {@"message_id", MBHybridShapeMessage, "message_id"},
    {@"mid", MBHybridShapeMessage, "mid"},
};
static NSString *const MBShapeContainers[] = {@"userInfo", @"remoteNotification", @"payload", @"data", @"aps"};
static const char *const MBShapeContainerLabels[] = {"top", "userInfo", "remoteNotification", "payload", "data", "aps"};
MBHybridShapeKind MBHybridValueKind(id value) {
    if (!value) return MBHybridShapeMissing;
    if (value == NSNull.null) return MBHybridShapeNull;
    if ([value isKindOfClass:NSString.class]) return MBHybridShapeString;
    if ([value isKindOfClass:NSNumber.class]) return CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID() ?
        MBHybridShapeBoolean : MBHybridShapeNumber;
    if ([value isKindOfClass:NSDictionary.class]) return MBHybridShapeDictionary;
    if ([value isKindOfClass:NSArray.class]) return MBHybridShapeArray;
    if ([value isKindOfClass:NSData.class]) return MBHybridShapeData;
    return MBHybridShapeOpaque;
}
const char *MBHybridShapeKeyName(unsigned key) {
    return key && key <= sizeof(MBShapeKeys) / sizeof(MBShapeKeys[0]) ? MBShapeKeys[key - 1].label : "none";
}
const char *MBHybridShapeFieldName(unsigned field) {
    static const char *const names[] = {"thread", "group", "avatar", "unread", "app-badge", "message-id"};
    return field < MBHybridShapeFieldCount ? names[field] : "invalid";
}
const char *MBHybridShapeContainerName(unsigned container) {
    return container < sizeof(MBShapeContainerLabels) / sizeof(MBShapeContainerLabels[0]) ?
        MBShapeContainerLabels[container] : "invalid";
}
MBHybridShape MBHybridInspectShape(id payload) {
    MBHybridShape result = {0};
    @try {
        result.rootKind = MBHybridValueKind(payload);
        if (result.rootKind != MBHybridShapeDictionary) return result;
        // At most eight dictionaries, depth two; never enumerate unknown keys,
        // stringify objects, parse JSON strings, inspect arrays, or call payload getters.
        id nodes[8] = {payload};
        uint8_t depth[8] = {0}, containers[8] = {0};
        unsigned count = 1;
        for (unsigned index = 0; index < count; ++index) {
            NSDictionary *node = nodes[index];
            ++result.dictionaries;
            for (unsigned key = 0; key < sizeof(MBShapeKeys) / sizeof(MBShapeKeys[0]); ++key) {
                const MBShapeKey *entry = &MBShapeKeys[key];
                if (result.fields[entry->field].key) continue;
                id value = [node objectForKey:entry->key];
                if (value) result.fields[entry->field] = (MBHybridShapeHit){key + 1, containers[index], MBHybridValueKind(value)};
            }
            if (depth[index] >= 2) continue;
            for (unsigned child = 0; child < sizeof(MBShapeContainers) / sizeof(MBShapeContainers[0]); ++child) {
                id value = [node objectForKey:MBShapeContainers[child]];
                if (![value isKindOfClass:NSDictionary.class]) continue;
                BOOL duplicate = NO;
                for (unsigned prior = 0; prior < count; ++prior) if (nodes[prior] == value) { duplicate = YES; break; }
                if (duplicate) continue;
                if (count == 8) { result.truncated = 1; continue; }
                nodes[count] = value; depth[count] = depth[index] + 1; containers[count] = child + 1; ++count;
            }
        }
    } @catch (__unused NSException *exception) { result.exception = 1; }
    return result;
}
