// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
#import "MBModel.h"

@interface MBOverlayController : NSObject
@property(nonatomic, copy) BOOL (^isDisplayAllowed)(void);
@property(nonatomic, copy) void (^didDismiss)(uint64_t conversation);
// Presentation loss invalidates the coordinator epoch; purgeImmediately itself
// does not call back, preventing recursive purge/invalidation.
@property(nonatomic, copy) void (^didLosePresentation)(void);
// Only sanitized in-memory model data; no content/avatar/IPC payload.
- (BOOL)renderModel:(const MBModel *)model;
- (void)purgeImmediately;
@end
