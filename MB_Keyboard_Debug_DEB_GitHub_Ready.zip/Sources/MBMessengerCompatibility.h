// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stddef.h>

// Separate process scopes. Neither scope implies injection into an extension.
typedef NS_ENUM(NSUInteger, MBMessengerMetadataProcess) {
    MBMessengerMetadataMainApplication = 1,
    MBMessengerMetadataNotificationContentExtension = 2,
};

typedef NS_ENUM(NSUInteger, MBMessengerMetadataStatus) {
    MBMessengerMetadataUnknownProcess = 0,
    MBMessengerMetadataVersionMismatch,
    MBMessengerMetadataBuildMismatch,
    MBMessengerMetadataClassMissing,
    MBMessengerMetadataInstanceMethodMissing,
    MBMessengerMetadataABIMismatch,
    MBMessengerMetadataContractMatch,
    MBMessengerMetadataClassImageMismatch,
    MBMessengerMetadataIMPImageMismatch,
    MBMessengerMetadataImageUnavailable,
    MBMessengerMetadataInspectionLimit,
    MBMessengerMetadataFactsUnavailable,
    MBMessengerMetadataBundleMismatch,
    MBMessengerMetadataProcessMismatch,
    MBMessengerMetadataImageNotLoaded,
    MBMessengerMetadataImageScanLimit,
    MBMessengerMetadataException,
};

// Deliberately a struct, not a BOOL permission/capability result. Reason strings
// point to static descriptor literals; they never contain app/user metadata.
typedef struct {
    MBMessengerMetadataStatus status;
    const char *className;
    const char *selectorName;
    size_t matchedMethodCount;
} MBMessengerMetadataResult;

// Trusted metadata lookup seam for offline fixtures. Returns an unowned Class
// handle (bridge to void *), or NULL. A raw handle avoids ARC retain/autorelease
// of an uninitialized class. NULL lookup uses objc_lookUpClass in this process,
// without loading images or creating instances. The callback must be side-effect-free.
typedef void *(*MBMessengerMetadataClassLookup)(const char *className, void *context);

// Trusted verifier seam: called once for the class (method == NULL), then for
// each owned instance method. expectedRelativeImage is a descriptor literal.
// Return ContractMatch or a finite image failure; never invoke a candidate.
typedef MBMessengerMetadataStatus (*MBMessengerMetadataOriginVerifier)(
    void *classHandle, Method method, const char *expectedRelativeImage, void *context);

// Low-level metadata-only checker. Identity is caller-supplied here; use the
// passive diagnostic entry for production facts and image checks. This API is
// retained for isolated fixtures, not as permission to call private methods.
FOUNDATION_EXPORT MBMessengerMetadataResult MBCheckMessengerMetadataContract(
    MBMessengerMetadataProcess process, const char *version, const char *build,
    MBMessengerMetadataClassLookup lookup, void *context);

// Strict variant: an origin verifier is required. No launch, policy or IPC here.
// Even ContractMatch proves no call semantics, block prototype, routing or send.
FOUNDATION_EXPORT MBMessengerMetadataResult MBCheckMessengerMetadataContractWithOrigins(
    MBMessengerMetadataProcess process, const char *version, const char *build,
    MBMessengerMetadataClassLookup lookup, MBMessengerMetadataOriginVerifier verifier,
    void *context);
