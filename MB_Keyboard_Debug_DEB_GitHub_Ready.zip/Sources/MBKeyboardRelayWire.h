// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
#include <string.h>

// Fixed, pointer-free wire format. No object archive, chat data or arbitrary command.
#define MB_KEYBOARD_WIRE_MAGIC UINT32_C(0x4d424b31)
#define MB_KEYBOARD_WIRE_VERSION 1u
#define MB_KEYBOARD_NONCE_BYTES 16u

typedef enum { MBKeyboardWireHello = 1, MBKeyboardWireLease = 2, MBKeyboardWireFrame = 3 } MBKeyboardWireKind;
typedef struct {
    uint32_t magic, version, kind, flags; // Lease: 1=active. Frame: 1=hidden.
    uint8_t challenge[MB_KEYBOARD_NONCE_BYTES], session[MB_KEYBOARD_NONCE_BYTES];
    uint64_t sequence;
    double timestamp;
    double screenX, screenY, screenWidth, screenHeight;
    double frameX, frameY, frameWidth, frameHeight, duration;
    int32_t curve, orientation;
    uint32_t reserved[2];
} MBKeyboardWire;

static inline bool MBKeyboardNoncePresent(const uint8_t *nonce) {
    uint8_t value = 0;
    for (unsigned i = 0; i < MB_KEYBOARD_NONCE_BYTES; ++i) value |= nonce[i];
    return value != 0;
}
static inline bool MBKeyboardNonceEqual(const uint8_t *a, const uint8_t *b) {
    uint8_t value = 0;
    for (unsigned i = 0; i < MB_KEYBOARD_NONCE_BYTES; ++i) value |= a[i] ^ b[i];
    return value == 0;
}
static inline bool MBKeyboardWireEnvelopeValid(const MBKeyboardWire *p, double now) {
    return p && p->magic == MB_KEYBOARD_WIRE_MAGIC && p->version == MB_KEYBOARD_WIRE_VERSION &&
        p->kind >= MBKeyboardWireHello && p->kind <= MBKeyboardWireFrame && p->flags <= 1 &&
        p->reserved[0] == 0 && p->reserved[1] == 0 &&
        MBKeyboardNoncePresent(p->challenge) && isfinite(now) && now > 0 &&
        isfinite(p->timestamp) && p->timestamp > 0 && p->timestamp <= now + 0.1 && now - p->timestamp <= 1.0;
}
static inline bool MBKeyboardWireFrameValid(const MBKeyboardWire *p, double now) {
    if (!MBKeyboardWireEnvelopeValid(p, now) || p->kind != MBKeyboardWireFrame ||
        !MBKeyboardNoncePresent(p->session) || p->sequence == 0 ||
        !isfinite(p->screenX) || !isfinite(p->screenY) || fabs(p->screenX) > 8192 || fabs(p->screenY) > 8192 ||
        !isfinite(p->screenWidth) || !isfinite(p->screenHeight) ||
        p->screenWidth < 1 || p->screenHeight < 1 || p->screenWidth > 4096 || p->screenHeight > 4096 ||
        !isfinite(p->frameX) || !isfinite(p->frameY) || fabs(p->frameX) > 8192 || fabs(p->frameY) > 8192 ||
        !isfinite(p->frameWidth) || !isfinite(p->frameHeight) ||
        p->frameWidth < 0 || p->frameHeight < 0 || p->frameWidth > 4096 || p->frameHeight > 4096 ||
        !isfinite(p->duration) || p->duration < 0 || p->duration > 1 || p->curve < 0 || p->curve > 7 ||
        p->orientation < 1 || p->orientation > 4) return false;
    return true;
}
static inline bool MBKeyboardWireAcceptLease(const MBKeyboardWire *p, double now,
    const uint8_t *challenge, uint64_t previousSequence) {
    return MBKeyboardWireEnvelopeValid(p, now) && p->kind == MBKeyboardWireLease &&
        MBKeyboardNoncePresent(p->session) && MBKeyboardNonceEqual(p->challenge, challenge) &&
        p->sequence > previousSequence;
}
// Caller must authenticate the kernel audit token BEFORE invoking this check.
static inline bool MBKeyboardWireAcceptFrame(const MBKeyboardWire *p, double now,
    const uint8_t *challenge, const uint8_t *session, uint64_t previousSequence) {
    return MBKeyboardWireFrameValid(p, now) && MBKeyboardNonceEqual(p->challenge, challenge) &&
        MBKeyboardNonceEqual(p->session, session) && p->sequence > previousSequence;
}
