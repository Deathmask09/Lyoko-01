// SPDX-License-Identifier: MIT
#import "MBSceneDiagnosticReadout.h"
#import <notify.h>
#import <os/log.h>

static const unsigned MBBootstrapMask = MBSceneBootstrapScheduled | MBSceneBootstrapEntered |
    MBSceneBootstrapArmed | MBSceneBootstrapDelivered | MBSceneBootstrapFailed;
static const unsigned MBHookMask = MBSceneLaunchHookChecked | MBSceneLaunchHookInstalled | MBSceneLaunchHookCalled;

void MBSceneReadoutNoteBootstrap(MBSceneReadoutState *state, unsigned flags) {
    if (!state) return;
    pthread_mutex_lock(&state->lock);
    state->snapshot.bootstrapFlags |= flags & MBBootstrapMask;
    pthread_mutex_unlock(&state->lock);
}
void MBSceneReadoutNoteHook(MBSceneReadoutState *state, unsigned flags) {
    if (!state) return;
    pthread_mutex_lock(&state->lock);
    state->snapshot.hookFlags |= flags & MBHookMask;
    pthread_mutex_unlock(&state->lock);
}
void MBSceneReadoutNoteProgress(MBSceneReadoutState *state, MBSceneHostDiagnosticStage stage,
                               MBSceneHostDiagnosticTrigger trigger) {
    if (!state || stage > MBSceneHostStageDeliveryException || trigger > MBSceneHostTriggerPublicActiveCatchUp) return;
    pthread_mutex_lock(&state->lock);
    if (stage == MBSceneHostStageAccepted && !(state->snapshot.progressFlags & (1u << MBSceneHostStageAccepted)))
        state->snapshot.acceptedTrigger = trigger;
    state->snapshot.progressFlags |= 1u << stage;
    pthread_mutex_unlock(&state->lock);
}
MBSceneReadoutSnapshot MBSceneReadoutCopySnapshot(MBSceneReadoutState *state) {
    if (!state) return (MBSceneReadoutSnapshot){0};
    pthread_mutex_lock(&state->lock);
    MBSceneReadoutSnapshot snapshot = state->snapshot;
    pthread_mutex_unlock(&state->lock);
    return snapshot;
}
static BOOL MBReadoutValidReport(const MBSceneHostDiagnosticReport *report) {
    // Check the bound BEFORE reading items or copying any caller-controlled count.
    if (!report || report->count > MB_SCENE_HOST_CATALOG_MAX || report->count > MBSceneHostCatalogCount() ||
        report->processStatus > MBSceneHostStatusMax ||
        !MBSceneMainImageObservationIsValid(report->mainImage)) return NO;
    if (report->processStatus != MBSceneHostMetadataMatch && report->count != 0) return NO;
    for (size_t i = 0; i < report->count; ++i)
        if (report->items[i] > MBSceneHostStatusMax) return NO;
    return YES;
}
static void MBReadoutDeliverReport(MBSceneReadoutDependencies deps, const MBSceneHostDiagnosticReport *report) {
    @try { deps.reportSink(report, deps.context); }
    @catch (__unused NSException *exception) { /* quota stays consumed */ }
}
BOOL MBSceneReadoutStoreReport(MBSceneReadoutState *state, const MBSceneHostDiagnosticReport *report) {
    if (!state || !MBReadoutValidReport(report)) return NO;
    MBSceneHostDiagnosticReport copy = { .processStatus = report->processStatus,
        .mainImage = report->mainImage, .count = report->count };
    for (size_t i = 0; i < copy.count; ++i) copy.items[i] = report->items[i];
    MBSceneReadoutDependencies deps = {0};
    BOOL deliver = NO;
    pthread_mutex_lock(&state->lock);
    if (state->snapshot.reportStored) { pthread_mutex_unlock(&state->lock); return NO; }
    state->report = copy;
    state->snapshot.reportStored = YES;
    if (state->snapshot.requestClaimed && !state->snapshot.replayClaimed) {
        state->snapshot.replayClaimed = YES;
        deps = state->pending;
        deliver = YES;
    }
    pthread_mutex_unlock(&state->lock);
    if (deliver) MBReadoutDeliverReport(deps, &copy);
    return YES;
}
BOOL MBSceneReadoutRequest(MBSceneReadoutState *state, MBSceneReadoutDependencies deps) {
    if (!state || !deps.statusSink || !deps.reportSink) return NO;
    MBSceneHostDiagnosticReport report = {0};
    MBSceneReadoutSnapshot snapshot;
    BOOL deliver = NO;
    pthread_mutex_lock(&state->lock);
    if (state->snapshot.requestClaimed) { pthread_mutex_unlock(&state->lock); return NO; }
    state->snapshot.requestClaimed = YES;
    state->pending = deps;
    if (state->snapshot.reportStored && !state->snapshot.replayClaimed) {
        state->snapshot.replayClaimed = YES;
        report = state->report;
        deliver = YES;
    }
    snapshot = state->snapshot;
    pthread_mutex_unlock(&state->lock);
    @try { deps.statusSink(&snapshot, deps.context); }
    @catch (__unused NSException *exception) { /* still allow the independent report sink */ }
    if (deliver) MBReadoutDeliverReport(deps, &report);
    return YES;
}

static MBSceneReadoutState MBProductionReadout = MB_SCENE_READOUT_STATE_INIT;
void MBRecordSceneBootstrap(unsigned flags) { MBSceneReadoutNoteBootstrap(&MBProductionReadout, flags); }
void MBRecordSceneLaunchHook(unsigned flags) { MBSceneReadoutNoteHook(&MBProductionReadout, flags); }
void MBRecordSceneDiagnosticProgress(MBSceneHostDiagnosticStage stage, MBSceneHostDiagnosticTrigger trigger) {
    MBSceneReadoutNoteProgress(&MBProductionReadout, stage, trigger);
}
void MBRetainSceneDiagnosticReport(const MBSceneHostDiagnosticReport *report) {
    (void)MBSceneReadoutStoreReport(&MBProductionReadout, report);
}
static os_log_t MBReadoutLog(void) {
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "scene-readout"); });
    return log;
}
static void MBReadoutLogStatus(const MBSceneReadoutSnapshot *s, __unused void *context) {
    os_log(MBReadoutLog(), "MBSceneReadout scope=springboard feature=snapshot tweak_build=%{public}s bootstrap_flags=%u hook_flags=%u progress_flags=%u trigger=%{public}s cached=%d request_claimed=%d replay_claimed=%d",
        APELIN_BUILD_ID, s->bootstrapFlags, s->hookFlags, s->progressFlags,
        MBSceneHostDiagnosticTriggerName(s->acceptedTrigger), s->reportStored, s->requestClaimed, s->replayClaimed);
}
static void MBReadoutLogReport(const MBSceneHostDiagnosticReport *report, __unused void *context) {
    MBEmitSceneHostDiagnosticReport(report, YES);
}
void MBInstallSceneDiagnosticReadout(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        dispatch_queue_t queue = dispatch_queue_create(APELIN_PACKAGE_ID ".scene-readout", DISPATCH_QUEUE_SERIAL);
        dispatch_async(queue, ^{
            @autoreleasepool {
                if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
                int token = 0;
                __block BOOL requested = NO; // confined to this serial queue
                uint32_t result = notify_register_dispatch(MB_SCENE_READOUT_NOTIFICATION, &token, queue, ^(int receivedToken) {
                    // This signal is diagnostic-only, NOT authenticated control.
                    // Cancel once, before emitting. Ignore already queued copies.
                    if (requested) return;
                    requested = YES;
                    (void)notify_cancel(receivedToken);
                    (void)MBSceneReadoutRequest(&MBProductionReadout, (MBSceneReadoutDependencies){
                        .statusSink = MBReadoutLogStatus, .reportSink = MBReadoutLogReport,
                    });
                });
                os_log(MBReadoutLog(), "MBSceneReadout scope=springboard feature=listener tweak_build=%{public}s result=%{public}s",
                    APELIN_BUILD_ID, result == NOTIFY_STATUS_OK ? "ready" : "registration-failed");
            }
        });
    });
}
