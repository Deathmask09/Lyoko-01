// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>

// A one-shot public-lifecycle bootstrap, not a scene host or permission gate.
// Registration/start/invalidate and delivery are main-thread-only. Notifications
// may arrive on any thread; at most one delivery is queued. No timers/retries.
typedef NS_ENUM(unsigned, MBLifecycleSource) {
    MBLifecycleSourceNone = 0, MBLifecycleSourceLaunch,
    MBLifecycleSourceActive, MBLifecycleSourceActiveCatchUp,
};
typedef NS_ENUM(unsigned, MBLifecycleState) {
    MBLifecycleStateNew = 0, MBLifecycleStateRegistering, MBLifecycleStateArmed,
    MBLifecycleStateQueued, MBLifecycleStateExecuting, MBLifecycleStateFinished,
    MBLifecycleStateInvalidated,
};
typedef void (^MBLifecycleMainEnqueue)(dispatch_block_t _Nonnull work);

NS_ASSUME_NONNULL_BEGIN
@interface MBPublicLifecycle : NSObject
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
// Production passes fixed UIKit notification names, the public active-state
// reader, and dispatch_async(main). The seams let offline tests drive the same
// registration/order/cancellation code without UIKit or a target process.
- (nullable instancetype)initWithCenter:(NSNotificationCenter *)center
                    launchNotification:(NSNotificationName)launch
                    activeNotification:(NSNotificationName)active
                              isActive:(BOOL (^)(void))isActive
                            enqueueMain:(MBLifecycleMainEnqueue)enqueueMain
                               handler:(void (^)(MBLifecycleSource source))handler;
// Register both observers BEFORE reading readiness. An event during registration
// is remembered, but cannot deliver until registration has completed. An active
// catch-up is a scheduling hint only; the consumer still validates actual facts.
- (BOOL)start;
// Idempotent; cannot undo a handler which has already begun. Returns NO off-main.
- (BOOL)invalidate;
@property(nonatomic, readonly) MBLifecycleState state;
@property(nonatomic, readonly) MBLifecycleSource source;
@end
NS_ASSUME_NONNULL_END
