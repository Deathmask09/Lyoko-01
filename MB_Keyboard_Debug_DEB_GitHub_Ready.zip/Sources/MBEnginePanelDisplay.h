// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import "MBRuntime.h"
#import "MBEngineBubbleShape.h"
#import "MBKeyboardViewportGeometry.h"

// Exact copy-method prototypes observed in the SHA-pinned engine's display
// configuration builder (both slices). No raw vendor IMP, initializer, defaults,
// global display mutation, or synthetic display mode is used here.
@protocol MBEngineDisplayConfigurationCopying
- (id)copyWithOverrideBounds:(CGRect)bounds;
- (id)copyWithOverrideMode:(id)mode pixelSize:(CGSize)pixels nativeBounds:(CGRect)nativeBounds;
@end

static inline BOOL MBEngineReadDisplaySize(id object, SEL selector, CGSize *out) {
    if (!object || !out) return NO;
    @try {
        Class cls = object_getClass(object);
        if (MBMethodMatches(cls, selector, @encode(CGSize), 0, NULL)) {
            *out = ((CGSize (*)(id, SEL))objc_msgSend)(object, selector);
        } else if (MBMethodMatches(cls, selector, @encode(CGRect), 0, NULL)) {
            CGRect rect = ((CGRect (*)(id, SEL))objc_msgSend)(object, selector);
            if (!CGPointEqualToPoint(rect.origin, CGPointZero)) return NO;
            *out = rect.size;
        } else return NO;
        return isfinite(out->width) && isfinite(out->height) &&
            out->width >= 1 && out->height >= 1 && out->width <= 32768 && out->height <= 32768;
    } @catch (__unused NSException *exception) { return NO; }
}

static inline BOOL MBEngineDisplayConfigurationMatches(id configuration, CGSize target) {
    if (!configuration || !MBEnginePanelBoundsValid(0, 0, target.width, target.height)) return NO;
    CGSize points, pixels, native;
    if (!MBEngineReadDisplaySize(configuration, sel_registerName("bounds"), &points) ||
        !MBEngineReadDisplaySize(configuration, sel_registerName("pixelSize"), &pixels) ||
        !MBEngineReadDisplaySize(configuration, sel_registerName("_nativeBounds"), &native)) return NO;
    double sx = pixels.width / points.width, sy = pixels.height / points.height;
    return fabs(points.width - target.width) <= 0.5 && fabs(points.height - target.height) <= 0.5 &&
        sx >= 0.99 && sx <= 4.01 && sy >= 0.99 && sy <= 4.01 && fabs(sx - sy) <= 0.01 &&
        fabs(native.width - pixels.width) <= 1 && fabs(native.height - pixels.height) <= 1;
}

// Return a private COPY of the current real display configuration for this
// viewport, retaining the real mode and scale. Unsupported metadata fails closed:
// never silently resize just the app frame while leaving the IME on phone bounds.
static inline id MBEngineCreatePanelDisplayConfiguration(id mainConfiguration, CGSize target) {
    if (!mainConfiguration || !MBEnginePanelBoundsValid(0, 0, target.width, target.height)) return nil;
    @try {
        CGSize points, pixels;
        if (!MBEngineReadDisplaySize(mainConfiguration, sel_registerName("bounds"), &points) ||
            !MBEngineReadDisplaySize(mainConfiguration, sel_registerName("pixelSize"), &pixels)) return nil;
        MBKeyboardViewportProjection projection;
        if (!MBKeyboardProjectViewportPixels(points.width, points.height, pixels.width, pixels.height,
                                             target.width, target.height, &projection)) return nil;
        id modes = MBReadObject(mainConfiguration, sel_registerName("availableModes"));
        if ([modes isKindOfClass:NSSet.class]) modes = [(NSSet *)modes allObjects];
        if (![modes isKindOfClass:NSArray.class] || [modes count] > 32) return nil;
        id mode = nil;
        for (id candidate in modes) {
            CGSize size;
            // FBSDisplayMode exposes logical size and pixelSize separately.
            // Compare physical pixels to pixels, not logical points to pixels.
            if (!MBEngineReadDisplaySize(candidate, sel_registerName("pixelSize"), &size)) continue;
            if (fabs(size.width - pixels.width) <= 1 && fabs(size.height - pixels.height) <= 1) {
                mode = candidate; break;
            }
        }
        if (!mode) return nil; // Never select an arbitrary fallback mode.
        const char *boundsArgs[] = {@encode(CGRect)};
        if (!MBMethodMatches(object_getClass(mainConfiguration), sel_registerName("copyWithOverrideBounds:"),
                             "@", 1, boundsArgs)) return nil;
        id resized = [(id<MBEngineDisplayConfigurationCopying>)mainConfiguration
            copyWithOverrideBounds:(CGRect){CGPointZero, target}];
        // A copy must not be the live/main object: do not change shared state.
        if (!resized || resized == mainConfiguration) return nil;
        const char *modeArgs[] = {"@", @encode(CGSize), @encode(CGRect)};
        if (!MBMethodMatches(object_getClass(resized),
            sel_registerName("copyWithOverrideMode:pixelSize:nativeBounds:"), "@", 3, modeArgs)) return nil;
        CGSize native = CGSizeMake(projection.widthPixels, projection.heightPixels);
        id result = [(id<MBEngineDisplayConfigurationCopying>)resized copyWithOverrideMode:mode
            pixelSize:native nativeBounds:(CGRect){CGPointZero, native}];
        if (result == mainConfiguration || !MBEngineDisplayConfigurationMatches(result, target)) return nil;
        return result;
    } @catch (__unused NSException *exception) { return nil; }
}
