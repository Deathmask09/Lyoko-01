// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>

// Reads section/date/bulletinID only; never title, body, context, thread or action.
FOUNDATION_EXPORT NSData * _Nullable MBEngineNotificationToken(id _Nullable bulletin, NSTimeInterval now);

// Main-queue bounded, transient duplicate suppression. No persistence or IPC.
@interface MBEngineEventHistory : NSObject
- (BOOL)acceptToken:(NSData * _Nullable)token;
- (void)removeAll;
@end
