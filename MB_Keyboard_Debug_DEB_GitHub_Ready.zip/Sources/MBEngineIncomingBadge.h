// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import "MBEngineBubbleShape.h"
#import "MBEngineBadgeGeometry.h"

// A non-interactive child of the engine's bubble, never a separate overlay/hit area.
// Bounds are unscaled (44 pt); the existing placement transform scales everything to 65 pt.
static char MBEngineIncomingBadgeKey;
static inline UILabel *MBEngineUpdateIncomingBadge(UIView *bubble, unsigned count) {
    if (![bubble isKindOfClass:UIView.class]) return nil;
    UILabel *badge = objc_getAssociatedObject(bubble, &MBEngineIncomingBadgeKey);
    if (!count) {
        badge.hidden = YES;
        bubble.accessibilityValue = nil;
        return badge;
    }
    MBEngineCircle circle;
    if (!MBEngineCircleInBounds(bubble.bounds.size.width, bubble.bounds.size.height, &circle)) {
        badge.hidden = YES;
        return badge;
    }
    if (!badge) {
        badge = [UILabel new];
        badge.userInteractionEnabled = NO;
        badge.isAccessibilityElement = NO;
        badge.textAlignment = NSTextAlignmentCenter;
        badge.backgroundColor = UIColor.systemRedColor;
        badge.textColor = UIColor.whiteColor;
        badge.layer.borderColor = UIColor.whiteColor.CGColor;
        badge.layer.cornerCurve = kCACornerCurveCircular;
        badge.clipsToBounds = YES;
        objc_setAssociatedObject(bubble, &MBEngineIncomingBadgeKey, badge, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [bubble addSubview:badge];
    }
    NSString *text = count > 99 ? @"99+" : [NSString stringWithFormat:@"%u", count];
    MBEngineBadgeMetrics metrics;
    if (!MBEngineIncomingBadgeMetrics(circle.diameter, (unsigned)text.length, &metrics)) {
        badge.hidden = YES;
        return badge;
    }
    CGFloat height = metrics.height, width = metrics.width;
    CGRect frame = CGRectMake(CGRectGetMaxX(bubble.bounds) - circle.x - width,
                              bubble.bounds.origin.y + circle.y, width, height);
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    badge.text = text;
    badge.font = [UIFont monospacedDigitSystemFontOfSize:metrics.fontSize weight:UIFontWeightBold];
    badge.frame = frame;
    badge.layer.cornerRadius = height / 2;
    badge.layer.borderWidth = metrics.borderWidth;
    badge.hidden = NO;
    [bubble bringSubviewToFront:badge];
    bubble.accessibilityValue = count > 99 ? @"Hơn 99 thông báo mới trong phiên" :
        [NSString stringWithFormat:@"%u thông báo mới trong phiên", count];
    [CATransaction commit];
    return badge;
}
