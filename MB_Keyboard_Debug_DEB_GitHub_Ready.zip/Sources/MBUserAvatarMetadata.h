// SPDX-License-Identifier: MIT
#pragma once
#import "MBMessengerMetadata.h"

NS_ASSUME_NONNULL_BEGIN
/// Photo identity only. Does not establish a navigation route or unread authority.
@interface MBUserAvatarMetadata : NSObject
@property(nonatomic, readonly, copy) NSString *accountID;
@property(nonatomic, readonly, copy) NSString *subjectID; // Exact userID OR group transport ID, never conflated.
@property(nonatomic, readonly) BOOL groupSubject;
@property(nonatomic, readonly, copy) NSString *reference;
@property(nonatomic, readonly, copy, nullable) NSString *fallbackReference;
@property(nonatomic, readonly) int64_t expirationTimestampMS; // Selected primary only; -1 unknown/fallback, never CDN freshness proof.
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
@end

/// Same worker-owned read-only/transaction contract as MBMessengerMetadata.
/// Verifies the sole self_profile owner equals accountID, resolves a unique
/// non-pending other participant through fb_transport_contacts to contacts.id.
/// Missing/ambiguous IDs/photos fail closed. Group uses only its own thread photo.
/// No file open, sidecar/write, log, network, hook, polling or callback replacement.
FOUNDATION_EXPORT MBUserAvatarMetadata * _Nullable MBUserAvatarReadForTransport(
    sqlite3 *readOnlySnapshot, NSString *accountID, NSString *transportThreadID,
    NSError * _Nullable * _Nullable error);
NS_ASSUME_NONNULL_END
