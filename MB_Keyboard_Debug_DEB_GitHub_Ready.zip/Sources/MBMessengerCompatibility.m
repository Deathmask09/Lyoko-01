// SPDX-License-Identifier: MIT
#import "MBMessengerCompatibility.h"
#import "MBRuntime.h"
#include <stdlib.h>
#include <string.h>

typedef struct {
    const char *selectorName;
    const char *returnType;
    unsigned argumentCount;
    const char *argumentTypes[5];
} MBMessengerMethodContract;

typedef struct {
    const char *className;
    const char *relativeImage;
    const MBMessengerMethodContract *methods;
    size_t methodCount;
} MBMessengerClassContract;

// Static evidence: Messenger 579.0.0 / 1068430635. See Docs/MESSENGER_579.md.
// Literal ABI tokens are intentional: mailboxType is i, flags are Q, blocks @?.
static const MBMessengerMethodContract MB579AppDelegateMethods[] = {
    {"application:openURL:options:", "B", 3, {"@", "@", "@"}},
    {"didReceiveMessageNotificationWithPayload:", "v", 1, {"@"}},
    {"didReceiveMessageCountNotificationWithPayload:", "v", 1, {"@"}},
    {"didReceiveAdvancedCryptoTransportNotificationWithPayload:", "v", 1, {"@"}},
    {"navigateToThread:mailboxType:pushPayload:accountSwitchNeeded:completion:",
        "v", 5, {"@", "i", "@", "B", "@?"}},
};
static const MBMessengerMethodContract MB579SceneDelegateMethods[] = {
    {"application:configurationForConnectingSceneSession:options:", "@", 3, {"@", "@", "@"}},
};
static const MBMessengerMethodContract MB579NotificationHandlerMethods[] = {
    {"userNotificationCenter:didReceiveNotificationResponse:withCompletionHandler:", "v", 3, {"@", "@", "@?"}},
    {"userNotificationCenter:willPresentNotification:withCompletionHandler:", "v", 3, {"@", "@", "@?"}},
};
static const MBMessengerMethodContract MB579NotificationContentMethods[] = {
    {"didReceiveNotification:", "v", 1, {"@"}},
    {"didReceiveNotificationResponse:completionHandler:", "v", 2, {"@", "@?"}},
    {"notificationActionsSend:successFlag:failureFlag:", "v", 3, {"@", "Q", "Q"}},
    {"inputAccessoryView", "@", 0, {NULL}},
};

#define MB_ARRAY_COUNT(array) (sizeof(array) / sizeof((array)[0]))
#define MB_CORE_IMAGE "Frameworks/LightSpeedCore.framework/LightSpeedCore"
static const MBMessengerClassContract MB579MainClasses[] = {
    {"LSAppDelegate", MB_CORE_IMAGE, MB579AppDelegateMethods, MB_ARRAY_COUNT(MB579AppDelegateMethods)},
    {"LSAppDelegateWithiOSScenesSupport", MB_CORE_IMAGE, MB579SceneDelegateMethods, MB_ARRAY_COUNT(MB579SceneDelegateMethods)},
    {"LSNotificationHandler", MB_CORE_IMAGE, MB579NotificationHandlerMethods, MB_ARRAY_COUNT(MB579NotificationHandlerMethods)},
};
static const MBMessengerClassContract MB579ContentClasses[] = {
    {"MSGNCEViewController", "PlugIns/MessengerNotificationContentExtension.appex/MessengerNotificationContentExtension",
        MB579NotificationContentMethods, MB_ARRAY_COUNT(MB579NotificationContentMethods)},
};
#undef MB_CORE_IMAGE
#undef MB_ARRAY_COUNT

static Method MBOwnedInstanceMethod(Class cls, SEL selector, BOOL *limited) {
    unsigned count = 0;
    Method *methods = class_copyMethodList(cls, &count);
    Method found = NULL;
    *limited = count > 4096;
    if (!*limited) {
        for (unsigned i = 0; methods && i < count; ++i) {
            if (sel_isEqual(method_getName(methods[i]), selector)) { found = methods[i]; break; }
        }
    }
    free(methods);
    return found;
}

static MBMessengerMetadataStatus MBVerifiedOrigin(MBMessengerMetadataOriginVerifier verifier,
    void *handle, Method method, const char *relativeImage, void *context) {
    MBMessengerMetadataStatus status = verifier(handle, method, relativeImage, context);
    switch (status) {
        case MBMessengerMetadataContractMatch:
        case MBMessengerMetadataClassImageMismatch:
        case MBMessengerMetadataIMPImageMismatch:
        case MBMessengerMetadataImageUnavailable: return status;
        default: return MBMessengerMetadataFactsUnavailable;
    }
}

static MBMessengerMetadataResult MBInspectMessengerMetadata(
    MBMessengerMetadataProcess process, const char *version, const char *build,
    MBMessengerMetadataClassLookup lookup, MBMessengerMetadataOriginVerifier verifier,
    void *context) {
    MBMessengerMetadataResult result = { .status = MBMessengerMetadataUnknownProcess };
    const MBMessengerClassContract *classes = NULL;
    size_t classCount = 0;
    switch (process) {
        case MBMessengerMetadataMainApplication:
            classes = MB579MainClasses;
            classCount = sizeof(MB579MainClasses) / sizeof(MB579MainClasses[0]);
            break;
        case MBMessengerMetadataNotificationContentExtension:
            classes = MB579ContentClasses;
            classCount = sizeof(MB579ContentClasses) / sizeof(MB579ContentClasses[0]);
            break;
        default: return result;
    }
    if (!version || strcmp(version, "579.0.0") != 0) {
        result.status = MBMessengerMetadataVersionMismatch;
        return result;
    }
    if (!build || strcmp(build, "1068430635") != 0) {
        result.status = MBMessengerMetadataBuildMismatch;
        return result;
    }
    for (size_t i = 0; i < classCount; ++i) {
        const MBMessengerClassContract *contract = &classes[i];
        result.className = contract->className;
        result.selectorName = NULL;
        __unsafe_unretained Class cls = lookup ? (__bridge Class)lookup(contract->className, context) : objc_lookUpClass(contract->className);
        if (!cls || class_isMetaClass(cls)) {
            result.status = MBMessengerMetadataClassMissing;
            return result;
        }
        if (verifier) {
            result.status = MBVerifiedOrigin(verifier, (__bridge void *)cls, NULL, contract->relativeImage, context);
            if (result.status != MBMessengerMetadataContractMatch) return result;
        }
        for (size_t j = 0; j < contract->methodCount; ++j) {
            const MBMessengerMethodContract *method = &contract->methods[j];
            result.selectorName = method->selectorName;
            SEL selector = sel_registerName(method->selectorName);
            // Inheritance or a similarly named class method is not evidence of
            // the declaring-class instance contract recorded in the binary.
            BOOL limited = NO;
            Method owned = MBOwnedInstanceMethod(cls, selector, &limited);
            if (limited || !owned) {
                result.status = limited ? MBMessengerMetadataInspectionLimit : MBMessengerMetadataInstanceMethodMissing;
                return result;
            }
            if (!MBMethodMatches(cls, selector, method->returnType,
                                 method->argumentCount, method->argumentTypes)) {
                result.status = MBMessengerMetadataABIMismatch;
                return result;
            }
            if (verifier) {
                result.status = MBVerifiedOrigin(verifier, (__bridge void *)cls, owned, contract->relativeImage, context);
                if (result.status != MBMessengerMetadataContractMatch) return result;
            }
            ++result.matchedMethodCount;
        }
    }
    result.status = MBMessengerMetadataContractMatch;
    result.className = NULL;
    result.selectorName = NULL;
    return result;
}

MBMessengerMetadataResult MBCheckMessengerMetadataContract(
    MBMessengerMetadataProcess process, const char *version, const char *build,
    MBMessengerMetadataClassLookup lookup, void *context) {
    return MBInspectMessengerMetadata(process, version, build, lookup, NULL, context);
}

MBMessengerMetadataResult MBCheckMessengerMetadataContractWithOrigins(
    MBMessengerMetadataProcess process, const char *version, const char *build,
    MBMessengerMetadataClassLookup lookup, MBMessengerMetadataOriginVerifier verifier,
    void *context) {
    if (!verifier) return (MBMessengerMetadataResult){ .status = MBMessengerMetadataFactsUnavailable };
    return MBInspectMessengerMetadata(process, version, build, lookup, verifier, context);
}
