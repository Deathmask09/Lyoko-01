// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "MBEnginePolicy.h"

// Immutable snapshot captured on the main thread, checked without touching
// UIKit, associated objects, weak view state, or mutable ObjC properties.
// The generation is atomically revoked on panel replacement and session exit.
typedef struct {
    uint64_t generation;
    uint64_t ingressEpoch;
    double started;
} MBSceneSizeRequestTicket;

static inline bool MBSceneSizeRequestTicketAllows(MBSceneSizeRequestTicket ticket,
    uint64_t currentGeneration, uint64_t currentIngressEpoch,
    bool sessionActive, double now) {
    return ticket.generation > 0 && ticket.generation == currentGeneration &&
        ticket.ingressEpoch > 0 && ticket.ingressEpoch == currentIngressEpoch &&
        MBEngineWatchMayContinue(ticket.started, now, sessionActive);
}
