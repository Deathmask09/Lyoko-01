// SPDX-License-Identifier: MIT
#import "MBSpringBoardCoordinator.h"
#import "MBConfiguration.h"
#import "MBRuntime.h"
#import "MBOverlayController.h"
#import "MBNotificationAdapter.h"
#import "MBEventGate.h"
#import <substrate.h>
#import <notify.h>

static MBEventGate MBUIGate = { .state = ATOMIC_VAR_INIT(2) };
static atomic_bool MBObservationEnabled;
static atomic_bool MBMainPurgePending;
static atomic_bool MBTransitionThreadSafe = ATOMIC_VAR_INIT(true);
static void (*MBOriginalFrontChange)(id, SEL, id);
static void (*MBOriginalLockInteger)(id, SEL, NSInteger, id);
static void (*MBOriginalLockInt)(id, SEL, int, id);

@interface MBSpringBoardCoordinator : NSObject {
    MBModel _model;
    BOOL _runtimeCompatible;
    BOOL _reloadPending;
    BOOL _reloadDirty;
    NSString *_lastForeground;
}
@property(nonatomic, strong) MBConfiguration *configuration;
@property(nonatomic, strong) MBOverlayController *overlay;
- (void)start;
- (void)purge;
- (void)refreshPolicy;
- (void)reloadConfiguration;
- (void)receiveConversation:(uint64_t)conversation event:(uint64_t)event epoch:(uint64_t)epoch;
@end
static MBSpringBoardCoordinator *MBCoordinator;

void MBInvalidateSpringBoardFoundation(void) {
    BOOL main = NSThread.isMainThread;
    // Invalidate BEFORE deciding who owns the queued purge. Otherwise a
    // background caller can decline enqueue, pause, and close the gate only
    // after the worker has cleared pending (a lost-purge ordering).
    MBEventGateInvalidate(&MBUIGate);
    if (main) { [MBCoordinator purge]; return; }
    if (atomic_exchange_explicit(&MBMainPurgePending, true, memory_order_acq_rel)) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBCoordinator purge];
        atomic_store_explicit(&MBMainPurgePending, false, memory_order_release);
    });
}

static BOOL MBThreadAndQueuePermit(void) {
    return atomic_load_explicit(&MBTransitionThreadSafe, memory_order_acquire) &&
        !atomic_load_explicit(&MBMainPurgePending, memory_order_acquire);
}
uint64_t MBCurrentIngressEpoch(void) {
    if (!MB_RUNTIME_PRIVACY_REVIEWED || !MBThreadAndQueuePermit()) return 0;
    return MBEventGateAllowedEpoch(&MBUIGate); // permission + epoch: one load
}
uint64_t MBCaptureBulletinEpoch(void) {
    if (!MB_RUNTIME_PRIVACY_REVIEWED || !MBThreadAndQueuePermit() ||
        !atomic_load_explicit(&MBObservationEnabled, memory_order_acquire)) return 0;
    return MBEventGateEpoch(&MBUIGate);
}
void MBSubmitBulletinDigests(uint64_t conversation, uint64_t event, uint64_t epoch) {
    if (!NSThread.isMainThread || !epoch || epoch != MBCaptureBulletinEpoch()) return;
    [MBCoordinator receiveConversation:conversation event:event epoch:epoch];
}

static void MBPreTransition(void) {
    // Observing an off-main privacy transition permanently disables the
    // adapter for this launch. This does NOT prove physical hiding before the
    // original on that path; therefore the review gate remains closed.
    if (!NSThread.isMainThread) atomic_store_explicit(&MBTransitionThreadSafe, false, memory_order_release);
    MBInvalidateSpringBoardFoundation();
}
static void MBHookFrontChange(id self, SEL cmd, id display) {
    MBPreTransition();
    if (MBOriginalFrontChange) MBOriginalFrontChange(self, cmd, display);
    if (NSThread.isMainThread) [MBCoordinator refreshPolicy];
}
static void MBHookLockInteger(id self, SEL cmd, NSInteger source, id options) {
    MBPreTransition();
    if (MBOriginalLockInteger) MBOriginalLockInteger(self, cmd, source, options);
}
static void MBHookLockInt(id self, SEL cmd, int source, id options) {
    MBPreTransition();
    if (MBOriginalLockInt) MBOriginalLockInt(self, cmd, source, options);
}
static id MBLockManager(void) {
    Class cls = objc_getClass("SBLockScreenManager");
    id object = MBReadObject(cls, NSSelectorFromString(@"sharedInstance"));
    return cls && [object isKindOfClass:cls] ? object : nil;
}
static BOOL MBInstallPrivacyAdapter(void) {
    if (!MB_RUNTIME_PRIVACY_REVIEWED) return NO;
    NSOperatingSystemVersion os = NSProcessInfo.processInfo.operatingSystemVersion;
    if (os.majorVersion != 16 || os.minorVersion != 5 || os.patchVersion != 0) return NO;
    Class sb = objc_getClass("SpringBoard");
    Class lockClass = objc_getClass("SBLockScreenManager");
    Class appClass = objc_getClass("SBApplication");
    SEL front = NSSelectorFromString(@"frontDisplayDidChange:");
    SEL lock = NSSelectorFromString(@"lockUIFromSource:withOptions:");
    const char *objectArgument[] = {"@"};
    const char *integerArguments[] = {@encode(NSInteger), "@"};
    const char *intArguments[] = {@encode(int), "@"};
    BOOL wide = MBMethodMatches(lockClass, lock, "v", 2, integerArguments);
    BOOL narrow = MBMethodMatches(lockClass, lock, "v", 2, intArguments);
    if (!MBMethodMatches(sb, front, "v", 1, objectArgument) || (!wide && !narrow) ||
        !MBMethodMatches(sb, NSSelectorFromString(@"_accessibilityFrontMostApplication"), "@", 0, NULL) ||
        !MBMethodMatches(appClass, NSSelectorFromString(@"bundleIdentifier"), "@", 0, NULL) ||
        !MBMethodMatches(lockClass, NSSelectorFromString(@"isUILocked"), @encode(BOOL), 0, NULL) || !MBLockManager()) return NO;
    MSHookMessageEx(sb, front, (IMP)MBHookFrontChange, (IMP *)&MBOriginalFrontChange);
    if (wide) MSHookMessageEx(lockClass, lock, (IMP)MBHookLockInteger, (IMP *)&MBOriginalLockInteger);
    else MSHookMessageEx(lockClass, lock, (IMP)MBHookLockInt, (IMP *)&MBOriginalLockInt);
    return MBOriginalFrontChange && (MBOriginalLockInteger || MBOriginalLockInt);
}

@implementation MBSpringBoardCoordinator
- (instancetype)init {
    self = [super init];
    if (self) {
        MBModelInit(&_model);
        _configuration = [[MBConfiguration alloc] initWithEnabled:NO safeApplications:[NSSet set]];
        _overlay = [MBOverlayController new];
        __weak MBSpringBoardCoordinator *weakSelf = self;
        _overlay.isDisplayAllowed = ^BOOL { return MBCurrentIngressEpoch() != 0; };
        _overlay.didLosePresentation = ^{ MBInvalidateSpringBoardFoundation(); };
        _overlay.didDismiss = ^(uint64_t conversation) {
            MBSpringBoardCoordinator *owner = weakSelf;
            if (!owner || !MBCurrentIngressEpoch()) return;
            if (MBModelDismiss(&owner->_model, conversation) &&
                ![owner.overlay renderModel:&owner->_model] && owner->_model.count) {
                MBInvalidateSpringBoardFoundation();
            }
        };
    }
    return self;
}
- (void)start {
    NSAssert(NSThread.isMainThread, @"Coordinator must start on main");
    _runtimeCompatible = MBInstallPrivacyAdapter() && MBInstallNotificationAdapter();
    int configurationToken = 0, invalidationToken = 0, lockToken = 0;
    uint32_t configurationStatus = notify_register_dispatch(APELIN_PACKAGE_ID "/changed", &configurationToken,
        dispatch_get_main_queue(), ^(__unused int token) { [self reloadConfiguration]; });
    uint32_t invalidationStatus = notify_register_dispatch(APELIN_PACKAGE_ID "/messenger/invalidate", &invalidationToken,
        dispatch_get_main_queue(), ^(__unused int token) { MBInvalidateSpringBoardFoundation(); });
    uint32_t lockStatus = notify_register_dispatch("com.apple.springboard.lockstate", &lockToken,
        dispatch_get_main_queue(), ^(__unused int token) {
            MBInvalidateSpringBoardFoundation();
            [self refreshPolicy];
        });
    if (configurationStatus != NOTIFY_STATUS_OK || invalidationStatus != NOTIFY_STATUS_OK || lockStatus != NOTIFY_STATUS_OK) _runtimeCompatible = NO;
    // Listener tokens/observer registrations intentionally live with the host.
    // They read no payload and cannot create a bubble or a chat action.
    for (NSNotificationName name in @[UIApplicationWillResignActiveNotification,
                                      UIApplicationDidEnterBackgroundNotification,
                                      UIApplicationProtectedDataWillBecomeUnavailable,
                                      UISceneWillDeactivateNotification,
                                      UISceneDidEnterBackgroundNotification,
                                      UISceneDidDisconnectNotification,
                                      UIScreenCapturedDidChangeNotification]) {
        [NSNotificationCenter.defaultCenter addObserverForName:name object:nil queue:NSOperationQueue.mainQueue
            usingBlock:^(__unused NSNotification *notification) { MBInvalidateSpringBoardFoundation(); }];
    }
    [self reloadConfiguration];
}
- (void)reloadConfiguration {
    atomic_store_explicit(&MBObservationEnabled, false, memory_order_release);
    MBInvalidateSpringBoardFoundation();
    if (_reloadPending) { _reloadDirty = YES; return; }
    _reloadPending = YES;
    MBLoadConfiguration(^(MBConfiguration *configuration) {
        self->_reloadPending = NO;
        self.configuration = configuration;
        MBInvalidateSpringBoardFoundation();
        if (self->_reloadDirty) { self->_reloadDirty = NO; [self reloadConfiguration]; return; }
        [self refreshPolicy];
    });
}
- (void)purge {
    MBModelInvalidate(&_model);
    _lastForeground = nil;
    [self.overlay purgeImmediately];
}
- (void)refreshPolicy {
    NSAssert(NSThread.isMainThread, @"Policy must stay on main");
    uint64_t evaluatedEpoch = MBEventGateEpoch(&MBUIGate);
    MBPolicy p = { .enabled = self.configuration.enabled && !_reloadPending && !_reloadDirty,
                   .privacyReviewed = MB_RUNTIME_PRIVACY_REVIEWED,
                   .runtimeCompatible = _runtimeCompatible && MBThreadAndQueuePermit() };
    atomic_store_explicit(&MBObservationEnabled,
        p.enabled && p.privacyReviewed && p.runtimeCompatible, memory_order_release);
    NSString *foreground = nil;
    if (p.enabled && p.privacyReviewed && p.runtimeCompatible) {
        BOOL locked = YES;
        p.lockKnown = MBReadBool(MBLockManager(), NSSelectorFromString(@"isUILocked"), &locked);
        p.locked = locked;
        Class appClass = objc_getClass("SBApplication");
        id application = MBReadObject(UIApplication.sharedApplication, NSSelectorFromString(@"_accessibilityFrontMostApplication"));
        if (appClass && [application isKindOfClass:appClass]) foreground = MBReadBoundedString(application, NSSelectorFromString(@"bundleIdentifier"), 255);
        p.foregroundKnown = foreground != nil;
        p.foregroundAllowed = foreground && [self.configuration.safeApplications containsObject:foreground];
        p.captured = YES;
        NSUInteger activeScenes = 0;
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
            p.captured = ((UIWindowScene *)scene).screen.isCaptured;
            ++activeScenes;
        }
        if (activeScenes != 1) p.foregroundKnown = false;
    }
    BOOL changedForeground = _lastForeground && ![_lastForeground isEqualToString:foreground];
    if (changedForeground || !MBPolicyAllows(p)) {
        MBInvalidateSpringBoardFoundation();
        _lastForeground = [foreground copy];
        return;
    }
    _lastForeground = [foreground copy];
    // Any off-main invalidation during the queries defeats this CAS. Never
    // publish a true permission for a newer generation from a stale snapshot.
    if (!MBThreadAndQueuePermit() || !MBEventGatePublishAllowed(&MBUIGate, evaluatedEpoch)) {
        [self purge];
        return;
    }
    MBModelApplyPolicy(&_model, p);
}
- (void)receiveConversation:(uint64_t)conversation event:(uint64_t)event epoch:(uint64_t)epoch {
    [self refreshPolicy];
    if (!epoch || epoch != MBCurrentIngressEpoch()) return;
    if (MBModelReceive(&_model, _model.epoch, conversation, event)) {
        if (![self.overlay renderModel:&_model]) MBInvalidateSpringBoardFoundation();
    }
}
@end

void MBStartSpringBoardFoundation(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        if (!NSThread.isMainThread || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
        MBCoordinator = [MBSpringBoardCoordinator new];
        [MBCoordinator start];
    });
}
