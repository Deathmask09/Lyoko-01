// SPDX-License-Identifier: MIT
#include "MBModel.h"
#include <math.h>
#include <string.h>

bool MBPolicyAllows(MBPolicy p) {
    return p.enabled && p.privacyReviewed && p.runtimeCompatible &&
        p.lockKnown && !p.locked && p.foregroundKnown &&
        p.foregroundAllowed && !p.captured;
}

void MBModelInit(MBModel *m) {
    if (!m) return;
    memset(m, 0, sizeof(*m));
    m->epoch = 1;
}

void MBModelInvalidate(MBModel *m) {
    if (!m) return;
    uint64_t epoch = m->epoch == UINT64_MAX ? 1 : m->epoch + 1;
    memset(m, 0, sizeof(*m));
    m->epoch = epoch;
}

void MBModelApplyPolicy(MBModel *m, MBPolicy p) {
    if (!m) return;
    bool allowed = MBPolicyAllows(p);
    if (!allowed && (m->allowed || m->count)) MBModelInvalidate(m);
    m->allowed = allowed;
}

bool MBModelReceive(MBModel *m, uint64_t epoch, uint64_t conversation, uint64_t event) {
    if (!m || !m->allowed || epoch != m->epoch || !conversation || !event) return false;
    for (size_t i = 0; i < MB_RECENT_EVENTS; ++i) {
        if (m->recentEvents[i] == event) return false;
    }
    if (m->clock == UINT64_MAX) {
        MBModelInvalidate(m);
        return false;
    }
    m->recentEvents[m->nextRecent] = event;
    m->nextRecent = (m->nextRecent + 1) % MB_RECENT_EVENTS;
    size_t index = m->count;
    for (size_t i = 0; i < m->count; ++i) {
        if (m->items[i].conversation == conversation) { index = i; break; }
    }
    if (index == m->count) {
        if (m->count < MB_MAX_CONVERSATIONS) {
            ++m->count;
        } else {
            index = 0;
            for (size_t i = 1; i < m->count; ++i) {
                if (m->items[i].recency < m->items[index].recency) index = i;
            }
        }
        m->items[index] = (MBConversation){ .conversation = conversation };
    }
    MBConversation *item = &m->items[index];
    item->recency = ++m->clock;
    if (item->observedUnread < MB_MAX_OBSERVED_UNREAD) ++item->observedUnread;
    return true;
}

bool MBModelDismiss(MBModel *m, uint64_t conversation) {
    if (!m || !conversation) return false;
    for (size_t i = 0; i < m->count; ++i) {
        if (m->items[i].conversation != conversation) continue;
        for (size_t j = i + 1; j < m->count; ++j) m->items[j - 1] = m->items[j];
        m->items[--m->count] = (MBConversation){0};
        // Retain the bounded dedupe ring: republishes still in its 128-event
        // horizon cannot reopen this bubble; older events may be observed again.
        return true;
    }
    return false;
}

unsigned MBModelTotalObservedUnread(const MBModel *m) {
    unsigned total = 0;
    if (m) for (size_t i = 0; i < m->count; ++i) total += m->items[i].observedUnread;
    return total;
}

static double MBClamp(double n, double lo, double hi) { return fmax(lo, fmin(n, hi)); }
static bool MBValidBounds(MBRect r, double radius) {
    return isfinite(r.x) && isfinite(r.y) && isfinite(r.width) &&
        isfinite(r.height) && isfinite(radius) && radius > 0 &&
        r.width >= 2 * radius && r.height >= 2 * radius &&
        isfinite(r.x + r.width) && isfinite(r.y + r.height);
}

bool MBClampCenter(MBRect r, double radius, MBPoint p, MBPoint *out) {
    if (!out || !MBValidBounds(r, radius) || !isfinite(p.x) || !isfinite(p.y)) return false;
    out->x = MBClamp(p.x, r.x + radius, r.x + r.width - radius);
    out->y = MBClamp(p.y, r.y + radius, r.y + r.height - radius);
    return true;
}

bool MBSnapCenter(MBRect r, double radius, MBPoint p, double vx, MBPoint *out) {
    if (!isfinite(vx) || !MBClampCenter(r, radius, p, out)) return false;
    double projected = out->x + MBClamp(vx, -3000, 3000) * 0.12;
    out->x = projected < r.x + r.width * 0.5 ? r.x + radius : r.x + r.width - radius;
    return true;
}

size_t MBRailCenters(MBRect r, double radius, double spacing, MBPoint anchor,
                     size_t requested, MBPoint *out) {
    if (!out || !requested || !MBValidBounds(r, radius) ||
        !isfinite(spacing) || spacing < radius * 2 ||
        !isfinite(anchor.x) || !isfinite(anchor.y)) return 0;
    size_t count = requested > MB_MAX_CONVERSATIONS ? MB_MAX_CONVERSATIONS : requested;
    while (count > 1 && (double)(count - 1) * spacing + 2 * radius > r.height) --count;
    MBPoint first;
    if (!MBSnapCenter(r, radius, anchor, 0, &first)) return 0;
    first.y = MBClamp(first.y, r.y + radius, r.y + r.height - radius - (count - 1) * spacing);
    for (size_t i = 0; i < count; ++i) out[i] = (MBPoint){first.x, first.y + i * spacing};
    return count;
}

bool MBDismissHit(MBPoint p, MBPoint target, double radius) {
    if (!isfinite(p.x) || !isfinite(p.y) || !isfinite(target.x) ||
        !isfinite(target.y) || !isfinite(radius) || radius <= 0) return false;
    return hypot(p.x - target.x, p.y - target.y) <= radius;
}

bool MBRemapAnchor(MBRect previous, MBRect next, double radius, MBPoint anchor, MBPoint *out) {
    MBPoint clamped;
    if (!out || !MBValidBounds(next, radius) || !MBClampCenter(previous, radius, anchor, &clamped)) return false;
    double oldRange = previous.height - 2 * radius;
    double fraction = oldRange > 0 ? (clamped.y - previous.y - radius) / oldRange : 0.5;
    fraction = MBClamp(fraction, 0, 1);
    bool right = clamped.x >= previous.x + previous.width * 0.5;
    MBPoint mapped = {right ? next.x + next.width - radius : next.x + radius,
        next.y + radius + fraction * (next.height - 2 * radius)};
    return MBClampCenter(next, radius, mapped, out);
}

bool MBDismissTargetCenter(MBRect safe, double radius, double inset, MBPoint *out) {
    if (!out || !MBValidBounds(safe, radius) || !isfinite(inset) || inset < 0 ||
        inset > safe.height - 2 * radius) return false;
    MBPoint target = {safe.x + safe.width * 0.5, safe.y + safe.height - radius - inset};
    return MBClampCenter(safe, radius, target, out);
}

bool MBResolveDragAnchor(MBRect safe, double radius, double spacing, size_t index,
                         bool cancelled, MBPoint original, MBPoint dragged, double velocity, MBPoint *out) {
    // A cancellation can carry invalid/stale translation and velocity. Ignore
    // them entirely rather than turning an interruption into a move or close.
    if (cancelled) return MBSnapCenter(safe, radius, original, 0, out);
    if (index >= MB_MAX_CONVERSATIONS || !isfinite(spacing) || spacing < 2 * radius) return false;
    MBPoint first;
    if (!MBClampCenter(safe, radius, dragged, &first)) return false;
    first.y -= (double)index * spacing;
    return MBSnapCenter(safe, radius, first, velocity, out);
}
