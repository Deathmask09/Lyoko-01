// SPDX-License-Identifier: MIT
#import "MBNotificationAdapter.h"
#import "MBRuntime.h"
#import "MBSpringBoardCoordinator.h"
#import <CommonCrypto/CommonDigest.h>
#import <substrate.h>
#include <stdatomic.h>
#include <string.h>

static void (*MBOriginalPublish)(id, SEL, id, NSUInteger);
static atomic_uint MBPendingBulletins;

static uint64_t MBDigest(NSString *domain, NSString *thread, NSString *identifier) {
    static NSData *salt;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        unsigned char bytes[32];
        arc4random_buf(bytes, sizeof(bytes));
        salt = [NSData dataWithBytes:bytes length:sizeof(bytes)];
        memset(bytes, 0, sizeof(bytes));
    });
    NSMutableData *data = [salt mutableCopy];
    for (NSString *part in @[domain, thread, identifier]) {
        NSData *encoded = [part dataUsingEncoding:NSUTF8StringEncoding];
        if (!encoded || encoded.length > 4096) return 0;
        uint32_t length = (uint32_t)encoded.length;
        [data appendBytes:&length length:sizeof(length)];
        [data appendData:encoded];
    }
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    uint64_t result = 0;
    memcpy(&result, digest, sizeof(result));
    // Salt never leaves this process. The transient input is never logged,
    // persisted, sent over IPC or used as a database/filesystem lookup.
    if (data.length) memset(data.mutableBytes, 0, data.length);
    return result;
}

static void MBObserveBulletin(id bulletin) {
    uint64_t epoch = MBCaptureBulletinEpoch();
    if (!epoch) return;
    unsigned pending = atomic_fetch_add_explicit(&MBPendingBulletins, 1, memory_order_relaxed);
    if (pending >= 32) {
        atomic_fetch_sub_explicit(&MBPendingBulletins, 1, memory_order_relaxed);
        return;
    }
    BOOL queued = NO;
    @try {
        @autoreleasepool {
            Class bulletinClass = objc_getClass("BBBulletin");
            NSString *section = nil, *thread = nil, *identifier = nil;
            if (bulletinClass && [bulletin isKindOfClass:bulletinClass]) {
                section = MBReadBoundedString(bulletin, NSSelectorFromString(@"sectionID"), 255);
                if ([section isEqualToString:@"com.facebook.Messenger"]) {
                    thread = MBReadBoundedString(bulletin, NSSelectorFromString(@"threadID"), 512);
                    identifier = MBReadBoundedString(bulletin, NSSelectorFromString(@"bulletinID"), 512);
                }
            }
            if (!thread || !identifier) return; // No title/context/payload heuristic.
            uint64_t conversation = MBDigest(@"conversation", thread, @"");
            uint64_t event = MBDigest(@"event", thread, identifier);
            dispatch_async(dispatch_get_main_queue(), ^{
                @try { MBSubmitBulletinDigests(conversation, event, epoch); }
                @catch (__unused NSException *exception) { MBInvalidateSpringBoardFoundation(); }
                @finally { atomic_fetch_sub_explicit(&MBPendingBulletins, 1, memory_order_relaxed); }
            });
            queued = YES;
        }
    } @finally {
        if (!queued) atomic_fetch_sub_explicit(&MBPendingBulletins, 1, memory_order_relaxed);
    }
}

static void MBHookPublish(id self, SEL cmd, id bulletin, NSUInteger destinations) {
    if (MBOriginalPublish) MBOriginalPublish(self, cmd, bulletin, destinations);
    // Never change/suppress the original notification or its destination mask.
    @try { MBObserveBulletin(bulletin); }
    @catch (__unused NSException *exception) { MBInvalidateSpringBoardFoundation(); }
}

BOOL MBInstallNotificationAdapter(void) {
    if (!MB_RUNTIME_PRIVACY_REVIEWED) return NO;
    Class cls = objc_getClass("BBServer");
    SEL selector = NSSelectorFromString(@"publishBulletin:destinations:");
    const char *arguments[] = {"@", @encode(NSUInteger)};
    if (!MBMethodMatches(cls, selector, "v", 2, arguments)) return NO;
    MSHookMessageEx(cls, selector, (IMP)MBHookPublish, (IMP *)&MBOriginalPublish);
    return MBOriginalPublish != NULL;
}
