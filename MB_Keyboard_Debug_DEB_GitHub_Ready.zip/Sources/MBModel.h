// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define MB_MAX_CONVERSATIONS 4u
#define MB_RECENT_EVENTS 128u
#define MB_MAX_OBSERVED_UNREAD 999u

typedef struct {
    bool enabled;
    bool privacyReviewed;
    bool runtimeCompatible;
    bool lockKnown;
    bool locked;
    bool foregroundKnown;
    bool foregroundAllowed;
    bool captured;
} MBPolicy;

typedef struct {
    uint64_t conversation; // Per-launch salted digest, never a raw thread ID.
    uint64_t recency;
    uint16_t observedUnread; // Observed bulletins, NOT Messenger's server count.
} MBConversation;

typedef struct {
    MBConversation items[MB_MAX_CONVERSATIONS];
    uint64_t recentEvents[MB_RECENT_EVENTS];
    uint64_t epoch;
    uint64_t clock;
    size_t count;
    size_t nextRecent;
    bool allowed;
} MBModel;

bool MBPolicyAllows(MBPolicy policy);
void MBModelInit(MBModel *model);
void MBModelInvalidate(MBModel *model);
void MBModelApplyPolicy(MBModel *model, MBPolicy policy);
bool MBModelReceive(MBModel *model, uint64_t epoch,
                    uint64_t conversation, uint64_t event);
bool MBModelDismiss(MBModel *model, uint64_t conversation);
unsigned MBModelTotalObservedUnread(const MBModel *model);

typedef struct { double x, y; } MBPoint;
typedef struct { double x, y, width, height; } MBRect;
bool MBClampCenter(MBRect safe, double radius, MBPoint point, MBPoint *result);
bool MBSnapCenter(MBRect safe, double radius, MBPoint point,
                  double velocityX, MBPoint *result);
size_t MBRailCenters(MBRect safe, double radius, double spacing,
                     MBPoint anchor, size_t requested, MBPoint *centers);
bool MBDismissHit(MBPoint point, MBPoint target, double radius);

// Geometry used by the real overlay: preserve dock side and relative height
// across safe-area/rotation changes; no persistence or conversation identifiers.
bool MBRemapAnchor(MBRect previousSafe, MBRect nextSafe, double radius,
                   MBPoint anchor, MBPoint *result);
// A close target is only interactive when the whole target plus bottom inset fits.
bool MBDismissTargetCenter(MBRect safe, double radius, double bottomInset,
                           MBPoint *result);
// Cancel/failed recognizers restore the original anchor, never dismiss or fling.
// On release, convert a dragged rail member back to the first rail anchor.
bool MBResolveDragAnchor(MBRect safe, double radius, double spacing, size_t railIndex,
                         bool cancelled, MBPoint originalAnchor, MBPoint draggedCenter,
                         double velocityX, MBPoint *result);
