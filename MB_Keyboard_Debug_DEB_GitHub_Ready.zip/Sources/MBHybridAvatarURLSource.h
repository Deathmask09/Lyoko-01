// SPDX-License-Identifier: MIT
#pragma once
#import "MBHybridAvatarCache.h"
#include <stdint.h>

NS_ASSUME_NONNULL_BEGIN
/// A real image source for MBHybridAvatarCache. Main-queue lifetime/API only.
/// The caller MUST have verified the account + user/group ID -> CDN reference
/// association. This class does not guess an ID, query Graph, inspect a payload,
/// open a DB or assert that a thread ID is a user ID.
/// Main-only; HTTPS fbcdn.net/fbsbx.com references only, never redirects/credentials.
/// At most 16 admitted requests/decode jobs; at capacity no callback is retained.
/// Encoded response <= 1 MiB, source dimensions <= 4096, static output <= 512px;
/// decoding is off-main. No URLCache, cookies, credentials, files or logging.
/// Lease gates new network loads, not pixel freshness in the separate RAM cache.
/// Call register again before binding; rotate revision when the source changes.
@interface MBHybridAvatarURLSource : NSObject <MBHybridAvatarSource>
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
- (nullable instancetype)initWithAccountID:(NSString *)accountID;
/// An ephemeral copy is enforced; protocolClasses may inject an offline fixture.
- (nullable instancetype)initWithAccountID:(NSString *)accountID
                           configuration:(NSURLSessionConfiguration *)configuration NS_DESIGNATED_INITIALIZER;
/// Returns an opaque cache/binding key, not a URL. Preserve IDs as exact strings.
/// revision must increase for each subject's reference changes; 0 is rejected.
/// lifetime is a local reference lease, 0 < seconds <= 300, not CDN expiry proof.
/// Same revision cannot replace a URL or extend its original lease.
/// At most 64 distinct subjects are registered until purge; missing/expired/
/// ambiguous input returns nil, never another user's picture or an app icon.
- (nullable NSString *)registerUserID:(NSString *)userID reference:(NSString *)reference
                            revision:(uint64_t)revision lifetime:(NSTimeInterval)seconds;
- (nullable NSString *)registerGroupID:(NSString *)groupID reference:(NSString *)reference
                             revision:(uint64_t)revision lifetime:(NSTimeInterval)seconds;
/// Cancel requests, drop references, invalidate queued deliveries. Call together
/// with cache.purge on OFF/logout/account switch. A new account needs a new source.
- (void)purge;
@end
NS_ASSUME_NONNULL_END
