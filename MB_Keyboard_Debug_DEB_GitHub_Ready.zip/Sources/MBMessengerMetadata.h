// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#include <sqlite3.h>
#include <stdint.h>

NS_ASSUME_NONNULL_BEGIN
// Metadata only, no image download or automatic conversion to Hybrid events.
@interface MBMessengerCryptoThreadMetadata : NSObject
@property(nonatomic, readonly, copy) NSString *accountID;
@property(nonatomic, readonly, copy) NSString *modelID; // Account + transport namespace.
@property(nonatomic, readonly, copy) NSString *transportThreadID; // Exact string; not a navigation contract.
@property(nonatomic, readonly) int64_t clientPK;
@property(nonatomic, readonly) int64_t localThreadKey; // Signed; can be negative or exceed JS's exact integer range.
@property(nonatomic, readonly) BOOL groupThread;
@property(nonatomic, readonly) int64_t observedUnread; // -1 = absent/invalid. NOT proof of freshness/authoritative live updates.
@property(nonatomic, readonly, copy, nullable) NSString *avatarReference;
@property(nonatomic, readonly, copy, nullable) NSString *avatarFallbackReference;
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
@end

// Caller owns an EXCLUSIVE-TO-THIS-WORKER, read-only SQLite handle already in a
// coherent read transaction for the verified Messenger version/account. Never
// pass Messenger's shared app connection; never assert immutable on a live file
// and then label this result live/authoritative. No file open, hook, pragma,
// transaction, callback replacement, logging or other database is touched here.
// Off main only. Missing/ambiguous mapping fails closed. No fallback to FBIDs.
FOUNDATION_EXPORT MBMessengerCryptoThreadMetadata * _Nullable MBMessengerReadCryptoThreadMetadata(
    sqlite3 *readOnlySnapshot, NSString *accountID, NSString *transportThreadID,
    NSError * _Nullable * _Nullable error);
NS_ASSUME_NONNULL_END
