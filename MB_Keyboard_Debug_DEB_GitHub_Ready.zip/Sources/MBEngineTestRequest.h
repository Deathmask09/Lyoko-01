// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#import "MBEnginePolicy.h"

#define MB_ENGINE_TEST_REQUEST_KEY @"DebugBubbleTestRequest"
#define MB_ENGINE_TEST_STATUS_KEY @"DebugBubbleTestStatus"
#define MB_ENGINE_TEST_REQUEST_CHANGED APELIN_PACKAGE_ID "/debug-test-request-changed"
#define MB_ENGINE_TEST_RESULT_CHANGED APELIN_PACKAGE_ID "/debug-test-result-changed"

// Inputs below must be stable scalar values with no side effects. The request
// nonce/timestamp must already pass MBEngineDebugTestNonce. Consume BEFORE gates
// so a request rejected by OFF/lock/capture cannot replay when those gates reopen.
#define MB_ENGINE_TEST_NEW_INTENT(stamp, consumedAt, nonceDifferent) \
    ((stamp) > (consumedAt) && (nonceDifferent))
#define MB_ENGINE_TEST_ALLOWED(epoch, currentEpoch, ready, enabled, settingsFront, unlocked, captureKnown, captured) \
    ((epoch) == (currentEpoch) && (ready) && (enabled) && (settingsFront) && \
     (unlocked) && (captureKnown) && !(captured))

// Darwin is only an unauthenticated hint to reread this domain. The foreground
// check is an intent guard, not peer authentication; no sender/audit token claim.

// Data validation only; never schedules work, reads settings or opens UI.
// notBefore is this SpringBoard session's start: requests never survive a restart.
FOUNDATION_EXPORT NSString * _Nullable MBEngineDebugTestNonce(id _Nullable request,
    NSTimeInterval now, NSTimeInterval notBefore);
