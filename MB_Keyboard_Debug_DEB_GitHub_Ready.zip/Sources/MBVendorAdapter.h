// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
FOUNDATION_EXPORT void MBStartVendorAdapter(void);
