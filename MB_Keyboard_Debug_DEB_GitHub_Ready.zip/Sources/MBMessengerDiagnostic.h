// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#import "MBMessengerCompatibility.h"
#include <limits.h>
#include <stdatomic.h>

// Transient process metadata only. Paths stay in evaluation; reports/logs contain none.
// These are trusted test seams, not a public control/IPC surface.
typedef NS_ENUM(NSUInteger, MBMessengerLoadedImageState) {
    MBMessengerImageUnknown = 0,
    MBMessengerImageLoaded,
    MBMessengerImageAbsent,
    MBMessengerImageLimit,
};
typedef struct {
    char bundleIdentifier[96], version[32], build[32], packageType[8], executableName[64];
    char bundlePath[PATH_MAX], bundleExecutable[PATH_MAX], mainExecutable[PATH_MAX], coreImagePath[PATH_MAX];
    BOOL isExtension, mainIsExecutable;
    MBMessengerLoadedImageState coreImageState;
    const void *coreImageHeader;
} MBMessengerProcessFacts;

typedef struct {
    MBMessengerMetadataResult metadata;
    char version[32], build[32]; // bounded numeric metadata, or a fixed "unknown"/"invalid"
} MBMessengerDiagnosticReport;

typedef BOOL (*MBMessengerFactCollector)(MBMessengerProcessFacts *facts, void *context);
typedef void (*MBMessengerDiagnosticSink)(const MBMessengerDiagnosticReport *report, void *context);
typedef void (*MBMessengerDiagnosticEnqueue)(dispatch_block_t work, void *context);
typedef struct {
    MBMessengerFactCollector collect;
    MBMessengerMetadataClassLookup lookup; // NULL: objc_lookUpClass, no image loading
    MBMessengerMetadataOriginVerifier origin; // NULL: real class/IMP origin verification
    MBMessengerDiagnosticSink sink;
    MBMessengerDiagnosticEnqueue enqueue;
    void *context; // trusted fixtures must keep this and their state alive through completion
} MBMessengerDiagnosticDependencies;
typedef struct { atomic_uint phase; } MBMessengerDiagnosticOnce;
#define MB_MESSENGER_DIAGNOSTIC_ONCE_INIT { .phase = ATOMIC_VAR_INIT(0) }

// Actual collector ignores context: NSBundle.mainBundle + already loaded dyld images.
FOUNDATION_EXPORT BOOL MBCollectMessengerProcessFacts(MBMessengerProcessFacts *facts, void *context);
FOUNDATION_EXPORT MBMessengerMetadataStatus MBVerifyMessengerLoadedOrigin(
    void *classHandle, Method ownedMethod, const char *relativeImage, const MBMessengerProcessFacts *facts);
FOUNDATION_EXPORT MBMessengerDiagnosticReport MBEvaluateMessengerDiagnostic(MBMessengerDiagnosticDependencies dependencies);
// CAS before enqueue: at most one attempt, including recursive/duplicate callbacks.
FOUNDATION_EXPORT BOOL MBQueueMessengerDiagnostic(MBMessengerDiagnosticOnce *once, MBMessengerDiagnosticDependencies dependencies);
FOUNDATION_EXPORT const char *MBMessengerDiagnosticReason(MBMessengerMetadataStatus status);
FOUNDATION_EXPORT const char *MBMessengerDiagnosticDisposition(MBMessengerMetadataStatus status);

// Only this entry is wired to public UIKit lifecycle. No injectable caller facts.
// Never opens a policy gate, calls a candidate, polls or exports a Darwin control.
FOUNDATION_EXPORT void MBStartPassiveMessengerDiagnostic(void);
