// SPDX-License-Identifier: MIT
#pragma once
#import "MBSceneHostDiagnostic.h"
#include <pthread.h>

// Read-only, unauthenticated diagnostic signal. No payload/state, scene action,
// preference change or policy decision. Another sender can consume the quota.
#define MB_SCENE_READOUT_NOTIFICATION APELIN_PACKAGE_ID "/diagnostic/scene-readout-once"
#define MB_SCENE_READOUT_EXTRA_LINE_MAX (1u + 1u + MB_SCENE_HOST_CATALOG_MAX + 2u)
#define MB_SCENE_READOUT_TOTAL_LINE_MAX (MB_SCENE_HOST_LOG_LINE_MAX + MB_SCENE_READOUT_EXTRA_LINE_MAX)

typedef NS_OPTIONS(unsigned, MBSceneBootstrapFlags) {
    MBSceneBootstrapScheduled = 1u << 0, MBSceneBootstrapEntered = 1u << 1,
    MBSceneBootstrapArmed = 1u << 2, MBSceneBootstrapDelivered = 1u << 3,
    MBSceneBootstrapFailed = 1u << 4,
};
typedef NS_OPTIONS(unsigned, MBSceneLaunchHookFlags) {
    MBSceneLaunchHookChecked = 1u << 0, MBSceneLaunchHookInstalled = 1u << 1,
    MBSceneLaunchHookCalled = 1u << 2,
};
typedef struct {
    unsigned bootstrapFlags, hookFlags, progressFlags;
    MBSceneHostDiagnosticTrigger acceptedTrigger;
    BOOL reportStored, requestClaimed, replayClaimed;
} MBSceneReadoutSnapshot;
typedef void (*MBSceneReadoutStatusSink)(const MBSceneReadoutSnapshot *, void *);
typedef struct {
    MBSceneReadoutStatusSink statusSink;
    MBSceneHostDiagnosticSink reportSink;
    void *context;
} MBSceneReadoutDependencies;
typedef struct {
    pthread_mutex_t lock;
    MBSceneReadoutSnapshot snapshot;
    MBSceneHostDiagnosticReport report;
    MBSceneReadoutDependencies pending;
} MBSceneReadoutState;
#define MB_SCENE_READOUT_STATE_INIT { .lock = PTHREAD_MUTEX_INITIALIZER }

// Trusted offline seams, not an IPC schema. State must not be copied after
// initialization. State/context/sinks stay alive through ALL callers/callbacks;
// flags are point-in-time evidence, not a join/ACK/order or callback-lifetime fence.
// Input reports remain immutable and valid for each synchronous store call.
// No sink runs under the lock. Throwing sinks consume their quota, without retry.
FOUNDATION_EXPORT void MBSceneReadoutNoteBootstrap(MBSceneReadoutState *, unsigned flags);
FOUNDATION_EXPORT void MBSceneReadoutNoteHook(MBSceneReadoutState *, unsigned flags);
FOUNDATION_EXPORT void MBSceneReadoutNoteProgress(MBSceneReadoutState *, MBSceneHostDiagnosticStage,
    MBSceneHostDiagnosticTrigger);
FOUNDATION_EXPORT MBSceneReadoutSnapshot MBSceneReadoutCopySnapshot(MBSceneReadoutState *);
FOUNDATION_EXPORT BOOL MBSceneReadoutStoreReport(MBSceneReadoutState *, const MBSceneHostDiagnosticReport *);
// Requires both sinks. First request emits one snapshot, then one report if/when
// retained. It never collects again. Concurrent/reentrant sinks may be unordered.
FOUNDATION_EXPORT BOOL MBSceneReadoutRequest(MBSceneReadoutState *, MBSceneReadoutDependencies);

// Production owns static storage; constructor notes use only a short C mutex.
FOUNDATION_EXPORT void MBRecordSceneBootstrap(unsigned flags);
FOUNDATION_EXPORT void MBRecordSceneLaunchHook(unsigned flags);
FOUNDATION_EXPORT void MBRecordSceneDiagnosticProgress(MBSceneHostDiagnosticStage, MBSceneHostDiagnosticTrigger);
FOUNDATION_EXPORT void MBRetainSceneDiagnosticReport(const MBSceneHostDiagnosticReport *);
// Registration is deferred independently of main/bootstrap; only exact SB calls
// this. One listener/process, canceled at first request, no timer or retry.
FOUNDATION_EXPORT void MBInstallSceneDiagnosticReadout(void);
