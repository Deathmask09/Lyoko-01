// SPDX-License-Identifier: MIT
#pragma once
#include <stdbool.h>
#include <math.h>

// Circle drawing plus a fixed visual enlargement for the SHA-pinned engine.
// Its placement method resets bounds to 44 pt on every call. Multiply that
// method's extraScale, never the current view transform: no layout accumulation.
// 65 pt diameter is approximately 10.8 mm on the target display (460 ppi, @3x).
#define MB_ENGINE_ICON_BASE_DIAMETER 44.0
#define MB_ENGINE_ICON_EXTRA_DIAMETER 21.0
static inline bool MBEngineLargerIconScale(double engineScale, double *out) {
    if (!out || !isfinite(engineScale) || engineScale < 0 || engineScale > 4) return false;
    *out = engineScale * ((MB_ENGINE_ICON_BASE_DIAMETER + MB_ENGINE_ICON_EXTRA_DIAMETER) /
                          MB_ENGINE_ICON_BASE_DIAMETER);
    return true;
}
// Panel uses the current chrome's own coordinate space (portrait/landscape).
// Reject unknown/degenerate bounds rather than inventing a screen geometry.
static inline bool MBEnginePanelBoundsValid(double x, double y, double width, double height) {
    return isfinite(x) && isfinite(y) && fabs(x) <= 4096 && fabs(y) <= 4096 &&
        isfinite(width) && isfinite(height) && width >= 1 && height >= 1 &&
        width <= 4096 && height <= 4096;
}
typedef struct { double x, y, width, height; } MBEnginePanelRect;
// Reference image supplied in the keyboard conversation on 18 November:
// centered floating outline, approximately 10% margins on all four sides.
// This is outer chrome geometry only; it does not fix remote keyboard hosting.
#define MB_ENGINE_PANEL_WIDTH_FRACTION 0.80
#define MB_ENGINE_PANEL_HEIGHT_FRACTION 0.80
// JPEG edge fits put the sample's bottom-corner radius at about 15% of its
// short edge (not a fixed device-point radius or a maximum/pill corner).
#define MB_ENGINE_PANEL_CORNER_FRACTION 0.15
static inline bool MBEngineFloatingPanelInBounds(double x, double y, double width, double height,
                                                 MBEnginePanelRect *out) {
    if (!out || !MBEnginePanelBoundsValid(x, y, width, height)) return false;
    double panelWidth = width * MB_ENGINE_PANEL_WIDTH_FRACTION;
    double panelHeight = height * MB_ENGINE_PANEL_HEIGHT_FRACTION;
    *out = (MBEnginePanelRect){x + (width - panelWidth) / 2,
                              y + (height - panelHeight) / 2, panelWidth, panelHeight};
    return true;
}
static inline bool MBEnginePanelCornerRadius(double width, double height, double *out) {
    if (!out || !isfinite(width) || !isfinite(height) ||
        width <= 0 || height <= 0 || width > 4096 || height > 4096) return false;
    *out = fmin(width, height) * MB_ENGINE_PANEL_CORNER_FRACTION;
    return true;
}
typedef struct { double width, height; } MBEngineNativeSize;
// The engine rotates a portrait-native scene into the chrome's current space.
// Request this native size, rather than stretching a full-phone scene/keyboard.
static inline bool MBEnginePanelNativeSize(double width, double height, long orientation,
                                           MBEngineNativeSize *out) {
    if (!out || !MBEnginePanelBoundsValid(0, 0, width, height) ||
        orientation < 1 || orientation > 4) return false;
    *out = (orientation == 3 || orientation == 4) ?
        (MBEngineNativeSize){height, width} : (MBEngineNativeSize){width, height};
    return true;
}
typedef struct { double x, y, diameter; } MBEngineCircle;
static inline bool MBEngineCircleInBounds(double width, double height, MBEngineCircle *out) {
    if (!out || !isfinite(width) || !isfinite(height) || width <= 0 || height <= 0 ||
        width > 1024 || height > 1024) return false;
    double diameter = fmin(width, height);
    *out = (MBEngineCircle){(width - diameter) / 2, (height - diameter) / 2, diameter};
    return true;
}
