// SPDX-License-Identifier: MIT
#import "MBHybridMetadataObserver.h"
#import "MBHybridSchema.h"
#import "MBRuntime.h"
#import <CoreFoundation/CoreFoundation.h>
#import <substrate.h>
#import <notify.h>
#import <os/log.h>
#import <os/lock.h>
#include <stdatomic.h>
#include <string.h>

#if defined(APELIN_CONFIGURATION_DEBUG)
static atomic_uint MBShapeClaimed;
static _Atomic(bool) MBShapeMessengerEnabled;
static os_unfair_lock MBShapeLock = OS_UNFAIR_LOCK_INIT;
static MBHybridShape MBShapeCache[3];
static uint8_t MBShapeBulletinThread[3];
static BOOL MBShapeHasCache[3];
static os_log_t MBShapeLog(void) {
    static os_log_t log; static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "hybrid-schema"); });
    return log;
}
static const char *MBShapeSource(unsigned source) {
    static const char *const names[] = {"sb-bulletin", "messenger-message", "messenger-count"};
    return source < 3 ? names[source] : "invalid";
}
static void MBShapeEmit(unsigned source, MBHybridShape shape, uint8_t threadKind, BOOL replay) {
    os_log(MBShapeLog(), "MBHybridSchema build=%{public}s source=%{public}s replay=%d root=%u dictionaries=%u truncated=%u exception=%u bulletin_thread_kind=%u",
        APELIN_BUILD_ID, MBShapeSource(source), replay, shape.rootKind, shape.dictionaries, shape.truncated, shape.exception, threadKind);
    for (unsigned field = 0; field < MBHybridShapeFieldCount; ++field) {
        MBHybridShapeHit hit = shape.fields[field];
        if (!hit.key) continue;
        os_log(MBShapeLog(), "MBHybridSchemaField build=%{public}s source=%{public}s field=%{public}s key=%{public}s container=%{public}s kind=%u",
            APELIN_BUILD_ID, MBShapeSource(source), MBHybridShapeFieldName(field), MBHybridShapeKeyName(hit.key),
            MBHybridShapeContainerName(hit.container), hit.kind);
    }
}
static BOOL MBShapeClaim(unsigned source) {
    return source < 3 && !(atomic_fetch_or(&MBShapeClaimed, 1u << source) & (1u << source));
}
static void MBShapeStore(unsigned source, MBHybridShape shape, uint8_t threadKind) {
    os_unfair_lock_lock(&MBShapeLock);
    MBShapeCache[source] = shape; MBShapeBulletinThread[source] = threadKind; MBShapeHasCache[source] = YES;
    os_unfair_lock_unlock(&MBShapeLock);
    MBShapeEmit(source, shape, threadKind, NO);
}
static void MBShapeReplay(void) {
    static unsigned remaining = 4; // Main queue; never rearms collection or opens UI.
    if (!remaining) return;
    --remaining;
    MBHybridShape shapes[3]; uint8_t kinds[3]; BOOL available[3];
    os_unfair_lock_lock(&MBShapeLock);
    memcpy(shapes, MBShapeCache, sizeof(shapes)); memcpy(kinds, MBShapeBulletinThread, sizeof(kinds));
    memcpy(available, MBShapeHasCache, sizeof(available));
    os_unfair_lock_unlock(&MBShapeLock);
    BOOL messenger = [NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.facebook.Messenger"];
    for (unsigned source = 0; source < 3; ++source) {
        if (messenger != (source > 0)) continue;
        if (available[source]) MBShapeEmit(source, shapes[source], kinds[source], YES);
        else os_log(MBShapeLog(), "MBHybridSchemaPending build=%{public}s source=%{public}s", APELIN_BUILD_ID, MBShapeSource(source));
    }
}
static void (*MBShapeOriginalMessage)(id, SEL, id);
static void (*MBShapeOriginalCount)(id, SEL, id);
static void MBShapeMessage(id self, SEL cmd, id payload) {
    MBShapeOriginalMessage(self, cmd, payload); // Chain unchanged BEFORE observation.
    if (atomic_load(&MBShapeMessengerEnabled) && MBShapeClaim(1)) MBShapeStore(1, MBHybridInspectShape(payload), 0);
}
static void MBShapeCount(id self, SEL cmd, id payload) {
    MBShapeOriginalCount(self, cmd, payload);
    if (atomic_load(&MBShapeMessengerEnabled) && MBShapeClaim(2)) MBShapeStore(2, MBHybridInspectShape(payload), 0);
}
static void MBShapeReadSetting(void) {
    static dispatch_queue_t queue; static unsigned generation;
    if (!queue) queue = dispatch_queue_create("com.lyoko-01.messengerbubbles.hybrid-schema-settings", DISPATCH_QUEUE_SERIAL);
    unsigned request = ++generation;
    atomic_store(&MBShapeMessengerEnabled, false);
    dispatch_async(queue, ^{
        BOOL enabled = NO;
        if (CFPreferencesAppSynchronize(CFSTR(APELIN_PACKAGE_ID))) {
            CFPropertyListRef value = CFPreferencesCopyAppValue(CFSTR("EngineEnabled"), CFSTR(APELIN_PACKAGE_ID));
            enabled = value && CFGetTypeID(value) == CFBooleanGetTypeID() && CFBooleanGetValue((CFBooleanRef)value);
            if (value) CFRelease(value);
        }
        dispatch_async(dispatch_get_main_queue(), ^{ if (request == generation) atomic_store(&MBShapeMessengerEnabled, enabled); });
    });
}
#endif

void MBStartHybridMetadataObserver(void) {
#if defined(APELIN_CONFIGURATION_DEBUG)
    if (!NSThread.isMainThread) return;
    NSString *bundle = NSBundle.mainBundle.bundleIdentifier;
    BOOL messenger = [bundle isEqualToString:@"com.facebook.Messenger"];
    if (!messenger && ![bundle isEqualToString:@"com.apple.springboard"]) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        int reportToken;
        // Unauthenticated LOG-ONLY hint: fixed schema cache, no identities/values.
        notify_register_dispatch(APELIN_PACKAGE_ID "/hybrid/schema-report", &reportToken, dispatch_get_main_queue(), ^(int token) {
            (void)token; MBShapeReplay();
        });
        if (!messenger) return;
        NSDictionary *info = NSBundle.mainBundle.infoDictionary;
        if (![info[@"CFBundleShortVersionString"] isEqual:@"579.0.0"] || ![info[@"CFBundleVersion"] isEqual:@"1068430635"]) {
            os_log(MBShapeLog(), "MBHybridSchemaUnsupported build=%{public}s reason=version", APELIN_BUILD_ID); return;
        }
        // One attempt: no polling, class loading, private getter calls or router invocation.
        dispatch_async(dispatch_get_main_queue(), ^{
            Class cls = objc_lookUpClass("LSAppDelegate");
            const char *image = cls ? class_getImageName(cls) : NULL;
            BOOL origin = image && [@(image) hasSuffix:@"/Frameworks/LightSpeedCore.framework/LightSpeedCore"];
            const char *args[] = {"@"};
            SEL message = sel_registerName("didReceiveMessageNotificationWithPayload:");
            SEL count = sel_registerName("didReceiveMessageCountNotificationWithPayload:");
            BOOL messageOK = origin && MBMethodMatches(cls, message, "v", 1, args);
            BOOL countOK = origin && MBMethodMatches(cls, count, "v", 1, args);
            if (messageOK) MSHookMessageEx(cls, message, (IMP)MBShapeMessage, (IMP *)&MBShapeOriginalMessage);
            if (countOK) MSHookMessageEx(cls, count, (IMP)MBShapeCount, (IMP *)&MBShapeOriginalCount);
            MBShapeReadSetting();
            int settingToken;
            notify_register_dispatch(APELIN_PACKAGE_ID "/changed", &settingToken, dispatch_get_main_queue(), ^(int token) {
                (void)token; MBShapeReadSetting();
            });
            os_log(MBShapeLog(), "MBHybridSchemaArmed build=%{public}s message=%d count=%d max_samples_per_source=1", APELIN_BUILD_ID,
                MBShapeOriginalMessage != NULL, MBShapeOriginalCount != NULL);
        });
    });
#endif
}
void MBHybridObserveBulletin(id bulletin, BOOL allowed) {
#if defined(APELIN_CONFIGURATION_DEBUG)
    if (!allowed || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"] || !MBShapeClaim(0)) return;
    @try {
        // Caller already checked exact Messenger section, date and bulletin identity.
        // Context is traversed only via MBHybridSchema's fixed field/container keys.
        id thread = MBReadObject(bulletin, sel_registerName("threadID"));
        id context = MBReadObject(bulletin, sel_registerName("context"));
        MBShapeStore(0, MBHybridInspectShape(context), MBHybridValueKind(thread));
    } @catch (__unused NSException *exception) {
        MBHybridShape shape = {0}; shape.exception = 1; MBShapeStore(0, shape, 0);
    }
#else
    (void)bulletin; (void)allowed;
#endif
}
