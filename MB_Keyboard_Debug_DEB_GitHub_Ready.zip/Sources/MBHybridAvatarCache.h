// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// All public methods, task cancellation and cache lifetime belong to the main queue.
@protocol MBHybridAvatarTask <NSObject>
- (void)cancel;
@end

typedef void (^MBHybridAvatarReply)(UIImage * _Nullable image);

/// Keys are opaque, provider-verified identifiers, never interpreted as URLs or paths.
/// The source may reply synchronously or on any queue. A nil task is also supported.
@protocol MBHybridAvatarSource <NSObject>
- (id<MBHybridAvatarTask> _Nullable)loadAvatarForKey:(NSString *)key
                                      completion:(MBHybridAvatarReply)completion;
@end

@interface MBHybridAvatarCache : NSObject
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)initWithSource:(id<MBHybridAvatarSource>)source
                    costLimit:(NSUInteger)bytes
                   maxEntries:(NSUInteger)entries NS_DESIGNATED_INITIALIZER;

/// Accepted subscribers receive at most one reply, always asynchronously on main.
/// nil means invalid input/image, load-slot exhaustion, failure, timeout or eviction
/// before delivery. Keys must be NSStrings of 1...512 UTF-16 code units.
///
/// At most 16 distinct loads and 64 subscribers (including queued hit/failure
/// deliveries) are retained. At subscriber capacity, or during purge, the returned
/// task is already cancelled and completion is NOT retained or called. Cancel and
/// purge also suppress callbacks, including queued cache hits. No waiting-load queue.
///
/// Resident pixels use a hard LRU byte/entry budget, not NSCache's soft limits.
/// Only static CGImages up to 512x512 are accepted, checked for stride overflow and
/// decoded into owned RGBA8 rasters. Images exceeding either input/output byte
/// budget are rejected. A zero byte or entry budget disables requests (async nil).
/// Queued deliveries do not pin evicted images. Provider/client-owned images and
/// transient decode buffers are outside the resident-cache budget.
- (id<MBHybridAvatarTask>)requestKey:(NSString *)key
                        completion:(MBHybridAvatarReply)completion;

/// Cancels all source tasks/subscribers, clears decoded RAM and suppresses late
/// replies. Also performed on UIApplicationDidReceiveMemoryWarningNotification.
/// Each load has a cancellable, one-shot 10-second deadline; there is no polling.
- (void)purge;
@end

NS_ASSUME_NONNULL_END
