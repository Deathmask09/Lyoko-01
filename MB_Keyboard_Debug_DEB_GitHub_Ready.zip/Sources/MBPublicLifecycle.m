// SPDX-License-Identifier: MIT
#import "MBPublicLifecycle.h"
#include <stdatomic.h>

@interface MBPublicLifecycle () {
    atomic_uint _state;
    atomic_uint _source;
    NSNotificationCenter *_center;
    NSNotificationName _launchName, _activeName;
    id _launchToken, _activeToken;
    BOOL (^_isActive)(void);
    MBLifecycleMainEnqueue _enqueueMain;
    void (^_handler)(MBLifecycleSource);
}
- (void)receive:(MBLifecycleSource)source;
- (void)scheduleIfArmed;
- (void)deliver;
- (void)removeObservers;
@end

@implementation MBPublicLifecycle
- (instancetype)initWithCenter:(NSNotificationCenter *)center
            launchNotification:(NSNotificationName)launch
            activeNotification:(NSNotificationName)active
                      isActive:(BOOL (^)(void))isActive
                   enqueueMain:(MBLifecycleMainEnqueue)enqueueMain
                       handler:(void (^)(MBLifecycleSource))handler {
    if (!center || !launch.length || !active.length || [launch isEqualToString:active] ||
        !isActive || !enqueueMain || !handler) return nil;
    self = [super init];
    if (self) {
        atomic_init(&_state, MBLifecycleStateNew);
        atomic_init(&_source, MBLifecycleSourceNone);
        _center = center;
        _launchName = [launch copy]; _activeName = [active copy];
        _isActive = [isActive copy]; _enqueueMain = [enqueueMain copy]; _handler = [handler copy];
    }
    return self;
}
- (MBLifecycleState)state { return (MBLifecycleState)atomic_load(&_state); }
- (MBLifecycleSource)source { return (MBLifecycleSource)atomic_load(&_source); }
- (BOOL)start {
    if (!NSThread.isMainThread) return NO;
    unsigned expected = MBLifecycleStateNew;
    if (!atomic_compare_exchange_strong(&_state, &expected, MBLifecycleStateRegistering)) return NO;
    __weak MBPublicLifecycle *weakSelf = self;
    @try {
        // queue:nil never blocks an off-main poster waiting for the main queue.
        // receive only claims a finite enum and schedules bounded main work.
        _launchToken = [_center addObserverForName:_launchName object:nil queue:nil
            usingBlock:^(__unused NSNotification *notification) { [weakSelf receive:MBLifecycleSourceLaunch]; }];
        if (!_launchToken) { [self invalidate]; return NO; }
        if (atomic_load(&_state) != MBLifecycleStateRegistering) {
            [self removeObservers]; return NO;
        }
        _activeToken = [_center addObserverForName:_activeName object:nil queue:nil
            usingBlock:^(__unused NSNotification *notification) { [weakSelf receive:MBLifecycleSourceActive]; }];
        if (!_activeToken) { [self invalidate]; return NO; }
        // Cancellation can be reentrant while a center is registering. A token
        // returned after cancellation must still be removed; never arm again.
        if (atomic_load(&_state) != MBLifecycleStateRegistering) {
            [self removeObservers]; return NO;
        }
        @try {
            if (_isActive()) [self receive:MBLifecycleSourceActiveCatchUp];
        } @catch (__unused NSException *exception) {
            // Unknown readiness does not create an attempt. A real public
            // notification already received (or arriving later) still can.
        }
        expected = MBLifecycleStateRegistering;
        if (!atomic_compare_exchange_strong(&_state, &expected, MBLifecycleStateArmed)) {
            [self removeObservers]; return NO;
        }
        [self scheduleIfArmed];
        return atomic_load(&_state) != MBLifecycleStateInvalidated;
    } @catch (__unused NSException *exception) {
        [self invalidate]; return NO;
    }
}
- (void)receive:(MBLifecycleSource)source {
    unsigned state = atomic_load(&_state);
    if (state != MBLifecycleStateRegistering && state != MBLifecycleStateArmed) return;
    unsigned none = MBLifecycleSourceNone;
    if (!atomic_compare_exchange_strong(&_source, &none, (unsigned)source)) return;
    // The registering->armed handshake covers both interleavings: start sees
    // the claimed source, or receive sees armed and queues it. No lost wakeup.
    [self scheduleIfArmed];
}
- (void)scheduleIfArmed {
    if (atomic_load(&_source) == MBLifecycleSourceNone) return;
    unsigned armed = MBLifecycleStateArmed;
    if (!atomic_compare_exchange_strong(&_state, &armed, MBLifecycleStateQueued)) return;
    __weak MBPublicLifecycle *weakSelf = self;
    @try {
        _enqueueMain(^{ [weakSelf deliver]; });
    } @catch (__unused NSException *exception) {
        // Cancel only work which has not begun. Never clobber a running/finished
        // handler when a test executor schedules work and then throws.
        unsigned queued = MBLifecycleStateQueued;
        atomic_compare_exchange_strong(&_state, &queued, MBLifecycleStateInvalidated);
        // Tokens are main-owned. An off-main enqueue failure leaves at most
        // two inert observers until owner invalidation/deallocation; no retry.
        if (NSThread.isMainThread && self.state == MBLifecycleStateInvalidated) [self removeObservers];
    }
}
- (void)deliver {
    if (!NSThread.isMainThread) {
        unsigned queued = MBLifecycleStateQueued;
        atomic_compare_exchange_strong(&_state, &queued, MBLifecycleStateInvalidated);
        return; // a bad executor never invokes the consumer off-main
    }
    unsigned queued = MBLifecycleStateQueued;
    if (!atomic_compare_exchange_strong(&_state, &queued, MBLifecycleStateExecuting)) return;
    [self removeObservers];
    @try { _handler((MBLifecycleSource)atomic_load(&_source)); }
    @catch (__unused NSException *exception) { /* finite attempt, never retry */ }
    @finally {
        unsigned executing = MBLifecycleStateExecuting;
        atomic_compare_exchange_strong(&_state, &executing, MBLifecycleStateFinished);
    }
}
- (BOOL)invalidate {
    if (!NSThread.isMainThread) return NO;
    atomic_store(&_state, MBLifecycleStateInvalidated);
    [self removeObservers];
    return YES;
}
- (void)removeObservers {
    // Only start/delivery/invalidate on main, or dealloc after all strong users
    // have returned. Notification blocks and scheduled work hold self weakly.
    id launch = _launchToken, active = _activeToken;
    _launchToken = nil; _activeToken = nil;
    @try { if (launch) [_center removeObserver:launch]; } @catch (__unused NSException *exception) {}
    @try { if (active) [_center removeObserver:active]; } @catch (__unused NSException *exception) {}
}
- (void)dealloc { [self removeObservers]; }
@end
