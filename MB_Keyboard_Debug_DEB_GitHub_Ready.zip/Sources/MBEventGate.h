// SPDX-License-Identifier: MIT
#pragma once
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>

// One atomic word: upper 63 bits epoch, bit 0 permission. Zero is terminal
// exhaustion/deny. A stale policy can never reopen a newer invalidation.
typedef struct { atomic_uint_fast64_t state; } MBEventGate;
void MBEventGateInit(MBEventGate *gate);
uint64_t MBEventGateEpoch(const MBEventGate *gate);
uint64_t MBEventGateAllowedEpoch(const MBEventGate *gate);
uint64_t MBEventGateInvalidate(MBEventGate *gate);
bool MBEventGatePublishAllowed(MBEventGate *gate, uint64_t evaluatedEpoch);
