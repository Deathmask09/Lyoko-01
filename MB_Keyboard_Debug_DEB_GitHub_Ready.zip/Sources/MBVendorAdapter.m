// SPDX-License-Identifier: MIT
// Local adaptation of the third-party engine attributed in Vendor/BubbleMe/NOTICE.md.
#import "MBVendorAdapter.h"
#import "MBEnginePolicy.h"
#import "MBEngineArtwork.h"
#import "MBEngineBubbleShape.h"
#import "MBEngineIncomingBadge.h"
#import "MBEngineSceneSizing.h"
#import "MBSceneSizeRequestGate.h"
#import "MBEnginePanelLifecycle.h"
#import "MBEngineEvents.h"
#import "MBEngineTestRequest.h"
#import "MBHybridMetadataObserver.h"
#import "MBUserAvatarNative.h"
#import "MBRuntime.h"
#import "ApelinBootstrap.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/message.h>
#import <substrate.h>
#import <os/log.h>
#import <notify.h>
#include <stdatomic.h>
#include <string.h>

static _Atomic(bool) MBEnabled, MBUserSession, MBEntryReady;
static atomic_ullong MBIngressEpoch = ATOMIC_VAR_INIT(1);
// A global, atomic request lease: invalidated when panels/sessions change.
// UIKit objects remain strictly main-thread-only; deferred scene settings blocks
// may execute on a different queue.
static atomic_ullong MBPanelRequestGeneration = ATOMIC_VAR_INIT(1);
static atomic_uint MBPendingBulletins;
static BOOL MBEngineReady, MBHandlingAutomatic;
static unsigned MBIncomingCount; // Main-queue, session-only; never an unread/read-receipt claim.
static void *MBEngineHandle;
static id MBCaptureObserver;
static MBEngineEventHistory *MBEventHistory;
static const char *MBTarget = "com.facebook.Messenger";
static os_log_t MBAdapterLog(void) {
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "engine"); });
    return log;
}
static void MBVoid(id object, const char *name) {
    SEL selector = sel_registerName(name);
    if (object && MBMethodMatches(object_getClass(object), selector, "v", 0, NULL))
        ((void (*)(id, SEL))objc_msgSend)(object, selector);
}
static id MBManager(void) {
    return MBEngineReady ? MBReadObject(objc_getClass("BMBubbleManager"), sel_registerName("sharedManager")) : nil;
}
static BOOL MBAllows(id bundle) {
    return [bundle isKindOfClass:NSString.class] && [bundle isEqualToString:@"com.facebook.Messenger"] &&
        MBEngineAllowsBundle([bundle UTF8String], atomic_load(&MBEnabled), atomic_load(&MBUserSession));
}
static void MBRefreshIncomingBadge(id manager) {
    id view = MBReadObject(manager, sel_registerName("activeBubbleView"));
    if ([view isKindOfClass:UIView.class] &&
        [MBReadObject(view, sel_registerName("bundleIdentifier")) isEqual:@"com.facebook.Messenger"])
        MBEngineUpdateIncomingBadge(view, MBIncomingCount);
}
static void MBEndSession(void) {
    atomic_fetch_add(&MBPanelRequestGeneration, 1); // Reject in-flight remote scene size writes.
    atomic_fetch_add(&MBIngressEpoch, 1); // Invalidate notification work already queued.
    MBIncomingCount = 0;
    atomic_store(&MBUserSession, false); // Invalidate engine retries before teardown.
    MBUserAvatarResetNative(); // Cancel photo/metadata work even if no engine manager exists.
    id manager = MBManager();
    if (!manager) return;
    @try {
        MBRefreshIncomingBadge(manager);
        id window = MBReadObject(manager, sel_registerName("window"));
        if ([window isKindOfClass:UIWindow.class]) [window setHidden:YES];
        MBVoid(manager, "bm_stopLiveContentHealthWatch");
        MBVoid(manager, "bm_releaseLiveScene");
        MBVoid(manager, "closeAllBubbles");
        MBVoid(manager, "stop");
    } @catch (__unused NSException *exception) {
        os_log_error(MBAdapterLog(), "MBEngine teardown-exception build=%{public}s", APELIN_BUILD_ID);
    }
}
static BOOL MBIsUnlocked(void) {
    id lock = MBReadObject(objc_getClass("SBLockScreenManager"), sel_registerName("sharedInstance"));
    BOOL locked = YES;
    return lock && MBReadBool(lock, sel_registerName("isUILocked"), &locked) && !locked;
}
static MBEngineForeground MBReadForeground(void) {
    // SpringBoard is the authority. An app's active state alone is ambiguous:
    // Messenger can also be active inside the hosted bubble.
    id springboard = UIApplication.sharedApplication;
    BOOL home = NO;
    if (MBReadBool(springboard, sel_registerName("isShowingHomescreen"), &home) && home)
        return MBEngineForegroundElsewhere;
    id application = MBReadObject(springboard, sel_registerName("_accessibilityFrontMostApplication"));
    NSString *bundle = MBReadBoundedString(application, sel_registerName("bundleIdentifier"), 255);
    if (!bundle) return MBEngineForegroundUnknown; // Never interpret nil as Home.
    return [bundle isEqualToString:@"com.facebook.Messenger"] ?
        MBEngineForegroundMessenger : MBEngineForegroundElsewhere;
}

// Photo assignment rechecks the existing SB privacy authority at delivery time.
// It cannot create a bubble, switch a scene, navigate or mark any chat read.
static BOOL MBMayApplyNativeAvatar(UIImageView *target) {
    if (!NSThread.isMainThread || !atomic_load(&MBUserSession) || ![target isKindOfClass:UIImageView.class] ||
        !MBEngineShouldAutoBubble(atomic_load(&MBEnabled), MBIsUnlocked(),
            UIScreen.mainScreen.isCaptured, MBReadForeground())) return NO;
    id manager = MBManager();
    if (!MBAllows(MBReadObject(manager, sel_registerName("activeBundleID")))) return NO;
    id bubble = MBReadObject(manager, sel_registerName("activeBubbleView"));
    return [bubble isKindOfClass:UIView.class] &&
        MBAllows(MBReadObject(bubble, sel_registerName("bundleIdentifier"))) &&
        MBReadObject(bubble, sel_registerName("iconImageView")) == target &&
        [target isDescendantOfView:bubble];
}

// Never read or subscribe to the original engine's settings domain.
@interface MBEnginePreferences : NSObject
@end
@implementation MBEnginePreferences
- (BOOL)isBubbleEnabled { return atomic_load(&MBEnabled) && atomic_load(&MBUserSession); }
- (BOOL)isBubbleBackgroundEnabled { return NO; }
- (void)reload {}
- (void)setBubbleEnabled:(BOOL)value { (void)value; }
- (void)setBubbleBackgroundEnabled:(BOOL)value { (void)value; }
@end
static id MBPreferences(id cls, SEL cmd) {
    (void)cls; (void)cmd;
    static MBEnginePreferences *settings;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ settings = [MBEnginePreferences new]; });
    return settings;
}
static NSArray *MBEmptyCatalog(id cls, SEL cmd, id excluded) {
    (void)cls; (void)cmd; (void)excluded;
    return @[];
}
static BOOL MBNoAdd(id self, SEL cmd) { (void)self; (void)cmd; return NO; }
static void MBNoHealthTimer(id self, SEL cmd) {
    (void)cmd;
    MBVoid(self, "bm_stopLiveContentHealthWatch");
}
static void (*MBOriginalOpen1)(id, SEL, id);
static void (*MBOriginalOpen3)(id, SEL, id, id, id);
static void (*MBOriginalOpen4)(id, SEL, id, id, id, id);
static void MBOpen1(id self, SEL cmd, id bundle) {
    if (MBAllows(bundle)) MBOriginalOpen1(self, cmd, bundle);
}
static void MBOpen3(id self, SEL cmd, id bundle, id icon, id name) {
    if (MBAllows(bundle)) MBOriginalOpen3(self, cmd, bundle, icon, name);
}
static void MBOpen4(id self, SEL cmd, id bundle, id icon, id name, id source) {
    if (MBAllows(bundle)) MBOriginalOpen4(self, cmd, bundle, icon, name, source);
}
static void (*MBOriginalRetry)(id, SEL, id, NSInteger);
static void MBRetry(id self, SEL cmd, id bundle, NSInteger attempt) {
    if (MBAllows(bundle)) MBOriginalRetry(self, cmd, bundle, attempt);
}
static void (*MBOriginalRescue)(id, SEL, id);
static void MBRescue(id self, SEL cmd, id bundle) {
    if (MBAllows(bundle)) MBOriginalRescue(self, cmd, bundle);
}
static void (*MBOriginalInstall)(id, SEL);
static void MBInstallContent(id self, SEL cmd) {
    if (!MBHandlingAutomatic && MBAllows(MBReadObject(self, sel_registerName("activeBundleID"))))
        MBOriginalInstall(self, cmd);
}
static void (*MBOriginalShowExpanded)(id, SEL);
static void MBShowExpanded(id self, SEL cmd) {
    // Notifications create a collapsed icon only. Hosting starts on a user's tap.
    if (!MBHandlingAutomatic && MBAllows(MBReadObject(self, sel_registerName("activeBundleID"))) &&
        MBIsUnlocked() && !UIScreen.mainScreen.isCaptured) {
        MBOriginalShowExpanded(self, cmd);
        id expanded = MBReadObject(self, sel_registerName("expandedView"));
        if (expanded) {
            double rounded;
            if ([expanded isKindOfClass:UIView.class]) {
                CGSize size = [(UIView *)expanded bounds].size;
                if (MBEnginePanelCornerRadius(size.width, size.height, &rounded))
                    ((void (*)(id, SEL, CGFloat))objc_msgSend)(expanded,
                        sel_registerName("setPanelCornerRadius:"), (CGFloat)rounded);
            }
            MBIncomingCount = 0; // Dismiss this local counter, never mark chats read.
            MBRefreshIncomingBadge(self);
        }
    }
}
static void (*MBOriginalWatchStart)(id, SEL);
static void (*MBOriginalWatchTick)(id, SEL);
static void MBWatchStart(id self, SEL cmd) {
    if (!MBAllows(MBReadObject(self, sel_registerName("bundleID")))) return;
    MBOriginalWatchStart(self, cmd);
    CADisplayLink *link = MBReadObject(self, sel_registerName("hostWatchLink"));
    if ([link isKindOfClass:CADisplayLink.class]) link.preferredFramesPerSecond = 15;
}
static void MBWatchTick(id self, SEL cmd) {
    double start = ((double (*)(id, SEL))objc_msgSend)(self, sel_registerName("hostWatchStart"));
    if (!MBEngineWatchMayContinue(start, CACurrentMediaTime(), atomic_load(&MBUserSession))) {
        ((void (*)(id, SEL, BOOL))objc_msgSend)(self, sel_registerName("setHostWaitExpired:"), YES);
        MBVoid(self, "bm_stopHostWatch");
        MBVoid(self, "bm_layoutHostedViews");
        MBVoid(self, "bm_stopHostWatch");
        return;
    }
    MBOriginalWatchTick(self, cmd);
}
static void (*MBOriginalDragStart)(id, SEL);
static void MBDragStart(id self, SEL cmd) {
    MBOriginalDragStart(self, cmd);
    CADisplayLink *link = MBReadObject(self, sel_registerName("collapsedDragDisplayLink"));
    if ([link isKindOfClass:CADisplayLink.class]) {
        link.preferredFrameRateRange = CAFrameRateRangeMake(30, 60, 60);
        link.preferredFramesPerSecond = 60;
    }
}
static void MBRoundBubble(id object) {
    if (![object isKindOfClass:UIView.class] ||
        !MBAllows(MBReadObject(object, sel_registerName("bundleIdentifier")))) return;
    UIView *bubble = object;
    id artwork = MBReadObject(object, sel_registerName("iconImageView"));
    if (![artwork isKindOfClass:UIImageView.class] || ![artwork isDescendantOfView:bubble]) return;
    MBEngineCircle circle;
    if (!MBEngineCircleInBounds(bubble.bounds.size.width, bubble.bounds.size.height, &circle)) return;
    UIImageView *icon = artwork;
    CGRect rect = CGRectMake(bubble.bounds.origin.x + circle.x, bubble.bounds.origin.y + circle.y,
                             circle.diameter, circle.diameter);
    CGFloat radius = circle.diameter / 2;
    if (CGRectEqualToRect(icon.frame, rect) && icon.clipsToBounds &&
        icon.layer.cornerRadius == radius && [icon.layer.cornerCurve isEqualToString:kCACornerCurveCircular]) return;
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    // Keep the outer view's frame, transform, hit testing, recognizers and shadow.
    icon.frame = rect;
    icon.layer.cornerCurve = kCACornerCurveCircular;
    icon.layer.cornerRadius = radius;
    icon.clipsToBounds = YES;
    icon.contentMode = UIViewContentModeScaleAspectFill;
    if (icon.image.isSymbolImage) icon.backgroundColor = UIColor.systemBlueColor;
    bubble.layer.cornerCurve = kCACornerCurveCircular;
    bubble.layer.cornerRadius = radius;
    bubble.layer.masksToBounds = NO;
    bubble.layer.shadowPath = [UIBezierPath bezierPathWithOvalInRect:rect].CGPath;
    [CATransaction commit];
}
static void (*MBOriginalPlaceIcon)(id, SEL, id, CGRect, CGFloat);
static void MBPlaceIcon(id self, SEL cmd, id icon, CGRect frame, CGFloat scale) {
    // Scale the actual bubble view, including artwork/border/shadow and hit area,
    // through the engine's own placement API. Keep its center, drag coordinates,
    // orientation and animation scale; never resize the hosted Messenger panel.
    double enlarged;
    if (MBAllows(MBReadObject(icon, sel_registerName("bundleIdentifier"))) &&
        MBEngineLargerIconScale(scale, &enlarged)) scale = (CGFloat)enlarged;
    MBOriginalPlaceIcon(self, cmd, icon, frame, scale);
    MBRoundBubble(icon);
    if (MBAllows(MBReadObject(icon, sel_registerName("bundleIdentifier"))))
        MBEngineUpdateIncomingBadge(icon, MBIncomingCount);
}

// Outer-frame candidate only. Keep the existing native scene/input path until
// keyboard layer ownership can be verified; no cross-process frame relay.

static CGRect (*MBOriginalAppWindowFrame)(id, SEL);
static CGRect MBAppWindowFrame(id self, SEL cmd) {
    CGRect original = MBOriginalAppWindowFrame(self, cmd);
    if (!MBAllows(MBReadObject(self, sel_registerName("activeBundleID")))) return original;
    // Use the engine's chrome coordinates, not UIScreen bounds in another
    // orientation. MBLayoutHost separately requests the actual native scene size.
    CGRect bounds = ((CGRect (*)(id, SEL))objc_msgSend)(self, sel_registerName("bm_layoutBounds"));
    MBEnginePanelRect panel;
    if (!MBEngineFloatingPanelInBounds(bounds.origin.x, bounds.origin.y,
        bounds.size.width, bounds.size.height, &panel)) return original;
    return CGRectMake(panel.x, panel.y, panel.width, panel.height);
}
static void (*MBOriginalPanelCaret)(id, SEL);
static void MBLayoutPanelCaret(id self, SEL cmd) {
    if (MBAllows(MBReadObject(self, sel_registerName("activeBundleID")))) {
        MBVoid(self, "bm_removePanelCaret"); // Floating window, not a popover attached to an icon.
        return;
    }
    MBOriginalPanelCaret(self, cmd);
}

static void (*MBOriginalPanelCornerRadius)(id, SEL, CGFloat);
static void MBPanelCornerRadius(id self, SEL cmd, CGFloat radius) {
    double rounded;
    if ([self isKindOfClass:UIView.class] &&
        MBAllows(MBReadObject(MBManager(), sel_registerName("activeBundleID")))) {
        CGSize size = [(UIView *)self bounds].size;
        if (MBEnginePanelCornerRadius(size.width, size.height, &rounded)) radius = (CGFloat)rounded;
    }
    MBOriginalPanelCornerRadius(self, cmd, radius);
}

// The factory starts with a full-phone scene even when its container is smaller.
// Resize the native frame AND display configuration, not its rendered bitmap.
@interface MBEnginePanelSizeState : NSObject
@property(nonatomic) CGSize target;
@property(nonatomic, weak) id scene, panel;
@property(nonatomic, strong) id configuration;
@property(nonatomic) unsigned long long epoch, presentation, requestGeneration;
@property(nonatomic) CFTimeInterval started;
@property(nonatomic) unsigned attempts;
@property(nonatomic) BOOL submitted, settingsWritten, pending, finished, applying;
@end
@implementation MBEnginePanelSizeState
@end
static char MBEnginePanelSizeKey;
// Main-queue presentation identity. Never use the notification ingress epoch as
// the sole lifetime of a panel: it intentionally survives collapse/reopen.
static unsigned long long MBPanelPresentation;
static __weak id MBPanelSizingHost;
static void (*MBOriginalSetExpandedView)(id, SEL, id);
static void MBSetExpandedView(id self, SEL cmd, id panel) {
    if (NSThread.isMainThread && MBReadObject(self, sel_registerName("expandedView")) != panel &&
        (MBAllows(MBReadObject(self, sel_registerName("activeBundleID"))) || MBPanelSizingHost)) {
        ++MBPanelPresentation; // Invalidate pending blocks BEFORE native teardown.
        atomic_fetch_add(&MBPanelRequestGeneration, 1);
        id host = MBPanelSizingHost;
        MBPanelSizingHost = nil;
        MBVoid(host, "bm_stopHostWatch");
        if (host) objc_setAssociatedObject(host, &MBEnginePanelSizeKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    MBOriginalSetExpandedView(self, cmd, panel);
}
static BOOL MBMaySizePanel(id host) {
    if (!NSThread.isMainThread || ![host isKindOfClass:UIView.class] ||
        !MBAllows(MBReadObject(host, sel_registerName("bundleID"))) ||
        !MBIsUnlocked() || UIScreen.mainScreen.isCaptured) return NO;
    id manager = MBManager();
    id expanded = MBReadObject(manager, sel_registerName("expandedView"));
    return MBAllows(MBReadObject(manager, sel_registerName("activeBundleID"))) &&
        [expanded isKindOfClass:UIView.class] && [(UIView *)host isDescendantOfView:expanded] &&
        MBReadForeground() == MBEngineForegroundElsewhere;
}
static BOOL MBPanelSizeStateIsCurrent(id host, MBEnginePanelSizeState *current) {
    return host && current && MBMaySizePanel(host) &&
        current.epoch == atomic_load(&MBIngressEpoch) && current.presentation == MBPanelPresentation &&
        current.panel == MBReadObject(MBManager(), sel_registerName("expandedView")) &&
        current.scene == MBReadObject(host, sel_registerName("hostedScene")) &&
        objc_getAssociatedObject(host, &MBEnginePanelSizeKey) == current;
}
static void (*MBOriginalLayoutHost)(id, SEL);
static void MBLayoutHost(id self, SEL cmd) {
    MBEnginePanelSizeState *state = objc_getAssociatedObject(self, &MBEnginePanelSizeKey);
    if (state.applying || !MBMaySizePanel(self)) { MBOriginalLayoutHost(self, cmd); return; }
    CGSize area = [(UIView *)self bounds].size;
    NSInteger physical = ((NSInteger (*)(id, SEL))objc_msgSend)(MBManager(),
        sel_registerName("bm_physicalDeviceOrientation"));
    MBEngineNativeSize native;
    id scene = MBReadObject(self, sel_registerName("hostedScene"));
    if (!scene || !MBEnginePanelNativeSize(area.width, area.height, physical, &native)) {
        MBOriginalLayoutHost(self, cmd); return;
    }
    CGSize target = CGSizeMake(native.width, native.height);
    unsigned long long epoch = atomic_load(&MBIngressEpoch);
    id panel = MBReadObject(MBManager(), sel_registerName("expandedView"));
    if (!state || state.panel != panel || !MBEnginePanelStateReusable(state.scene == scene,
        CGSizeEqualToSize(state.target, target), state.epoch, epoch, state.presentation, MBPanelPresentation)) {
        state = [MBEnginePanelSizeState new];
        state.target = target; state.scene = scene; state.panel = panel; state.epoch = epoch;
        state.presentation = MBPanelPresentation;
        state.requestGeneration = atomic_fetch_add(&MBPanelRequestGeneration, 1) + 1;
        state.started = CACurrentMediaTime();
        id mainDisplay = MBReadObject(UIScreen.mainScreen, sel_registerName("displayConfiguration"));
        state.configuration = MBEngineCreatePanelDisplayConfiguration(mainDisplay, target);
        objc_setAssociatedObject(self, &MBEnginePanelSizeKey, state, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        MBPanelSizingHost = self;
    }
    state.applying = YES;
    MBOriginalLayoutHost(self, cmd);
    state.applying = NO;
    if (!state.configuration || !MBPanelSizeStateIsCurrent(self, state)) return;
    BOOL sceneMatches = NO;
    BOOL geometryKnown = MBEngineReadPanelSettings(MBReadObject(scene, sel_registerName("settings")), target, &sceneMatches);
    BOOL waiting = MBEngineWatchMayContinue(state.started, CACurrentMediaTime(), true);
    if ((!state.submitted || (geometryKnown && !sceneMatches)) &&
        MBEnginePanelMayRequest(state.attempts, state.pending, waiting)) {
        ++state.attempts; state.pending = YES; state.settingsWritten = NO; state.finished = NO;
        state.applying = YES;
        __weak id weakHost = self;
        __weak MBEnginePanelSizeState *weakState = state;
        // Snapshot plain scalar state on main. Do not call MBPanelSizeStateIsCurrent
        // from the deferred FrontBoard settings block: that method probes UIKit
        // and explicitly requires the main thread. An off-main callback would
        // reject a valid resize or leave pending=YES until the host deadline.
        const MBSceneSizeRequestTicket ticket = {
            state.requestGeneration, state.epoch, state.started
        };
        // Submit AFTER original layout. A native update in the original must not
        // be the final writer of frame/display geometry on a reopened scene.
        state.submitted = MBEngineRequestSceneSizeAcknowledged(scene, target, state.configuration, ^BOOL {
            return MBSceneSizeRequestTicketAllows(ticket,
                atomic_load(&MBPanelRequestGeneration), atomic_load(&MBIngressEpoch),
                atomic_load(&MBUserSession), CACurrentMediaTime());
        }, ^(BOOL written) {
            // FrontBoard may invoke its update block off-main. Deliver all host,
            // state and UIView updates on main, and recheck the live panel there.
            dispatch_block_t complete = ^{
                id host = weakHost;
                MBEnginePanelSizeState *current = weakState;
                if (!MBPanelSizeStateIsCurrent(host, current) ||
                    !MBSceneSizeRequestTicketAllows(ticket,
                        atomic_load(&MBPanelRequestGeneration), atomic_load(&MBIngressEpoch),
                        atomic_load(&MBUserSession), CACurrentMediaTime())) return;
                current.pending = NO;
                current.settingsWritten = written;
                // Ensure an asynchronous acknowledgement gets reconciled even
                // when the native host did not otherwise request a layout pass.
                [(UIView *)host setNeedsLayout];
            };
            if (NSThread.isMainThread) complete();
            else dispatch_async(dispatch_get_main_queue(), complete);
        });
        if (state.submitted && MBPanelSizeStateIsCurrent(self, state)) {
            ((void (*)(id, SEL, CGSize))objc_msgSend)(self, sel_registerName("setNativeHostSize:"), target);
            ((void (*)(id, SEL, BOOL))objc_msgSend)(self, sel_registerName("setLandscapeLocked:"), NO);
            ((void (*)(id, SEL, NSInteger))objc_msgSend)(self, sel_registerName("setLastHostOrientation:"), UIInterfaceOrientationPortrait);
            ((void (*)(id, SEL, BOOL))objc_msgSend)(self, sel_registerName("setLastFitValid:"), NO);
            ((void (*)(id, SEL, BOOL))objc_msgSend)(self, sel_registerName("setHostWaitExpired:"), NO);
            [(UIView *)self setNeedsLayout]; // Native relayout, never bitmap scaling.
        }
        if (!state.submitted) state.pending = NO;
        state.applying = NO;
        sceneMatches = NO;
        geometryKnown = MBEngineReadPanelSettings(MBReadObject(scene, sel_registerName("settings")), target, &sceneMatches);
        os_log(MBAdapterLog(), "MBEngine panel-size-request build=%{public}s submitted=%d presentation=%llu attempt=%u written=%d width=%.2f height=%.2f",
            APELIN_BUILD_ID, state.submitted, state.presentation, state.attempts, state.settingsWritten, target.width, target.height);
    }
    CGSize buffer = ((CGSize (*)(id, SEL))objc_msgSend)(self, sel_registerName("hostBufferSize"));
    BOOL matched = isfinite(buffer.width) && isfinite(buffer.height) &&
        fabs(buffer.width - target.width) <= 1 && fabs(buffer.height - target.height) <= 1;
    BOOL settled = MBEnginePanelMayFinish(state.settingsWritten, geometryKnown && sceneMatches, matched);
    if (settled || !waiting) {
        if (!state.finished) {
            os_log(MBAdapterLog(), "MBEngine panel-buffer build=%{public}s settled=%d geometry_known=%d scene_match=%d buffer_match=%d presentation=%llu",
                APELIN_BUILD_ID, settled, geometryKnown, sceneMatches, matched, state.presentation);
        }
        state.finished = YES;
        MBVoid(self, "bm_stopHostWatch");
    } else {
        // Reuse the native 15 FPS link and the original absolute deadline. An
        // old same-sized buffer cannot finish a still-pending settings write.
        state.finished = NO;
        MBVoid(self, "bm_startHostWatchIfNeeded");
    }
}

typedef struct {
    const char *cls, *selector, *result;
    unsigned argc;
    const char *args[4];
    BOOL meta;
    IMP replacement;
    IMP *original;
} MBEngineHook;
static BOOL MBPrepareEngine(void) {
    if (MBEngineReady) return YES;
    if (MBEngineHandle) return NO;
    const char *names[] = {"BMBubbleManager", "BMPreferences", "BMLiveSceneContainer", "BMAppCatalog", "BMAppInfo", "BMBubbleView", "BMBubbleExpandedView"};
    for (unsigned i = 0; i < sizeof(names) / sizeof(names[0]); ++i) if (objc_getClass(names[i])) return NO;
    NSString *path = ApelinBootstrapPath(@"/Library/MessengerBubbles/MessengerBubblesEngine.dylib");
    if (!path) return NO;
    MBEngineHandle = dlopen(path.fileSystemRepresentation, RTLD_NOW | RTLD_LOCAL);
    if (!MBEngineHandle) return NO;
    MBEngineHook hooks[] = {
        {"BMPreferences", "sharedPreferences", "@", 0, {0}, YES, (IMP)MBPreferences, NULL},
        {"BMAppCatalog", "visibleApplicationsExcluding:", "@", 1, {"@"}, YES, (IMP)MBEmptyCatalog, NULL},
        {"BMBubbleManager", "bm_shouldShowAddButton", @encode(BOOL), 0, {0}, NO, (IMP)MBNoAdd, NULL},
        {"BMBubbleManager", "bm_startLiveContentHealthWatch", "v", 0, {0}, NO, (IMP)MBNoHealthTimer, NULL},
        {"BMBubbleManager", "openAppAsBubble:", "v", 1, {"@"}, NO, (IMP)MBOpen1, (IMP *)&MBOriginalOpen1},
        {"BMBubbleManager", "openAppAsBubble:icon:displayName:", "v", 3, {"@", "@", "@"}, NO, (IMP)MBOpen3, (IMP *)&MBOriginalOpen3},
        {"BMBubbleManager", "openAppAsBubble:icon:displayName:source:", "v", 4, {"@", "@", "@", "@"}, NO, (IMP)MBOpen4, (IMP *)&MBOriginalOpen4},
        {"BMBubbleManager", "bm_retryLiveContentForBundleID:attempt:", "v", 2, {"@", @encode(NSInteger)}, NO, (IMP)MBRetry, (IMP *)&MBOriginalRetry},
        {"BMBubbleManager", "bm_beginLiveContentRescueForBundleID:", "v", 1, {"@"}, NO, (IMP)MBRescue, (IMP *)&MBOriginalRescue},
        {"BMBubbleManager", "bm_installLiveContentForActiveBubble", "v", 0, {0}, NO, (IMP)MBInstallContent, (IMP *)&MBOriginalInstall},
        {"BMBubbleManager", "showExpandedView", "v", 0, {0}, NO, (IMP)MBShowExpanded, (IMP *)&MBOriginalShowExpanded},
        {"BMBubbleManager", "setExpandedView:", "v", 1, {"@"}, NO, (IMP)MBSetExpandedView, (IMP *)&MBOriginalSetExpandedView},
        {"BMBubbleManager", "bm_appWindowFrame", @encode(CGRect), 0, {0}, NO, (IMP)MBAppWindowFrame, (IMP *)&MBOriginalAppWindowFrame},
        {"BMBubbleManager", "bm_layoutPanelCaret", "v", 0, {0}, NO, (IMP)MBLayoutPanelCaret, (IMP *)&MBOriginalPanelCaret},
        {"BMBubbleManager", "bm_startCollapsedDragDisplayLink", "v", 0, {0}, NO, (IMP)MBDragStart, (IMP *)&MBOriginalDragStart},
        {"BMBubbleManager", "bm_placeIconView:inFrame:extraScale:", "v", 3, {"@", @encode(CGRect), @encode(CGFloat)}, NO, (IMP)MBPlaceIcon, (IMP *)&MBOriginalPlaceIcon},
        {"BMBubbleExpandedView", "setPanelCornerRadius:", "v", 1, {@encode(CGFloat)}, NO, (IMP)MBPanelCornerRadius, (IMP *)&MBOriginalPanelCornerRadius},
        {"BMLiveSceneContainer", "bm_layoutHostedViews", "v", 0, {0}, NO, (IMP)MBLayoutHost, (IMP *)&MBOriginalLayoutHost},
        {"BMLiveSceneContainer", "bm_startHostWatchIfNeeded", "v", 0, {0}, NO, (IMP)MBWatchStart, (IMP *)&MBOriginalWatchStart},
        {"BMLiveSceneContainer", "bm_hostWatchTick", "v", 0, {0}, NO, (IMP)MBWatchTick, (IMP *)&MBOriginalWatchTick},
    };
    NSString *canonical = path.stringByResolvingSymlinksInPath;
    for (const char **name = names; name < names + sizeof(names) / sizeof(names[0]); ++name) {
        Class cls = objc_getClass(*name);
        const char *image = cls ? class_getImageName(cls) : NULL;
        if (!image || ![[@(image) stringByResolvingSymlinksInPath] isEqualToString:canonical]) return NO;
    }
    for (unsigned i = 0; i < sizeof(hooks) / sizeof(hooks[0]); ++i) {
        MBEngineHook *hook = &hooks[i];
        Class cls = objc_getClass(hook->cls);
        if (hook->meta) cls = object_getClass(cls);
        if (!MBMethodMatches(cls, sel_registerName(hook->selector), hook->result, hook->argc, hook->args)) return NO;
    }
    Class host = objc_getClass("BMLiveSceneContainer"), bubble = objc_getClass("BMBubbleView");
    Class manager = objc_getClass("BMBubbleManager");
    const char *boolean[] = {@encode(BOOL)}, *size[] = {@encode(CGSize)}, *integer[] = {@encode(NSInteger)};
    if (!MBMethodMatches(manager, sel_registerName("bm_layoutBounds"), @encode(CGRect), 0, NULL) ||
        !MBMethodMatches(manager, sel_registerName("bm_chromeView"), "@", 0, NULL) ||
        !MBMethodMatches(manager, sel_registerName("bm_physicalDeviceOrientation"), @encode(NSInteger), 0, NULL) ||
        !MBMethodMatches(manager, sel_registerName("bm_removePanelCaret"), "v", 0, NULL) ||
        !MBMethodMatches(host, sel_registerName("hostedScene"), "@", 0, NULL) ||
        !MBMethodMatches(host, sel_registerName("bundleID"), "@", 0, NULL) ||
        !MBMethodMatches(host, sel_registerName("hostBufferSize"), @encode(CGSize), 0, NULL) ||
        !MBMethodMatches(host, sel_registerName("setNativeHostSize:"), "v", 1, size) ||
        !MBMethodMatches(host, sel_registerName("setLandscapeLocked:"), "v", 1, boolean) ||
        !MBMethodMatches(host, sel_registerName("setLastHostOrientation:"), "v", 1, integer) ||
        !MBMethodMatches(host, sel_registerName("setLastFitValid:"), "v", 1, boolean) ||
        !MBMethodMatches(host, sel_registerName("bm_stopHostWatch"), "v", 0, NULL) ||
        !MBMethodMatches(host, sel_registerName("hostWatchStart"), "d", 0, NULL) ||
        !MBMethodMatches(host, sel_registerName("setHostWaitExpired:"), "v", 1, boolean) ||
        !MBMethodMatches(bubble, sel_registerName("bundleIdentifier"), "@", 0, NULL) ||
        !MBMethodMatches(bubble, sel_registerName("iconImageView"), "@", 0, NULL)) return NO;
    for (unsigned i = 0; i < sizeof(hooks) / sizeof(hooks[0]); ++i) {
        MBEngineHook *hook = &hooks[i];
        Class cls = objc_getClass(hook->cls);
        MSHookMessageEx(hook->meta ? object_getClass(cls) : cls, sel_registerName(hook->selector), hook->replacement, hook->original);
    }
    MBEngineReady = YES;
    os_log(MBAdapterLog(), "MBEngine prepared build=%{public}s automatic=1 background=off health_timer=off", APELIN_BUILD_ID);
    return YES;
}
static id MBMessengerIconModel(void) {
    id controller = MBReadObject(objc_getClass("SBIconController"), sel_registerName("sharedInstance"));
    id model = MBReadObject(controller, sel_registerName("model"));
    SEL read = sel_registerName("applicationIconForBundleIdentifier:");
    const char *args[] = {"@"};
    if (!MBMethodMatches(object_getClass(model), read, "@", 1, args)) return nil;
    @try { return ((id (*)(id, SEL, id))objc_msgSend)(model, read, @"com.facebook.Messenger"); }
    @catch (__unused NSException *exception) { return nil; }
}
static UIImage *MBMessengerArtwork(void) {
    id artwork = MBReadMessengerArtwork(objc_getClass("BMAppInfo"), MBMessengerIconModel());
    if ([artwork isKindOfClass:UIImage.class]) {
        UIImage *image = artwork;
        if (image.size.width > 0 && image.size.height > 0 &&
            image.size.width <= 1024 && image.size.height <= 1024) return image;
    }
    return [[UIImage systemImageNamed:@"message.fill"] imageWithTintColor:UIColor.whiteColor
        renderingMode:UIImageRenderingModeAlwaysOriginal];
}
static NSString *MBAutoBubble(BOOL isTest) {
    MBEngineForeground foreground = MBReadForeground();
    BOOL enabled = atomic_load(&MBEnabled), unlocked = MBIsUnlocked();
    BOOL captured = UIScreen.mainScreen.isCaptured;
    if (!MBEngineShouldAutoBubble(enabled, unlocked, captured, foreground)) {
        if (foreground == MBEngineForegroundMessenger && atomic_load(&MBUserSession)) MBEndSession();
        os_log(MBAdapterLog(), "MBEngine event-suppressed build=%{public}s test=%d foreground=%d", APELIN_BUILD_ID, isTest, foreground);
        if (!enabled) return @"Chặn: bubble đang tắt";
        if (!unlocked) return @"Chặn: máy đang khóa";
        if (captured) return @"Chặn: đang quay màn hình";
        if (foreground == MBEngineForegroundMessenger) return @"Chặn: đang mở Messenger";
        return @"Chặn: chưa xác định app trước mặt";
    }
    @try {
        if (!MBPrepareEngine()) {
            os_log_error(MBAdapterLog(), "MBEngine prepare-failed build=%{public}s", APELIN_BUILD_ID);
            return @"Lỗi: chưa chuẩn bị được engine";
        }
        id manager = MBManager();
        if (!manager) return @"Lỗi: chưa có bubble manager";
        // Count only deduplicated real ingress accepted by the guards above.
        // A notification while the panel is open is not a new local unread claim.
        // TEST must not change even an existing real counter while its panel is open.
        if (!isTest)
            MBIncomingCount = MBEngineNextIncomingCount(MBIncomingCount, !isTest,
                MBReadObject(manager, sel_registerName("expandedView")) != nil);
        // One app bubble only; a second event must not collapse, switch or reopen
        // the user's existing panel. The system notification is still published.
        if (MBAllows(MBReadObject(manager, sel_registerName("activeBundleID")))) {
            MBRefreshIncomingBadge(manager);
            return @"Đã có bubble; đã cập nhật số thông báo";
        }
        atomic_store(&MBUserSession, true);
        BOOL previous = MBHandlingAutomatic;
        MBHandlingAutomatic = YES;
        @try {
            MBVoid(manager, "start");
            SEL open = sel_registerName("openAppAsBubble:icon:displayName:");
            NSString *name = isTest ? @"TEST nội bộ • Messenger" : @"Messenger";
            ((void (*)(id, SEL, id, id, id))objc_msgSend)(manager, open, @(MBTarget), MBMessengerArtwork(), name);
            if (isTest) {
                id view = MBReadObject(manager, sel_registerName("activeBubbleView"));
                if ([view isKindOfClass:UIView.class]) [view setAccessibilityLabel:name];
            }
        } @finally { MBHandlingAutomatic = previous; }
        if (!MBReadObject(manager, sel_registerName("activeBubbleView"))) {
            MBEndSession();
            return @"Lỗi: engine chưa tạo bubble";
        }
        MBRefreshIncomingBadge(manager);
        os_log(MBAdapterLog(), "MBEngine auto-submitted build=%{public}s test=%d collapsed=1", APELIN_BUILD_ID, isTest);
        // Submission is not proof that the icon was visibly rendered.
        return isTest ? @"Đã yêu cầu hiện TEST" : @"Đã yêu cầu hiện bubble";
    } @catch (__unused NSException *exception) {
        MBEndSession();
        return @"Lỗi: engine dừng TEST/bubble";
    }
}
#if defined(APELIN_CONFIGURATION_DEBUG)
static void MBStartDebugTests(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        // Session-only high-water marks. Never read a stored request at startup.
        // A consumed request stays consumed even if a privacy guard rejects it.
        static NSTimeInterval sessionStart, consumedAt;
        static NSString *consumedNonce;
        static BOOL readPending;
        sessionStart = NSDate.date.timeIntervalSince1970;
        consumedAt = sessionStart;
        dispatch_queue_t queue = dispatch_queue_create("com.lyoko-01.messengerbubbles.test-read", DISPATCH_QUEUE_SERIAL);
        int token;
        uint32_t result = notify_register_dispatch(MB_ENGINE_TEST_REQUEST_CHANGED, &token,
            dispatch_get_main_queue(), ^(int hint) {
            (void)hint;
            if (readPending) return; // At most one preference read in flight.
            readPending = YES;
            unsigned long long epoch = atomic_load(&MBIngressEpoch);
            dispatch_async(queue, ^{
                id request = nil;
                BOOL preferenceEnabled = NO;
                if (CFPreferencesAppSynchronize(CFSTR(APELIN_PACKAGE_ID))) {
                    request = CFBridgingRelease(CFPreferencesCopyAppValue(
                        (__bridge CFStringRef)MB_ENGINE_TEST_REQUEST_KEY, CFSTR(APELIN_PACKAGE_ID)));
                    CFPropertyListRef value = CFPreferencesCopyAppValue(CFSTR("EngineEnabled"), CFSTR(APELIN_PACKAGE_ID));
                    preferenceEnabled = value && CFGetTypeID(value) == CFBooleanGetTypeID() &&
                        CFBooleanGetValue((CFBooleanRef)value);
                    if (value) CFRelease(value);
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    readPending = NO;
                    NSString *nonce = MBEngineDebugTestNonce(request, NSDate.date.timeIntervalSince1970, sessionStart);
                    if (!nonce) return;
                    NSTimeInterval stamp = [request[@"requestedAt"] doubleValue];
                    BOOL nonceDifferent = ![consumedNonce isEqualToString:nonce];
                    if (!MB_ENGINE_TEST_NEW_INTENT(stamp, consumedAt, nonceDifferent)) return;
                    consumedAt = stamp;
                    consumedNonce = [nonce copy];
                    // Darwin has no authenticated sender. Require current Settings
                    // foreground plus all existing privacy gates; never queue for
                    // a later unlock/ON or bypass them to create/host a scene.
                    id application = MBReadObject(UIApplication.sharedApplication,
                        sel_registerName("_accessibilityFrontMostApplication"));
                    NSString *bundle = MBReadBoundedString(application, sel_registerName("bundleIdentifier"), 255);
                    BOOL settingsFront = [bundle isEqualToString:@"com.apple.Preferences"];
                    BOOL ready = atomic_load(&MBEntryReady);
                    BOOL enabled = preferenceEnabled && atomic_load(&MBEnabled);
                    BOOL unlocked = MBIsUnlocked();
                    BOOL captured = YES;
                    BOOL captureKnown = MBReadBool(UIScreen.mainScreen, sel_registerName("isCaptured"), &captured);
                    unsigned long long currentEpoch = atomic_load(&MBIngressEpoch);
                    if (!MB_ENGINE_TEST_ALLOWED(epoch, currentEpoch, ready, enabled, settingsFront,
                                                unlocked, captureKnown, captured)) return;
                    // Collapsed icon only. This path never calls publish/provider,
                    // invents a message, increments a badge or marks anything read.
                    (void)MBAutoBubble(YES);
                });
            });
        });
        if (result != NOTIFY_STATUS_OK)
            os_log_error(MBAdapterLog(), "MBEngine test-listener-failed build=%{public}s", APELIN_BUILD_ID);
    });
}
#endif

static void (*MBOriginalPublish)(id, SEL, id, NSUInteger);
static void MBPublish(id self, SEL cmd, id bulletin, NSUInteger destinations) {
    unsigned long long epoch = atomic_load(&MBIngressEpoch);
    if (MBOriginalPublish) MBOriginalPublish(self, cmd, bulletin, destinations);
    // Preserve original notification, action and destination mask unconditionally.
    if (!atomic_load(&MBEntryReady) || !atomic_load(&MBEnabled)) return;
    unsigned pending = atomic_fetch_add(&MBPendingBulletins, 1);
    if (pending >= 16) { atomic_fetch_sub(&MBPendingBulletins, 1); return; }
    BOOL queued = NO;
    @try {
        Class cls = objc_getClass("BBBulletin");
        if (!cls || ![bulletin isKindOfClass:cls]) return;
        NSData *token = MBEngineNotificationToken(bulletin, NSDate.date.timeIntervalSince1970);
        if (!token) return;
        MBHybridObserveBulletin(bulletin, atomic_load(&MBEnabled));
        // Bounded identity candidate only, after the original publish. Exact avatar
        // lookup must resolve it in the verified account DB; never use it as userID.
        NSString *avatarCandidate = [MBReadBoundedString(bulletin, sel_registerName("threadID"), 512) copy];
        CFTimeInterval received = CACurrentMediaTime();
        dispatch_async(dispatch_get_main_queue(), ^{
            @try {
                if (MBEngineIngressMayDispatch(epoch, atomic_load(&MBIngressEpoch), received, CACurrentMediaTime()) &&
                    [MBEventHistory acceptToken:token]) {
                    (void)MBAutoBubble(NO);
                    id bubble = MBReadObject(MBManager(), sel_registerName("activeBubbleView"));
                    id icon = MBReadObject(bubble, sel_registerName("iconImageView"));
                    MBUserAvatarObserveNative(avatarCandidate, [icon isKindOfClass:UIImageView.class] ? icon : nil, MBMessengerArtwork(),
                        ^BOOL(UIImageView *target) { return MBMayApplyNativeAvatar(target); });
                }
            } @catch (__unused NSException *exception) { MBEndSession(); }
            @finally { atomic_fetch_sub(&MBPendingBulletins, 1); }
        });
        queued = YES;
    } @catch (__unused NSException *exception) {
        // Observation failure never changes the original notification.
    } @finally { if (!queued) atomic_fetch_sub(&MBPendingBulletins, 1); }
}
static void (*MBOriginalLockWide)(id, SEL, NSInteger, id);
static void (*MBOriginalLockNarrow)(id, SEL, int, id);
static void MBLockWide(id self, SEL cmd, NSInteger source, id options) {
    MBEndSession();
    MBOriginalLockWide(self, cmd, source, options);
}
static void MBLockNarrow(id self, SEL cmd, int source, id options) {
    MBEndSession();
    MBOriginalLockNarrow(self, cmd, source, options);
}
static void MBReloadSettings(void) {
    static dispatch_queue_t queue;
    static NSUInteger generation;
    if (!queue) queue = dispatch_queue_create("com.lyoko-01.messengerbubbles.settings", DISPATCH_QUEUE_SERIAL);
    NSUInteger request = ++generation;
    atomic_store(&MBEnabled, false);
    MBEndSession(); // Drop queued events across OFF/ON and settings reloads.
    dispatch_async(queue, ^{
        BOOL enabled = NO;
        if (CFPreferencesAppSynchronize(CFSTR(APELIN_PACKAGE_ID))) {
            CFPropertyListRef value = CFPreferencesCopyAppValue(CFSTR("EngineEnabled"), CFSTR(APELIN_PACKAGE_ID));
            enabled = value && CFGetTypeID(value) == CFBooleanGetTypeID() && CFBooleanGetValue((CFBooleanRef)value);
            if (value) CFRelease(value);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (request == generation) atomic_store(&MBEnabled, enabled && atomic_load(&MBEntryReady));
        });
    });
}
void MBStartVendorAdapter(void) {
    if (!NSThread.isMainThread || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
    NSOperatingSystemVersion os = NSProcessInfo.processInfo.operatingSystemVersion;
    if (os.majorVersion != 16 || os.minorVersion != 5 || os.patchVersion != 0) return;
    MBStartHybridMetadataObserver();
    Class lock = objc_getClass("SBLockScreenManager"), server = objc_getClass("BBServer");
    SEL locking = sel_registerName("lockUIFromSource:withOptions:"), publish = sel_registerName("publishBulletin:destinations:");
    const char *wideArgs[] = {@encode(NSInteger), "@"}, *narrowArgs[] = {@encode(int), "@"};
    const char *publishArgs[] = {"@", @encode(NSUInteger)};
    BOOL wide = MBMethodMatches(lock, locking, "v", 2, wideArgs);
    BOOL narrow = MBMethodMatches(lock, locking, "v", 2, narrowArgs);
    if ((!wide && !narrow) || !MBMethodMatches(lock, sel_registerName("isUILocked"), @encode(BOOL), 0, NULL) ||
        !MBMethodMatches(object_getClass(UIApplication.sharedApplication), sel_registerName("_accessibilityFrontMostApplication"), "@", 0, NULL)) {
        os_log_error(MBAdapterLog(), "MBEngine automatic-unsupported build=%{public}s guards=0", APELIN_BUILD_ID);
        return;
    }
    if (wide) MSHookMessageEx(lock, locking, (IMP)MBLockWide, (IMP *)&MBOriginalLockWide);
    else MSHookMessageEx(lock, locking, (IMP)MBLockNarrow, (IMP *)&MBOriginalLockNarrow);
    atomic_store(&MBEntryReady, MBOriginalLockWide || MBOriginalLockNarrow);
    // Notification ingress requires the privacy guards as well as its exact ABI.
    if (atomic_load(&MBEntryReady) && MBMethodMatches(server, publish, "v", 2, publishArgs)) {
        MBEventHistory = [MBEngineEventHistory new];
        MSHookMessageEx(server, publish, (IMP)MBPublish, (IMP *)&MBOriginalPublish);
    }
    if (!MBOriginalPublish)
        os_log_error(MBAdapterLog(), "MBEngine notification-unsupported build=%{public}s", APELIN_BUILD_ID);
    int settingsToken, activeToken;
    notify_register_dispatch(APELIN_PACKAGE_ID "/changed", &settingsToken, dispatch_get_main_queue(), ^(int _) { (void)_; MBReloadSettings(); });
    notify_register_dispatch(APELIN_PACKAGE_ID "/messenger/active-hint", &activeToken, dispatch_get_main_queue(), ^(int _) {
        (void)_;
        // Unauthenticated hint has no activation authority. Verify SB foreground.
        if (atomic_load(&MBUserSession) && MBReadForeground() == MBEngineForegroundMessenger) MBEndSession();
    });
    MBCaptureObserver = [NSNotificationCenter.defaultCenter addObserverForName:UIScreenCapturedDidChangeNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) {
        if (UIScreen.mainScreen.isCaptured) MBEndSession();
    }];
    MBReloadSettings();
#if defined(APELIN_CONFIGURATION_DEBUG)
    MBStartDebugTests();
#endif
    os_log(MBAdapterLog(), "MBEngine automatic-armed build=%{public}s guards=%d notifications=%d lazy=1 default=off", APELIN_BUILD_ID, atomic_load(&MBEntryReady), MBOriginalPublish != NULL);
}
