// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>

@interface MBConfiguration : NSObject
@property(nonatomic, readonly) BOOL enabled;
@property(nonatomic, copy, readonly) NSSet<NSString *> *safeApplications;
- (instancetype)initWithEnabled:(BOOL)enabled safeApplications:(NSSet<NSString *> *)applications;
@end

// Pure parser, also exercised by the offline executable. Empty/invalid => deny all.
FOUNDATION_EXPORT NSSet<NSString *> *MBParseSafeApplications(id value);
// Does not read preferences in a constructor or on SpringBoard's main thread.
FOUNDATION_EXPORT void MBLoadConfiguration(void (^completion)(MBConfiguration *configuration));
