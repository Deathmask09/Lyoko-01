// SPDX-License-Identifier: MIT
#import "MBHybridAvatarURLSource.h"
#import <ImageIO/ImageIO.h>
#include <math.h>

static const NSUInteger MBUserAvatarSubjectLimit = 64;
static const NSUInteger MBUserAvatarRequestLimit = 16;
static const NSUInteger MBUserAvatarEncodedLimit = 1024 * 1024;

static void MBUserAvatarRequireMain(void) {
    NSCAssert(NSThread.isMainThread, @"Avatar source is main-queue-only");
}
static BOOL MBUserAvatarID(NSString *text, BOOL numeric) {
    if (![text isKindOfClass:NSString.class] || !text.length || text.length > (numeric ? 64 : 512)) return NO;
    for (NSUInteger i = 0; i < text.length; ++i) {
        unichar c = [text characterAtIndex:i];
        if (numeric ? (c < '0' || c > '9') : (c < 0x21 || c > 0x7e)) return NO;
    }
    return YES; // Exact strings, including leading zeroes; never cast through a number.
}
static NSURL *MBUserAvatarURL(NSString *reference) {
    if (![reference isKindOfClass:NSString.class] || !reference.length || reference.length > 4096 ||
        [reference rangeOfCharacterFromSet:NSCharacterSet.whitespaceAndNewlineCharacterSet].location != NSNotFound) return nil;
    NSURLComponents *parts = [NSURLComponents componentsWithString:reference];
    NSString *host = parts.host.lowercaseString;
    BOOL cdn = [host isEqualToString:@"fbcdn.net"] || [host hasSuffix:@".fbcdn.net"] ||
               [host isEqualToString:@"fbsbx.com"] || [host hasSuffix:@".fbsbx.com"];
    if (![parts.scheme.lowercaseString isEqualToString:@"https"] || !cdn || parts.user || parts.password ||
        parts.fragment || (parts.port && parts.port.integerValue != 443)) return nil;
    return parts.URL; // No Graph URL construction, cookies, auth or redirects.
}
static UIImage *MBUserAvatarDecode(NSData *bytes) {
    if (!bytes.length || bytes.length > MBUserAvatarEncodedLimit) return nil;
    CGImageSourceRef source = CGImageSourceCreateWithData((__bridge CFDataRef)bytes,
        (__bridge CFDictionaryRef)@{(__bridge NSString *)kCGImageSourceShouldCache:@NO});
    if (!source) return nil;
    UIImage *result = nil;
    if (CGImageSourceGetCount(source) == 1) {
        NSDictionary *properties = CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(source, 0, NULL));
        id width = properties[(__bridge NSString *)kCGImagePropertyPixelWidth];
        id height = properties[(__bridge NSString *)kCGImagePropertyPixelHeight];
        double w = [width isKindOfClass:NSNumber.class] ? [width doubleValue] : 0;
        double h = [height isKindOfClass:NSNumber.class] ? [height doubleValue] : 0;
        // Bound source dimensions before decompression; thumbnail decodes off-main.
        if (isfinite(w) && isfinite(h) && w >= 1 && h >= 1 && w <= 4096 && h <= 4096) {
            NSDictionary *options = @{
                (__bridge NSString *)kCGImageSourceCreateThumbnailFromImageAlways:@YES,
                (__bridge NSString *)kCGImageSourceCreateThumbnailWithTransform:@YES,
                (__bridge NSString *)kCGImageSourceThumbnailMaxPixelSize:@512,
                (__bridge NSString *)kCGImageSourceShouldCacheImmediately:@YES,
            };
            CGImageRef image = CGImageSourceCreateThumbnailAtIndex(source, 0, (__bridge CFDictionaryRef)options);
            if (image) {
                size_t iw = CGImageGetWidth(image), ih = CGImageGetHeight(image), row = CGImageGetBytesPerRow(image);
                if (iw && ih && iw <= 512 && ih <= 512 && row <= MBUserAvatarEncodedLimit / ih)
                    result = [UIImage imageWithCGImage:image];
                CGImageRelease(image);
            }
        }
    }
    CFRelease(source);
    return result;
}

@interface MBUserAvatarReference : NSObject
@property(nonatomic, copy) NSString *key, *subject, *reference;
@property(nonatomic, strong) NSURL *url;
@property(nonatomic) uint64_t revision;
@property(nonatomic) NSTimeInterval deadline;
@property(nonatomic) BOOL invalid;
@end
@implementation MBUserAvatarReference
@end

@class MBUserAvatarRequest;
@interface MBHybridAvatarURLSource (MBUserAvatarPrivate)
- (void)mb_cancelRequest:(MBUserAvatarRequest *)request;
- (void)mb_receiveResponse:(NSURLResponse *)response task:(NSURLSessionDataTask *)task
               completion:(void (^)(NSURLSessionResponseDisposition))completion;
- (void)mb_receiveData:(NSData *)data task:(NSURLSessionDataTask *)task;
- (void)mb_completeTask:(NSURLSessionTask *)task error:(NSError *)error;
@end

@interface MBUserAvatarDecodeGate : NSObject
@property(nonatomic, strong) NSData *data;
@property(nonatomic, strong) UIImage *image;
@property(nonatomic) BOOL closed;
- (NSData *)takeData;
- (void)offerImage:(UIImage *)image;
- (UIImage *)takeImage;
- (void)invalidate;
@end
@implementation MBUserAvatarDecodeGate
- (NSData *)takeData {
    @synchronized (self) { NSData *value = self.closed ? nil : self.data; self.data = nil; return value; }
}
- (void)offerImage:(UIImage *)image { @synchronized (self) { if (!self.closed) self.image = image; } }
- (UIImage *)takeImage {
    @synchronized (self) { UIImage *value = self.closed ? nil : self.image; self.image = nil; self.closed = YES; return value; }
}
- (void)invalidate { @synchronized (self) { self.closed = YES; self.data = nil; self.image = nil; } }
@end

@interface MBUserAvatarRequest : NSObject <MBHybridAvatarTask>
@property(nonatomic, weak) MBHybridAvatarURLSource *owner;
@property(nonatomic, strong) MBUserAvatarReference *reference;
@property(nonatomic, strong) NSURLSessionDataTask *task;
@property(nonatomic, strong) NSMutableData *data;
@property(nonatomic, strong) MBUserAvatarDecodeGate *decodeGate;
@property(nonatomic, copy) MBHybridAvatarReply reply;
@property(nonatomic) BOOL active, responseAccepted;
@end
@implementation MBUserAvatarRequest
- (void)cancel { MBUserAvatarRequireMain(); [self.owner mb_cancelRequest:self]; }
@end

// NSURLSession retains its delegate. A weak proxy prevents a source/session cycle.
@interface MBUserAvatarSessionDelegate : NSObject <NSURLSessionDataDelegate>
@property(nonatomic, weak) MBHybridAvatarURLSource *owner;
@end
@implementation MBUserAvatarSessionDelegate
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task
    didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completion {
    (void)session;
    MBHybridAvatarURLSource *owner = self.owner;
    if (owner) [owner mb_receiveResponse:response task:task completion:completion];
    else completion(NSURLSessionResponseCancel);
}
- (void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)task didReceiveData:(NSData *)data {
    (void)session; [self.owner mb_receiveData:data task:task];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    (void)session; [self.owner mb_completeTask:task error:error];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task
    willPerformHTTPRedirection:(NSHTTPURLResponse *)response newRequest:(NSURLRequest *)request
    completionHandler:(void (^)(NSURLRequest *))completion {
    (void)session; (void)task; (void)response; (void)request;
    completion(nil); // A reference grants only that exact HTTPS request.
}
- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
    completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completion {
    (void)session;
    completion([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust] ?
        NSURLSessionAuthChallengePerformDefaultHandling : NSURLSessionAuthChallengeCancelAuthenticationChallenge, nil);
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task
    didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
    completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completion {
    (void)task; [self URLSession:session didReceiveChallenge:challenge completionHandler:completion];
}
@end

@implementation MBHybridAvatarURLSource {
    NSString *_accountID;
    NSURLSessionConfiguration *_configuration;
    NSURLSession *_session;
    MBUserAvatarSessionDelegate *_delegate;
    NSMutableDictionary<NSString *, MBUserAvatarReference *> *_subjects;
    NSMutableDictionary<NSString *, MBUserAvatarReference *> *_references;
    NSMutableDictionary<NSNumber *, MBUserAvatarRequest *> *_network;
    NSMutableSet<MBUserAvatarRequest *> *_requests;
    NSMutableSet<MBUserAvatarDecodeGate *> *_decodes;
    dispatch_queue_t _decodeQueue;
}
- (instancetype)initWithAccountID:(NSString *)accountID {
    return [self initWithAccountID:accountID configuration:NSURLSessionConfiguration.ephemeralSessionConfiguration];
}
- (instancetype)initWithAccountID:(NSString *)accountID configuration:(NSURLSessionConfiguration *)configuration {
    MBUserAvatarRequireMain();
    if (!MBUserAvatarID(accountID, YES) || ![configuration isKindOfClass:NSURLSessionConfiguration.class]) return nil;
    if ((self = [super init])) {
        _accountID = [accountID copy];
        // Do not copy persistent caches, cookie jars, credentials or arbitrary headers.
        _configuration = NSURLSessionConfiguration.ephemeralSessionConfiguration;
        _configuration.protocolClasses = [configuration.protocolClasses copy]; // Offline fixture seam only.
        _configuration.URLCache = nil; _configuration.HTTPCookieStorage = nil;
        _configuration.URLCredentialStorage = nil; _configuration.HTTPShouldSetCookies = NO;
        _configuration.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        _configuration.timeoutIntervalForRequest = 8; _configuration.timeoutIntervalForResource = 8;
        _configuration.waitsForConnectivity = NO; _configuration.HTTPMaximumConnectionsPerHost = 2;
        _subjects = [NSMutableDictionary new]; _references = [NSMutableDictionary new];
        _network = [NSMutableDictionary new]; _requests = [NSMutableSet new]; _decodes = [NSMutableSet new];
        _decodeQueue = dispatch_queue_create("com.lyoko-01.messengerbubbles.avatar-decode", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}
- (BOOL)mb_currentReference:(MBUserAvatarReference *)reference {
    return reference && !reference.invalid && _references[reference.key] == reference &&
        NSProcessInfo.processInfo.systemUptime < reference.deadline;
}
- (void)mb_cancelRequest:(MBUserAvatarRequest *)request {
    MBUserAvatarRequireMain();
    if (!request.active || ![_requests containsObject:request]) return;
    request.active = NO; request.reply = nil; request.owner = nil; request.data = nil;
    [request.decodeGate invalidate]; request.decodeGate = nil;
    NSURLSessionDataTask *task = request.task;
    if (task) [_network removeObjectForKey:@(task.taskIdentifier)];
    request.task = nil; [_requests removeObject:request];
    [task cancel]; // State invalidated before callbacks can reenter.
}
- (void)mb_finishRequest:(MBUserAvatarRequest *)request image:(UIImage *)image {
    MBUserAvatarRequireMain();
    if (!request.active || ![_requests containsObject:request]) return;
    MBHybridAvatarReply reply = request.reply;
    if (![self mb_currentReference:request.reference]) image = nil;
    [self mb_cancelRequest:request];
    if (reply) reply(image);
}
- (void)mb_invalidateReference:(MBUserAvatarReference *)reference {
    reference.invalid = YES;
    [_references removeObjectForKey:reference.key];
    // A rotated/conflicting reference must not leave a cache flight hanging.
    for (MBUserAvatarRequest *request in [_requests allObjects]) {
        if (request.reference != reference) continue;
        NSURLSessionDataTask *task = request.task;
        if (task) [_network removeObjectForKey:@(task.taskIdentifier)];
        request.task = nil; request.data = nil; [task cancel];
        __weak typeof(self) weakSelf = self;
        __weak MBUserAvatarRequest *weakRequest = request;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf mb_finishRequest:weakRequest image:nil]; });
    }
}
- (NSString *)mb_registerID:(NSString *)identifier group:(BOOL)group reference:(NSString *)reference
                  revision:(uint64_t)revision lifetime:(NSTimeInterval)seconds {
    MBUserAvatarRequireMain();
    if (!MBUserAvatarID(identifier, !group) || !revision || !isfinite(seconds) || seconds <= 0 || seconds > 300) return nil;
    NSURL *url = MBUserAvatarURL(reference);
    if (!url) return nil;
    NSString *subject = [NSString stringWithFormat:@"%@:%lu:%@", group ? @"group" : @"user",
        (unsigned long)identifier.length, identifier];
    MBUserAvatarReference *old = _subjects[subject];
    if (old && revision < old.revision) return nil;
    if (old && revision == old.revision) {
        if (![old.reference isEqualToString:reference]) [self mb_invalidateReference:old];
        return [self mb_currentReference:old] ? old.key : nil; // No lease extension.
    }
    if (!old && _subjects.count >= MBUserAvatarSubjectLimit) return nil;
    if (old) [self mb_invalidateReference:old];
    MBUserAvatarReference *entry = [MBUserAvatarReference new];
    entry.subject = subject; entry.reference = reference; entry.url = url; entry.revision = revision;
    entry.deadline = NSProcessInfo.processInfo.systemUptime + seconds;
    // Source is account-scoped; a fresh opaque key never aliases account/kind/revision.
    entry.key = NSUUID.UUID.UUIDString;
    _subjects[subject] = entry; _references[entry.key] = entry;
    return entry.key;
}
- (NSString *)registerUserID:(NSString *)userID reference:(NSString *)reference
                  revision:(uint64_t)revision lifetime:(NSTimeInterval)seconds {
    return [self mb_registerID:userID group:NO reference:reference revision:revision lifetime:seconds];
}
- (NSString *)registerGroupID:(NSString *)groupID reference:(NSString *)reference
                   revision:(uint64_t)revision lifetime:(NSTimeInterval)seconds {
    return [self mb_registerID:groupID group:YES reference:reference revision:revision lifetime:seconds];
}
- (id<MBHybridAvatarTask>)loadAvatarForKey:(NSString *)key completion:(MBHybridAvatarReply)completion {
    MBUserAvatarRequireMain();
    MBUserAvatarRequest *request = [MBUserAvatarRequest new];
    if (!completion || _requests.count + _decodes.count >= MBUserAvatarRequestLimit) return request;
    request.active = YES; request.owner = self; request.reply = completion;
    [_requests addObject:request];
    MBUserAvatarReference *reference = [key isKindOfClass:NSString.class] ? _references[key] : nil;
    request.reference = reference;
    if (![self mb_currentReference:reference]) {
        __weak typeof(self) weakSelf = self;
        __weak MBUserAvatarRequest *weakRequest = request;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf mb_finishRequest:weakRequest image:nil]; });
        return request;
    }
    if (!_session) {
        _delegate = [MBUserAvatarSessionDelegate new]; _delegate.owner = self;
        _session = [NSURLSession sessionWithConfiguration:_configuration delegate:_delegate delegateQueue:NSOperationQueue.mainQueue];
    }
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:reference.url
        cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:8];
    urlRequest.HTTPShouldHandleCookies = NO;
    [urlRequest setValue:@"image/jpeg,image/png,image/webp" forHTTPHeaderField:@"Accept"];
    request.data = [NSMutableData new];
    request.task = [_session dataTaskWithRequest:urlRequest];
    _network[@(request.task.taskIdentifier)] = request;
    [request.task resume];
    return request;
}
- (void)mb_receiveResponse:(NSURLResponse *)response task:(NSURLSessionDataTask *)task
               completion:(void (^)(NSURLSessionResponseDisposition))completion {
    MBUserAvatarRequireMain();
    MBUserAvatarRequest *request = _network[@(task.taskIdentifier)];
    NSString *mime = response.MIMEType.lowercaseString;
    BOOL type = [mime isEqualToString:@"image/jpeg"] || [mime isEqualToString:@"image/png"] || [mime isEqualToString:@"image/webp"];
    BOOL valid = request.active && [self mb_currentReference:request.reference] &&
        [response isKindOfClass:NSHTTPURLResponse.class] && [(NSHTTPURLResponse *)response statusCode] == 200 &&
        [response.URL isEqual:request.reference.url] && type && response.expectedContentLength != 0 &&
        response.expectedContentLength <= (int64_t)MBUserAvatarEncodedLimit;
    request.responseAccepted = valid;
    completion(valid ? NSURLSessionResponseAllow : NSURLSessionResponseCancel);
}
- (void)mb_receiveData:(NSData *)data task:(NSURLSessionDataTask *)task {
    MBUserAvatarRequireMain();
    MBUserAvatarRequest *request = _network[@(task.taskIdentifier)];
    if (!request.active) return;
    if (!request.responseAccepted || ![self mb_currentReference:request.reference] ||
        data.length > MBUserAvatarEncodedLimit - request.data.length) {
        [_network removeObjectForKey:@(task.taskIdentifier)];
        request.task = nil; request.data = nil; [task cancel];
        __weak typeof(self) weakSelf = self;
        __weak MBUserAvatarRequest *weakRequest = request;
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf mb_finishRequest:weakRequest image:nil]; });
        return;
    }
    [request.data appendData:data];
}
- (void)mb_completeTask:(NSURLSessionTask *)task error:(NSError *)error {
    MBUserAvatarRequireMain();
    MBUserAvatarRequest *request = _network[@(task.taskIdentifier)];
    if (!request.active) return;
    [_network removeObjectForKey:@(task.taskIdentifier)]; request.task = nil;
    NSData *data = request.data; request.data = nil;
    if (error || !request.responseAccepted || ![self mb_currentReference:request.reference]) {
        [self mb_finishRequest:request image:nil]; return;
    }
    MBUserAvatarDecodeGate *gate = [MBUserAvatarDecodeGate new];
    gate.data = data; request.decodeGate = gate; [_decodes addObject:gate];
    __weak typeof(self) weakSelf = self;
    __weak MBUserAvatarRequest *weakRequest = request;
    dispatch_async(_decodeQueue, ^{
        @autoreleasepool {
            [gate offerImage:MBUserAvatarDecode([gate takeData])];
            dispatch_async(dispatch_get_main_queue(), ^{
                MBHybridAvatarURLSource *source = weakSelf;
                if (!source) { [gate invalidate]; return; }
                [source->_decodes removeObject:gate];
                [source mb_finishRequest:weakRequest image:[gate takeImage]];
            });
        }
    });
}
- (void)purge {
    MBUserAvatarRequireMain();
    for (MBUserAvatarRequest *request in [_requests allObjects]) [self mb_cancelRequest:request];
    for (MBUserAvatarDecodeGate *gate in _decodes) [gate invalidate];
    // Keep pending job slots until their queued work retires, even across purge.
    [_references removeAllObjects]; [_subjects removeAllObjects];
}
- (void)dealloc {
    [self purge]; _delegate.owner = nil; [_session invalidateAndCancel];
}
@end
