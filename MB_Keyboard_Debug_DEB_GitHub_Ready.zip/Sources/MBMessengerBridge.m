// SPDX-License-Identifier: MIT
#import "MBMessengerBridge.h"
#import "MBHybridMetadataObserver.h"
#import <UIKit/UIKit.h>
#import <notify.h>

static void MBPostActiveHint(void) {
    // Untrusted, payload-free PURGE hint only. SpringBoard verifies its own
    // foreground state; this signal can never open a bubble or send a message.
    notify_post(APELIN_PACKAGE_ID "/messenger/active-hint");
}
void MBStartMessengerBridge(void) {
    if (!NSThread.isMainThread || ![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.facebook.Messenger"]) return;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        MBStartHybridMetadataObserver();
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        for (NSNotificationName name in @[UIApplicationDidBecomeActiveNotification,
                                          UIApplicationWillEnterForegroundNotification,
                                          UISceneDidActivateNotification]) {
            [center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue
                           usingBlock:^(__unused NSNotification *note) { MBPostActiveHint(); }];
        }
        if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive) MBPostActiveHint();
    });
}
