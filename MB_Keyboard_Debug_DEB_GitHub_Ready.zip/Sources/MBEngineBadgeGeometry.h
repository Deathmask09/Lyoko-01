// SPDX-License-Identifier: MIT
#pragma once
#include <math.h>
#include <stdbool.h>

// Target display: 460 ppi at @3x. Increase the single-digit badge diameter /
// multi-digit pill HEIGHT by 1.5 mm, not the Messenger icon's diameter.
#define MB_ENGINE_BADGE_EXTRA_VISUAL_POINTS (1.5 * 460.0 / (25.4 * 3.0))
#define MB_ENGINE_BADGE_ICON_VISUAL_POINTS 65.0

typedef struct { double width, height, fontSize, borderWidth; } MBEngineBadgeMetrics;
static inline bool MBEngineIncomingBadgeMetrics(double iconDiameter, unsigned characters,
                                                 MBEngineBadgeMetrics *out) {
    if (!out || !isfinite(iconDiameter) || iconDiameter <= 0 || iconDiameter > 1024 ||
        characters < 1 || characters > 3) return false;
    double growth = 1.0 + MB_ENGINE_BADGE_EXTRA_VISUAL_POINTS /
        (MB_ENGINE_BADGE_ICON_VISUAL_POINTS * 0.31);
    *out = (MBEngineBadgeMetrics){
        iconDiameter * (0.31 + (characters - 1) * 0.105) * growth,
        iconDiameter * 0.31 * growth, iconDiameter * 0.21 * growth,
        iconDiameter * 0.023};
    return true;
}
