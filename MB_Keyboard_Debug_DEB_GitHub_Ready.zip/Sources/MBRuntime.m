// SPDX-License-Identifier: MIT
#import "MBRuntime.h"
#import <objc/message.h>
#include <stdlib.h>
#include <string.h>

static BOOL MBTypeMatches(const char *actual, const char *expected) {
    if (!actual || !expected) return NO;
    // Ignore only Objective-C qualifiers, never integer width or struct layout.
    while (*actual && strchr("rnNoORV", *actual)) ++actual;
    if (strcmp(expected, "@") == 0) return actual[0] == '@' && actual[1] != '?';
    return strcmp(actual, expected) == 0;
}

BOOL MBMethodMatches(Class cls, SEL selector, const char *result,
                     unsigned count, const char *const *arguments) {
    if (!cls || !selector || !result || (count && !arguments)) return NO;
    Method method = class_getInstanceMethod(cls, selector);
    if (!method || method_getNumberOfArguments(method) != count + 2) return NO;
    char *type = method_copyReturnType(method);
    BOOL valid = MBTypeMatches(type, result);
    free(type);
    for (unsigned i = 0; valid && i < count; ++i) {
        type = method_copyArgumentType(method, i + 2);
        valid = MBTypeMatches(type, arguments[i]);
        free(type);
    }
    return valid;
}

id MBReadObject(id object, SEL selector) {
    if (!object || !MBMethodMatches(object_getClass(object), selector, "@", 0, NULL)) return nil;
    @try { return ((id (*)(id, SEL))objc_msgSend)(object, selector); }
    @catch (__unused NSException *exception) { return nil; }
}

BOOL MBReadBool(id object, SEL selector, BOOL *value) {
    if (!object || !value || !MBMethodMatches(object_getClass(object), selector, @encode(BOOL), 0, NULL)) return NO;
    @try {
        *value = ((BOOL (*)(id, SEL))objc_msgSend)(object, selector);
        return YES;
    } @catch (__unused NSException *exception) { return NO; }
}

NSString *MBReadBoundedString(id object, SEL selector, NSUInteger limit) {
    id value = MBReadObject(object, selector);
    if (![value isKindOfClass:NSString.class] || ![value length] || [value length] > limit) return nil;
    return [value copy];
}
