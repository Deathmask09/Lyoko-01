// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

// Deliberately closed in this offline-only foundation. Changing this requires
// an explicit security/compatibility audit; an existing selector is NOT proof.
#define MB_RUNTIME_PRIVACY_REVIEWED 0

FOUNDATION_EXPORT BOOL MBMethodMatches(Class cls, SEL selector, const char *result,
                                      unsigned count, const char *const *arguments);
FOUNDATION_EXPORT id MBReadObject(id object, SEL selector);
FOUNDATION_EXPORT BOOL MBReadBool(id object, SEL selector, BOOL *value);
FOUNDATION_EXPORT NSString *MBReadBoundedString(id object, SEL selector, NSUInteger limit);
