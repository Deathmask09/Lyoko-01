// SPDX-License-Identifier: MIT
#pragma once
#import <Foundation/Foundation.h>

// These are in-process calls, NOT a world-readable IPC data transport.
FOUNDATION_EXPORT void MBStartSpringBoardFoundation(void);
FOUNDATION_EXPORT void MBInvalidateSpringBoardFoundation(void);
FOUNDATION_EXPORT uint64_t MBCurrentIngressEpoch(void);
FOUNDATION_EXPORT uint64_t MBCaptureBulletinEpoch(void);
FOUNDATION_EXPORT void MBSubmitBulletinDigests(uint64_t conversation, uint64_t event, uint64_t epoch);
