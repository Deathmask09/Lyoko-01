// SPDX-License-Identifier: MIT
#pragma once
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import "MBRuntime.h"
#import "MBEngineBubbleShape.h"
#import "MBEnginePanelDisplay.h"

// Read the native scene's current geometry, not merely its last rendered buffer.
// NO means unavailable/unknown, not a full-phone mismatch to repair blindly.
static inline BOOL MBEngineReadPanelSettings(id settings, CGSize size, BOOL *matches) {
    if (!settings || !matches || !MBEnginePanelBoundsValid(0, 0, size.width, size.height)) return NO;
    SEL frame = sel_registerName("frame"), orientation = sel_registerName("interfaceOrientation");
    Class cls = object_getClass(settings);
    if (!MBMethodMatches(cls, frame, @encode(CGRect), 0, NULL) ||
        !MBMethodMatches(cls, orientation, @encode(NSInteger), 0, NULL)) return NO;
    id configuration = MBReadObject(settings, sel_registerName("displayConfiguration"));
    if (!configuration) return NO;
    @try {
        CGRect current = ((CGRect (*)(id, SEL))objc_msgSend)(settings, frame);
        NSInteger currentOrientation = ((NSInteger (*)(id, SEL))objc_msgSend)(settings, orientation);
        *matches = isfinite(current.origin.x) && isfinite(current.origin.y) &&
            isfinite(current.size.width) && isfinite(current.size.height) &&
            fabs(current.origin.x) <= 0.5 && fabs(current.origin.y) <= 0.5 &&
            fabs(current.size.width - size.width) <= 0.5 && fabs(current.size.height - size.height) <= 0.5 &&
            currentOrientation == UIInterfaceOrientationPortrait &&
            MBEngineDisplayConfigurationMatches(configuration, size);
        return YES;
    } @catch (__unused NSException *exception) { return NO; }
}

// Submit frame AND display geometry in one settings transaction. Frame alone
// leaves remote keyboard/IME display coordinates at the full-phone size.
// YES means submitted, not committed or that remote pixels/input are verified.
// didWrite acknowledges the settings block's writes only, NOT a rendered keyboard.
static inline BOOL MBEngineRequestSceneSizeAcknowledged(id scene, CGSize size, id configuration,
    BOOL (^permit)(void), void (^didWrite)(BOOL)) {
    if (!scene || !permit || !MBEngineDisplayConfigurationMatches(configuration, size)) return NO;
    SEL update = sel_registerName("updateSettingsWithBlock:");
    const char *blockArgs[] = {"@?"};
    if (!MBMethodMatches(object_getClass(scene), update, "v", 1, blockArgs)) return NO;
    @try {
        void (^change)(id) = ^(id settings) {
            if (!permit()) { if (didWrite) didWrite(NO); return; }
            SEL frame = sel_registerName("setFrame:"), orientation = sel_registerName("setInterfaceOrientation:");
            SEL display = sel_registerName("setDisplayConfiguration:");
            const char *frameArgs[] = {@encode(CGRect)}, *orientationArgs[] = {@encode(NSInteger)}, *displayArgs[] = {"@"};
            Class cls = object_getClass(settings);
            if (!MBMethodMatches(cls, frame, "v", 1, frameArgs) ||
                !MBMethodMatches(cls, orientation, "v", 1, orientationArgs) ||
                !MBMethodMatches(cls, display, "v", 1, displayArgs)) {
                if (didWrite) didWrite(NO);
                return;
            }
            @try {
                // Same native viewport for Messenger AND its remote keyboard.
                // Never replace a screen's global configuration or focus owner.
                ((void (*)(id, SEL, id))objc_msgSend)(settings, display, configuration);
                ((void (*)(id, SEL, NSInteger))objc_msgSend)(settings, orientation, UIInterfaceOrientationPortrait);
                ((void (*)(id, SEL, CGRect))objc_msgSend)(settings, frame, (CGRect){CGPointZero, size});
                BOOL matches = NO;
                if (didWrite) didWrite(MBEngineReadPanelSettings(settings, size, &matches) && matches);
            } @catch (__unused NSException *exception) { if (didWrite) didWrite(NO); }
        };
        ((void (*)(id, SEL, id))objc_msgSend)(scene, update, change);
        return YES;
    } @catch (__unused NSException *exception) { return NO; }
}

// Compatibility for existing callers/fixtures which only require submission.
static inline BOOL MBEngineRequestSceneSize(id scene, CGSize size, id configuration, BOOL (^permit)(void)) {
    return MBEngineRequestSceneSizeAcknowledged(scene, size, configuration, permit, nil);
}
