// SPDX-License-Identifier: MIT
#import "MBEngineEvents.h"
#import "MBEnginePolicy.h"
#import "MBRuntime.h"
#import "MBEngineTestRequest.h"
#import <CommonCrypto/CommonDigest.h>
#include <math.h>
#include <string.h>

NSData *MBEngineNotificationToken(id bulletin, NSTimeInterval now) {
    NSString *section = MBReadBoundedString(bulletin, sel_registerName("sectionID"), 255);
    if (![section isEqualToString:@"com.facebook.Messenger"]) return nil;
    id date = MBReadObject(bulletin, sel_registerName("date"));
    if (![date isKindOfClass:NSDate.class]) return nil;
    NSTimeInterval time = [date timeIntervalSince1970];
    if (!MBEngineEventIsFresh(time, now)) return nil;
    NSString *identifier = MBReadBoundedString(bulletin, sel_registerName("bulletinID"), 512);
    if (!identifier) return nil;
    NSData *encoded = [identifier dataUsingEncoding:NSUTF8StringEncoding];
    if (!encoded.length || encoded.length > 2048) return nil;
    static NSData *salt;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        unsigned char bytes[32];
        arc4random_buf(bytes, sizeof(bytes));
        salt = [NSData dataWithBytes:bytes length:sizeof(bytes)];
        memset(bytes, 0, sizeof(bytes));
    });
    NSMutableData *input = [salt mutableCopy];
    [input appendBytes:&time length:sizeof(time)];
    [input appendData:encoded];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(input.bytes, (CC_LONG)input.length, digest);
    memset(input.mutableBytes, 0, input.length);
    NSData *token = [NSData dataWithBytes:digest length:sizeof(digest)];
    memset(digest, 0, sizeof(digest));
    return token;
}

NSString *MBEngineDebugTestNonce(id request, NSTimeInterval now, NSTimeInterval notBefore) {
    if (![request isKindOfClass:NSDictionary.class] || [request count] != 2 ||
        !isfinite(now) || !isfinite(notBefore) || notBefore < 0) return nil;
    id nonce = request[@"nonce"], stamp = request[@"requestedAt"];
    if (![nonce isKindOfClass:NSString.class] || [nonce length] != 36 ||
        ![stamp isKindOfClass:NSNumber.class] ||
        CFGetTypeID((__bridge CFTypeRef)stamp) == CFBooleanGetTypeID()) return nil;
    double when = [stamp doubleValue];
    if (!isfinite(when) || when <= 0 || when < notBefore || now < when || now - when > 5.0) return nil;
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:nonce];
    NSString *canonical = uuid.UUIDString;
    return [canonical isEqualToString:[nonce uppercaseString]] ? canonical : nil;
}

@implementation MBEngineEventHistory {
    NSMutableOrderedSet<NSData *> *_tokens;
}
- (instancetype)init {
    self = [super init];
    if (self) _tokens = [NSMutableOrderedSet orderedSet];
    return self;
}
- (BOOL)acceptToken:(NSData *)token {
    if (![token isKindOfClass:NSData.class] || token.length != CC_SHA256_DIGEST_LENGTH ||
        [_tokens containsObject:token]) return NO;
    if (_tokens.count >= 64) [_tokens removeObjectAtIndex:0];
    [_tokens addObject:[token copy]];
    return YES;
}
- (void)removeAll { [_tokens removeAllObjects]; }
@end
