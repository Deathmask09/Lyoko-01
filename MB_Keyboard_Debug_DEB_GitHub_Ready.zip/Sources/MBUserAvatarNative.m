// SPDX-License-Identifier: MIT
#import "MBUserAvatarNative.h"
#import "MBUserAvatarMetadata.h"
#import "MBUserAvatarReferencePolicy.h"
#import "MBHybridAvatarURLSource.h"
#import "MBRuntime.h"
#import <objc/message.h>
#import <os/log.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>

@interface MBUserAvatarLookupJob : NSObject
@property(atomic) BOOL canceled;
@property(nonatomic) NSTimeInterval deadline;
@property(nonatomic, copy) NSString *candidate;
@property(nonatomic) uint64_t generation;
@end
@implementation MBUserAvatarLookupJob
@end

static int MBUserAvatarSQLProgress(void *context) {
    MBUserAvatarLookupJob *job = (__bridge MBUserAvatarLookupJob *)context;
    return job.canceled || NSProcessInfo.processInfo.systemUptime >= job.deadline;
}
static int MBUserAvatarSQLAuthorize(__unused void *context, int action,
    const char *table, const char *column, __unused const char *database, __unused const char *trigger) {
    if (action == SQLITE_SELECT) return SQLITE_OK;
    if (action != SQLITE_READ || !table || !column) return SQLITE_DENY;
    struct { const char *table; const char *columns; } allowed[] = {
        {"self_profile", "|user_id|"},
        {"advanced_crypto_transport_threads", "|client_thread_pk|thread_id|"},
        {"client_threads", "|pk|is_group_thread|is_shadow_thread|thread_picture_url|thread_picture_url_fallback|thread_picture_url_expiration_timestamp_ms|"},
        {"client_participants", "|pk|thread_pk|contact_pk|is_pending|"},
        {"client_contacts", "|pk|"},
        {"fb_transport_contacts", "|client_contact_pk|server_contact_id|"},
        {"contacts", "|id|profile_picture_url|profile_picture_fallback_url|profile_picture_url_expiration_timestamp_ms|"},
    };
    for (NSUInteger i = 0; i < sizeof(allowed) / sizeof(allowed[0]); ++i) {
        if (strcmp(table, allowed[i].table)) continue;
        if (!*column) return SQLITE_OK; // SQLite's row-presence read, no field value.
        size_t size = strlen(column);
        if (size > 96) return SQLITE_DENY;
        char bounded[100]; snprintf(bounded, sizeof(bounded), "|%s|", column);
        return strstr(allowed[i].columns, bounded) ? SQLITE_OK : SQLITE_DENY;
    }
    return SQLITE_DENY;
}
static BOOL MBUserAvatarVerifiedVersion(void) {
    @try {
        Class cls = objc_getClass("LSApplicationProxy");
        SEL lookup = sel_registerName("applicationProxyForIdentifier:");
        const char *arguments[] = {"@"};
        if (!cls || !MBMethodMatches(object_getClass(cls), lookup, "@", 1, arguments)) return NO;
        id proxy = ((id (*)(id, SEL, id))objc_msgSend)(cls, lookup, @"com.facebook.Messenger");
        id location = MBReadObject(proxy, sel_registerName("bundleURL"));
        if (![location isKindOfClass:NSURL.class] || ![location isFileURL]) return NO;
        NSData *data = [NSData dataWithContentsOfURL:[location URLByAppendingPathComponent:@"Info.plist"]
            options:NSDataReadingUncached error:NULL];
        if (!data.length || data.length > 2 * 1024 * 1024) return NO;
        id info = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL];
        return [info isKindOfClass:NSDictionary.class] &&
            [info[@"CFBundleShortVersionString"] isEqual:@"579.0.0"] &&
            [info[@"CFBundleVersion"] isEqual:@"1068430635"];
    } @catch (__unused NSException *exception) { return NO; }
}
static NSURL *MBUserAvatarFindDatabase(MBUserAvatarLookupJob *job, NSString **accountID) {
    // Kernel/system paths, not bootstrap paths. Nothing is persisted or created.
    NSURL *root = [NSURL fileURLWithPath:@"/var/mobile/Containers/Shared/AppGroup" isDirectory:YES];
    NSFileManager *files = NSFileManager.defaultManager;
    NSArray<NSURL *> *folders = [files contentsOfDirectoryAtURL:root includingPropertiesForKeys:nil
        options:NSDirectoryEnumerationSkipsHiddenFiles error:NULL];
    if (folders.count > 2048 || job.canceled) return nil;
    NSMutableArray<NSURL *> *databases = [NSMutableArray new];
    for (NSURL *folder in folders) {
        if (job.canceled || NSProcessInfo.processInfo.systemUptime >= job.deadline) return nil;
        NSData *data = [NSData dataWithContentsOfURL:[folder URLByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"]
            options:NSDataReadingUncached error:NULL];
        if (!data.length || data.length > 65536) continue;
        id info = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL];
        NSString *identifier = [info isKindOfClass:NSDictionary.class] ? info[@"MCMMetadataIdentifier"] : nil;
        if (![identifier isKindOfClass:NSString.class]) continue;
        NSString *lower = identifier.lowercaseString;
        if (![lower containsString:@"facebook"] || ![lower containsString:@"messenger"]) continue;
        NSURL *directory = [folder URLByAppendingPathComponent:@"Library/Application Support/lightspeed-userDatabases" isDirectory:YES];
        NSArray<NSURL *> *entries = [files contentsOfDirectoryAtURL:directory includingPropertiesForKeys:nil options:0 error:NULL];
        if (entries.count > 256) return nil;
        for (NSURL *entry in entries) {
            NSString *name = entry.lastPathComponent;
            if (![name.pathExtension isEqualToString:@"db"]) continue;
            NSString *candidate = name.stringByDeletingPathExtension;
            if (!candidate.length || candidate.length > 64 ||
                [candidate rangeOfCharacterFromSet:NSCharacterSet.decimalDigitCharacterSet.invertedSet].location != NSNotFound) continue;
            [databases addObject:entry];
            if (databases.count > 1) return nil; // Active-account selection is unproven; do not guess.
        }
    }
    if (databases.count != 1) return nil;
    NSURL *database = databases.firstObject;
    *accountID = database.lastPathComponent.stringByDeletingPathExtension;
    return database;
}
static MBUserAvatarMetadata *MBUserAvatarLookup(MBUserAvatarLookupJob *job) {
    if (!MBUserAvatarVerifiedVersion() || job.canceled) return nil;
    job.deadline = NSProcessInfo.processInfo.systemUptime + 0.75;
    NSString *accountID = nil;
    NSURL *file = MBUserAvatarFindDatabase(job, &accountID);
    if (!file || job.canceled) return nil;
    struct stat before, after;
    if (lstat(file.fileSystemRepresentation, &before) || !S_ISREG(before.st_mode)) return nil;
    NSURLComponents *parts = [NSURLComponents componentsWithURL:file resolvingAgainstBaseURL:NO];
    NSString *uri = [NSString stringWithFormat:@"file:%@?mode=ro&immutable=1", parts.percentEncodedPath];
    sqlite3 *database = NULL;
    if (sqlite3_open_v2(uri.UTF8String, &database, SQLITE_OPEN_READONLY | SQLITE_OPEN_URI | SQLITE_OPEN_NOMUTEX, NULL) != SQLITE_OK) {
        if (database) sqlite3_close(database);
        return nil;
    }
    MBUserAvatarMetadata *metadata = nil;
    sqlite3_limit(database, SQLITE_LIMIT_LENGTH, 65536);
    sqlite3_limit(database, SQLITE_LIMIT_SQL_LENGTH, 4096);
    sqlite3_progress_handler(database, 1000, MBUserAvatarSQLProgress, (__bridge void *)job);
    // Connection-local only. immutable forbids DB/WAL/SHM writes and deliberately
    // reads main-file photo metadata, NOT a live/WAL/unread authority.
    if (sqlite3_exec(database, "PRAGMA query_only=ON; PRAGMA cache_size=-256; BEGIN", NULL, NULL, NULL) == SQLITE_OK) {
        sqlite3_set_authorizer(database, MBUserAvatarSQLAuthorize, NULL);
        metadata = MBUserAvatarReadForTransport(database, accountID, job.candidate, NULL);
    }
    sqlite3_close(database);
    if (job.canceled || lstat(file.fileSystemRepresentation, &after) ||
        before.st_dev != after.st_dev || before.st_ino != after.st_ino || before.st_size != after.st_size ||
        before.st_mtimespec.tv_sec != after.st_mtimespec.tv_sec || before.st_mtimespec.tv_nsec != after.st_mtimespec.tv_nsec ||
        before.st_ctimespec.tv_sec != after.st_ctimespec.tv_sec || before.st_ctimespec.tv_nsec != after.st_ctimespec.tv_nsec) return nil;
    return metadata;
}

@interface MBUserAvatarRegistration : NSObject
@property(nonatomic, copy) NSString *reference;
@property(nonatomic) uint64_t revision;
@end
@implementation MBUserAvatarRegistration
@end

@interface MBUserAvatarNativeController : NSObject
@property(nonatomic, weak) UIImageView *target;
@property(nonatomic, strong) UIImage *placeholder;
@property(nonatomic, copy) BOOL (^mayApply)(UIImageView *);
@property(nonatomic, copy) NSString *pending, *accountID;
@property(nonatomic, strong) MBUserAvatarLookupJob *job;
@property(nonatomic, strong) MBHybridAvatarURLSource *source;
@property(nonatomic, strong) MBHybridAvatarCache *cache;
@property(nonatomic, strong) id<MBHybridAvatarTask> imageTask;
@property(nonatomic, strong) NSMutableDictionary<NSString *, MBUserAvatarRegistration *> *registrations;
@property(nonatomic, strong) dispatch_queue_t worker;
@property(nonatomic) uint64_t generation, revision;
@property(nonatomic) BOOL busy;
@property(nonatomic) unsigned reports;
- (void)reset;
- (void)observe:(NSString *)candidate target:(UIImageView *)target placeholder:(UIImage *)placeholder guard:(BOOL (^)(UIImageView *))guard;
@end
@implementation MBUserAvatarNativeController
- (instancetype)init {
    if ((self = [super init])) {
        _worker = dispatch_queue_create("com.lyoko-01.messengerbubbles.avatar-metadata", DISPATCH_QUEUE_SERIAL);
        _registrations = [NSMutableDictionary new];
    }
    return self;
}
- (void)report:(int)stage success:(BOOL)success {
    if (self.reports >= 4) return;
    ++self.reports;
    static os_log_t log;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ log = os_log_create(APELIN_PACKAGE_ID, "avatar"); });
    os_log(log, "MBUserAvatar build=%{public}s stage=%d success=%d mainfile=1", APELIN_BUILD_ID, stage, success);
}
- (BOOL)allowed {
    return self.target && self.mayApply && self.mayApply(self.target);
}
- (void)clearAccount {
    [self.imageTask cancel]; self.imageTask = nil;
    [self.cache purge]; [self.source purge]; self.cache = nil; self.source = nil;
    self.accountID = nil; [self.registrations removeAllObjects];
}
- (void)reset {
    NSCAssert(NSThread.isMainThread, @"Native avatar is main-only");
    ++self.generation; self.job.canceled = YES; self.pending = nil;
    self.target.image = self.placeholder; self.target = nil; self.placeholder = nil; self.mayApply = nil;
    [self clearAccount]; self.reports = 0;
}
- (void)applyMetadata:(MBUserAvatarMetadata *)metadata generation:(uint64_t)generation {
    if (generation != self.generation || ![self allowed]) return;
    if (!metadata) { [self clearAccount]; [self report:1 success:NO]; return; }
    [self report:1 success:YES];
    if (![self.accountID isEqualToString:metadata.accountID]) {
        [self clearAccount]; self.accountID = metadata.accountID;
        self.source = [[MBHybridAvatarURLSource alloc] initWithAccountID:metadata.accountID];
        if (!self.source) return;
        self.cache = [[MBHybridAvatarCache alloc] initWithSource:self.source costLimit:4 * 1024 * 1024 maxEntries:32];
    }
    NSTimeInterval lifetime = 0;
    NSString *reference = MBUserAvatarChooseReference(metadata.reference, metadata.fallbackReference,
        metadata.expirationTimestampMS, NSDate.date.timeIntervalSince1970, &lifetime);
    if (!reference) { [self report:2 success:NO]; return; }
    NSString *subject = [NSString stringWithFormat:@"%@:%lu:%@", metadata.groupSubject ? @"group" : @"user",
        (unsigned long)metadata.subjectID.length, metadata.subjectID];
    MBUserAvatarRegistration *registration = self.registrations[subject];
    if (!registration || ![registration.reference isEqualToString:reference]) {
        if (!registration && self.registrations.count >= 64) { [self report:2 success:NO]; return; }
        registration = [MBUserAvatarRegistration new]; registration.reference = reference;
        registration.revision = ++self.revision; self.registrations[subject] = registration;
    }
    NSString *(^registerKey)(void) = ^NSString *{
        return metadata.groupSubject ? [self.source registerGroupID:metadata.subjectID reference:reference revision:registration.revision lifetime:lifetime] :
            [self.source registerUserID:metadata.subjectID reference:reference revision:registration.revision lifetime:lifetime];
    };
    NSString *key = registerKey();
    if (!key) { registration.revision = ++self.revision; key = registerKey(); }
    if (!key) { [self report:2 success:NO]; return; }
    __weak typeof(self) weakSelf = self;
    __weak UIImageView *target = self.target;
    self.imageTask = [self.cache requestKey:key completion:^(UIImage *image) {
        MBUserAvatarNativeController *controller = weakSelf;
        if (!controller || controller.generation != generation || controller.target != target || ![controller allowed]) return;
        controller.imageTask = nil; target.image = image ?: controller.placeholder;
        [controller report:3 success:image != nil]; // Assignment is not visual/layout proof.
    }];
}
- (void)startPending {
    if (self.busy || !self.pending || ![self allowed]) return;
    MBUserAvatarLookupJob *job = [MBUserAvatarLookupJob new];
    job.candidate = self.pending; job.generation = self.generation;
    self.pending = nil; self.job = job; self.busy = YES;
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.worker, ^{
        @autoreleasepool {
            MBUserAvatarMetadata *metadata = MBUserAvatarLookup(job);
            dispatch_async(dispatch_get_main_queue(), ^{
                MBUserAvatarNativeController *controller = weakSelf;
                if (!controller) return;
                controller.busy = NO; controller.job = nil;
                if (!job.canceled) [controller applyMetadata:metadata generation:job.generation];
                [controller startPending]; // Latest only; no queue growth, retry or polling.
            });
        }
    });
}
- (void)observe:(NSString *)candidate target:(UIImageView *)target placeholder:(UIImage *)placeholder guard:(BOOL (^)(UIImageView *))guard {
    ++self.generation; self.job.canceled = YES;
    [self.imageTask cancel]; self.imageTask = nil;
    self.target.image = self.placeholder; target.image = placeholder; // No stale A photo on unknown B.
    self.target = target; self.placeholder = placeholder; self.mayApply = guard;
    self.pending = [candidate copy];
    [self startPending];
}
@end

static MBUserAvatarNativeController *MBUserAvatarNativeInstance;
void MBUserAvatarResetNative(void) {
    if (NSThread.isMainThread) [MBUserAvatarNativeInstance reset];
    else dispatch_async(dispatch_get_main_queue(), ^{ [MBUserAvatarNativeInstance reset]; });
}
void MBUserAvatarObserveNative(NSString *candidate, UIImageView *target, UIImage *placeholder, BOOL (^mayApply)(UIImageView *)) {
    if (!NSThread.isMainThread) return;
    if (placeholder && ![placeholder isKindOfClass:UIImage.class]) placeholder = nil;
    if (![candidate isKindOfClass:NSString.class] || !candidate.length || candidate.length > 512 ||
        ![target isKindOfClass:UIImageView.class] || !mayApply || !mayApply(target)) {
        [MBUserAvatarNativeInstance reset];
        if ([target isKindOfClass:UIImageView.class]) target.image = placeholder;
        return;
    }
    for (NSUInteger i = 0; i < candidate.length; ++i) {
        unichar c = [candidate characterAtIndex:i];
        if (c < 0x21 || c > 0x7e) {
            [MBUserAvatarNativeInstance reset]; target.image = placeholder; return;
        }
    }
    if (!MBUserAvatarNativeInstance) MBUserAvatarNativeInstance = [MBUserAvatarNativeController new];
    [MBUserAvatarNativeInstance observe:candidate target:target placeholder:placeholder guard:mayApply];
}
