// SPDX-License-Identifier: MIT
#import "MBHybridBubbleManager.h"
#include <limits.h>

static BOOL MBHybridIdentifier(NSString *value, NSUInteger limit) {
    return [value isKindOfClass:NSString.class] && value.length > 0 && value.length <= limit;
}
@implementation MBHybridMessageEvent
- (instancetype)initWithThreadID:(NSString *)threadID group:(BOOL)group avatarKey:(NSString *)avatarKey
    messageID:(NSString *)messageID authoritativeUnread:(NSInteger)unread revision:(uint64_t)revision newUnread:(BOOL)newUnread {
    if (!MBHybridIdentifier(threadID, 256) || (avatarKey && !MBHybridIdentifier(avatarKey, 512)) ||
        (messageID && !MBHybridIdentifier(messageID, 512)) || unread < -1 || revision == 0) return nil;
    if ((self = [super init])) {
        _threadID = [threadID copy]; _groupThread = group; _avatarKey = [avatarKey copy]; _messageID = [messageID copy];
        _authoritativeUnread = unread; _sourceRevision = revision; _newUnread = newUnread;
    }
    return self;
}
@end
@interface MBHybridBubble ()
@property(nonatomic, copy) NSString *threadID;
@property(nonatomic) BOOL groupThread;
@property(nonatomic, copy) NSString *avatarKey;
@property(nonatomic, copy) NSString *lastMessageID;
@property(nonatomic) NSUInteger unread;
@property(nonatomic) BOOL unreadIsAuthoritative;
@property(nonatomic) uint64_t sourceRevision, activityOrder;
@end
@implementation MBHybridBubble
- (id)copyWithZone:(NSZone *)zone {
    MBHybridBubble *copy = [[MBHybridBubble allocWithZone:zone] init];
    copy.threadID = self.threadID; copy.groupThread = self.groupThread; copy.avatarKey = self.avatarKey;
    copy.lastMessageID = self.lastMessageID; copy.unread = self.unread;
    copy.unreadIsAuthoritative = self.unreadIsAuthoritative; copy.sourceRevision = self.sourceRevision;
    copy.activityOrder = self.activityOrder;
    return copy;
}
@end
@interface MBHybridSnapshot ()
@property(nonatomic, copy) NSArray<MBHybridBubble *> *items;
@property(nonatomic) MBHybridPresentationStyle style;
@property(nonatomic) BOOL pickerExpanded, badgeIsExact, capacityExceeded;
@property(nonatomic) NSUInteger totalUnread;
@property(nonatomic, copy) NSString *activeThreadID, *pendingThreadID;
@end
@implementation MBHybridSnapshot
@end

@interface MBHybridBubbleManager ()
@property(nonatomic, strong) id<MBHybridSharedChatPanel> panel;
@property(nonatomic, strong) NSMutableDictionary<NSString *, MBHybridBubble *> *bubbles;
@property(nonatomic, strong) NSMutableOrderedSet<NSArray<NSString *> *> *recentMessages;
@property(nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *dismissedRevisions;
@property(nonatomic, strong) NSMutableOrderedSet<NSString *> *dismissedOrder;
@property(nonatomic) NSUInteger maximumThreads;
@property(nonatomic) uint64_t activityClock, epoch, routeTicket;
@property(nonatomic) BOOL expanded, capacityExceeded, changeScheduled, routing, routeSuspended;
@property(nonatomic, strong) dispatch_source_t routeTimer;
@property(nonatomic, copy) NSString *activeID, *desiredID, *routingID;
@end
@implementation MBHybridBubbleManager
- (instancetype)initWithSharedPanel:(id<MBHybridSharedChatPanel>)panel {
    return [self initWithSharedPanel:panel maximumThreads:32];
}
- (instancetype)initWithSharedPanel:(id<MBHybridSharedChatPanel>)panel maximumThreads:(NSUInteger)maximum {
    if (!panel || maximum == 0 || maximum > 32) return nil;
    if ((self = [super init])) {
        _panel = panel; _maximumThreads = maximum; _epoch = 1;
        _bubbles = [NSMutableDictionary new]; _recentMessages = [NSMutableOrderedSet new];
        _dismissedRevisions = [NSMutableDictionary new]; _dismissedOrder = [NSMutableOrderedSet new];
    }
    return self;
}
- (MBHybridSnapshot *)snapshot {
    MBHybridSnapshot *snapshot = [MBHybridSnapshot new];
    if (!NSThread.isMainThread) { snapshot.items = @[]; return snapshot; }
    NSArray *ordered = [self.bubbles.allValues sortedArrayUsingComparator:^NSComparisonResult(MBHybridBubble *a, MBHybridBubble *b) {
        if (a.activityOrder == b.activityOrder) return [a.threadID compare:b.threadID];
        return a.activityOrder > b.activityOrder ? NSOrderedAscending : NSOrderedDescending;
    }];
    snapshot.items = [[NSArray alloc] initWithArray:ordered copyItems:YES];
    snapshot.style = ordered.count == 0 ? MBHybridPresentationHidden : ordered.count == 1 ? MBHybridPresentationSingle : MBHybridPresentationStack;
    snapshot.pickerExpanded = ordered.count > 1 && self.expanded;
    snapshot.activeThreadID = self.activeID; snapshot.pendingThreadID = self.desiredID;
    snapshot.capacityExceeded = self.capacityExceeded;
    BOOL exact = !self.capacityExceeded;
    NSUInteger total = 0;
    for (MBHybridBubble *bubble in ordered) {
        exact = exact && bubble.unreadIsAuthoritative;
        if (NSUIntegerMax - total < bubble.unread) { exact = NO; break; }
        total += bubble.unread;
    }
    snapshot.badgeIsExact = exact;
    snapshot.totalUnread = exact ? total : 0;
    return snapshot;
}
- (void)changed {
    if (self.changeScheduled) return;
    self.changeScheduled = YES;
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        MBHybridBubbleManager *manager = weakSelf;
        if (!manager) return;
        manager.changeScheduled = NO;
        void (^callback)(MBHybridSnapshot *) = manager.onChange;
        if (callback) callback(manager.snapshot);
    });
}
- (BOOL)onMessage:(MBHybridMessageEvent *)event {
    if (!NSThread.isMainThread || ![event isKindOfClass:MBHybridMessageEvent.class] ||
        !MBHybridIdentifier(event.threadID, 256) || event.sourceRevision == 0 || event.authoritativeUnread < -1 ||
        (event.avatarKey && !MBHybridIdentifier(event.avatarKey, 512)) ||
        (event.messageID && !MBHybridIdentifier(event.messageID, 512))) return NO;
    NSString *thread = event.threadID;
    MBHybridBubble *bubble = self.bubbles[thread];
    // The provider supplies thread identity, not sender identity. Kind cannot flip.
    if (bubble && (bubble.groupThread != event.groupThread || event.sourceRevision <= bubble.sourceRevision)) return NO;
    NSNumber *dismissed = self.dismissedRevisions[thread];
    if (!bubble && dismissed && event.sourceRevision <= dismissed.unsignedLongLongValue) return NO;
    NSArray *messageKey = event.messageID ? @[thread, event.messageID] : nil;
    BOOL duplicate = messageKey && [self.recentMessages containsObject:messageKey];
    // A duplicate message can carry a NEW authoritative unread revision, but can
    // never recreate a dismissed bubble or increase/reorder a message again.
    if (duplicate && !bubble) return NO;
    if (!bubble) {
        if (self.bubbles.count >= self.maximumThreads) {
            if (!self.capacityExceeded) { self.capacityExceeded = YES; [self changed]; }
            return NO; // No silent eviction, false total, or unbounded allocation.
        }
        bubble = [MBHybridBubble new]; bubble.threadID = thread; bubble.groupThread = event.groupThread;
        self.bubbles[thread] = bubble;
    }
    bubble.sourceRevision = event.sourceRevision;
    BOOL visibleChange = NO;
    if (event.authoritativeUnread >= 0) {
        NSUInteger count = (NSUInteger)event.authoritativeUnread;
        visibleChange = !bubble.unreadIsAuthoritative || count != bubble.unread;
        bubble.unread = count; bubble.unreadIsAuthoritative = YES;
    } else if (!duplicate && event.newUnread) {
        // Preserve the sample's increment only as a local estimate. A transport
        // message cannot prove real unread after reads on this/another device.
        if (event.messageID && bubble.unread < NSUIntegerMax) ++bubble.unread;
        bubble.unreadIsAuthoritative = NO; visibleChange = YES;
    }
    if (bubble.avatarKey != event.avatarKey && ![bubble.avatarKey isEqualToString:event.avatarKey]) {
        bubble.avatarKey = event.avatarKey; visibleChange = YES; // Metadata may change on a deduplicated message.
    }
    if (!duplicate) {
        bubble.lastMessageID = event.messageID;
        bubble.activityOrder = ++self.activityClock; visibleChange = YES;
        if (messageKey) {
            [self.recentMessages addObject:messageKey];
            if (self.recentMessages.count > 512) [self.recentMessages removeObjectAtIndex:0];
        }
    }
    if (visibleChange) [self changed];
    return visibleChange;
}
- (BOOL)onUnreadChanged:(NSString *)threadID count:(NSInteger)count revision:(uint64_t)revision {
    if (!NSThread.isMainThread || !MBHybridIdentifier(threadID, 256) || count < 0 || revision == 0) return NO;
    MBHybridBubble *bubble = self.bubbles[threadID];
    if (!bubble || revision <= bubble.sourceRevision) return NO;
    bubble.sourceRevision = revision;
    BOOL changed = !bubble.unreadIsAuthoritative || bubble.unread != (NSUInteger)count;
    bubble.unread = (NSUInteger)count; bubble.unreadIsAuthoritative = YES;
    if (changed) [self changed];
    return changed;
}
- (void)onStackTap {
    if (!NSThread.isMainThread || !self.bubbles.count) return;
    if (self.bubbles.count == 1) { [self onAvatarTap:self.bubbles.allKeys.firstObject]; return; }
    self.expanded = !self.expanded;
    [self changed];
}
- (void)onAvatarTap:(NSString *)threadID {
    if (!NSThread.isMainThread || !MBHybridIdentifier(threadID, 256) || !self.bubbles[threadID] || self.routeSuspended) return;
    self.expanded = NO;
    if ([self.activeID isEqualToString:threadID] && !self.routing) {
        [self.panel present]; [self changed]; return;
    }
    self.desiredID = threadID;
    [self changed];
    if (!self.routing) [self beginNavigation];
}
- (void)stopNavigationDeadline {
    if (self.routeTimer) { dispatch_source_cancel(self.routeTimer); self.routeTimer = nil; }
}
- (void)beginNavigation {
    if (self.routing || self.routeSuspended || !self.desiredID) return;
    MBHybridBubble *bubble = self.bubbles[self.desiredID];
    if (!bubble) { self.desiredID = nil; return; }
    self.routing = YES; self.routingID = bubble.threadID; self.activeID = nil;
    [self.panel collapse]; // No transient old chat/inbox while a route is unresolved.
    uint64_t epoch = self.epoch, ticket = ++self.routeTicket;
    NSString *thread = bubble.threadID;
    __weak typeof(self) weakSelf = self;
    __weak MBHybridBubble *weakBubble = bubble;
    [self.panel navigateToThread:thread group:bubble.groupThread completion:^(BOOL success) {
        dispatch_async(dispatch_get_main_queue(), ^{
            MBHybridBubbleManager *manager = weakSelf;
            if (!manager || !manager.routing || manager.epoch != epoch || manager.routeTicket != ticket) return;
            [manager stopNavigationDeadline];
            manager.routing = NO; manager.routingID = nil;
            BOOL current = [manager.desiredID isEqualToString:thread] && weakBubble && manager.bubbles[thread] == weakBubble;
            if (current) {
                manager.desiredID = nil;
                if (success) { manager.activeID = thread; [manager.panel present]; }
                else { manager.activeID = nil; [manager.panel collapse]; }
                [manager changed];
            } else if (manager.desiredID && manager.bubbles[manager.desiredID]) {
                [manager beginNavigation];
            } else {
                manager.desiredID = nil; [manager.panel collapse]; [manager changed];
            }
        });
    }];
    // A hung router is failed closed once, never polled/retried. Reset is required
    // before any new route, so a late callback cannot race a newer scene mutation.
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    self.routeTimer = timer;
    dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_SEC), DISPATCH_TIME_FOREVER, 20 * NSEC_PER_MSEC);
    dispatch_source_set_event_handler(timer, ^{
        MBHybridBubbleManager *manager = weakSelf;
        if (!manager || !manager.routing || manager.epoch != epoch || manager.routeTicket != ticket) return;
        [manager stopNavigationDeadline];
        manager.routing = NO; manager.routeSuspended = YES;
        manager.desiredID = nil; manager.routingID = nil; manager.activeID = nil;
        ++manager.routeTicket; [manager.panel cancelNavigation]; [manager.panel collapse]; [manager changed];
    });
    dispatch_resume(timer);
}
- (BOOL)onBubbleClose:(NSString *)threadID {
    if (!NSThread.isMainThread || !MBHybridIdentifier(threadID, 256)) return NO;
    MBHybridBubble *bubble = self.bubbles[threadID];
    if (!bubble) return NO;
    self.dismissedRevisions[threadID] = @(bubble.sourceRevision);
    [self.dismissedOrder removeObject:threadID]; [self.dismissedOrder addObject:threadID];
    if (self.dismissedOrder.count > 64) {
        NSString *old = self.dismissedOrder.firstObject;
        [self.dismissedRevisions removeObjectForKey:old]; [self.dismissedOrder removeObjectAtIndex:0];
    }
    [self.bubbles removeObjectForKey:threadID]; self.expanded = NO;
    if ([self.activeID isEqualToString:threadID]) { self.activeID = nil; [self.panel collapse]; }
    if ([self.desiredID isEqualToString:threadID]) self.desiredID = nil;
    if ([self.routingID isEqualToString:threadID]) [self.panel collapse];
    [self changed];
    return YES;
}
- (void)reset {
    if (!NSThread.isMainThread) return;
    ++self.epoch; ++self.routeTicket;
    [self stopNavigationDeadline];
    [self.bubbles removeAllObjects]; [self.recentMessages removeAllObjects];
    [self.dismissedRevisions removeAllObjects]; [self.dismissedOrder removeAllObjects];
    self.activeID = nil; self.desiredID = nil; self.routingID = nil;
    self.routing = NO; self.routeSuspended = NO; self.expanded = NO; self.capacityExceeded = NO;
    [self.panel cancelNavigation]; [self.panel collapse]; [self changed];
}
- (void)dealloc { if (_routeTimer) dispatch_source_cancel(_routeTimer); }
@end
